---
gca-followup-marker: v1
project_id: 24bf72c3-2ee8-45fd-b879-d3a00b347c39
persona_id: QA
persona_name: QA/Testing Lead
generated_at: 2026-05-05T01:39:19.649279+00:00
question_count: 51
---

# Perguntas em aberto — QA/Testing Lead — Assistente Judicial para Advogados

Preencha as respostas abaixo de cada pergunta (substitua `<sua resposta aqui>`). Faça upload deste arquivo pela aba **Ingestão de Documentos**. NÃO altere as linhas com `<!-- pfq-id: ... -->`.

## Q1
<!-- pfq-id: b74d6fb6-10df-4320-a3e0-f9d71fa798cd -->

**Pergunta**: Qual a meta de cobertura de código (>80%)?

**Resposta**:

A meta mínima de cobertura de código para o AJA será 80% no MVP, com meta recomendada de 85% para módulos críticos como RBAC, prazos, cálculo judicial, anonimização, LLM Gateway, auditoria e conectores externos. A cobertura deverá bloquear merge quando cair abaixo do limite definido por módulo.

## Q2
<!-- pfq-id: 1db57dae-ca87-400f-ac0d-9b5ef9fad772 -->

**Pergunta**: Qual a expectativa de volume de usuários simultâneos para dimensionar os testes de carga?

**Resposta**:

Para testes de carga do MVP, a premissa inicial será escritório pequeno/médio com 1 a 10 advogados e equipe de apoio, simulando 20 usuários simultâneos por tenant, 100 usuários simultâneos na plataforma, 10.000 processos por tenant, 100.000 documentos por tenant e picos controlados de consultas externas. Os volumes devem ser revisados na Sprint 0 conforme o escritório piloto.

## Q3
<!-- pfq-id: bbffe4e7-fde6-4f09-9135-e7aed361a08f -->

**Pergunta**: Existe alguma suíte de testes atual? Se sim, qual cobertura atual?

**Resposta**:

A meta mínima de cobertura de código para o AJA será 80% no MVP, com meta recomendada de 85% para módulos críticos como RBAC, prazos, cálculo judicial, anonimização, LLM Gateway, auditoria e conectores externos. A cobertura deverá bloquear merge quando cair abaixo do limite definido por módulo.

## Q4
<!-- pfq-id: dd85c7ae-3178-408a-b032-5189d83f6f52 -->

**Pergunta**: Qual a expectativa de cobertura mínima de código para testes unitários (>80%)?

**Resposta**:

A meta mínima de cobertura de código para o AJA será 80% no MVP, com meta recomendada de 85% para módulos críticos como RBAC, prazos, cálculo judicial, anonimização, LLM Gateway, auditoria e conectores externos. A cobertura deverá bloquear merge quando cair abaixo do limite definido por módulo.

## Q5
<!-- pfq-id: a37fed73-f77a-4960-881b-55f774eff65b -->

**Pergunta**: Qual meta de cobertura de testes unitários é esperada?

**Resposta**:

A meta mínima de cobertura de código para o AJA será 80% no MVP, com meta recomendada de 85% para módulos críticos como RBAC, prazos, cálculo judicial, anonimização, LLM Gateway, auditoria e conectores externos. A cobertura deverá bloquear merge quando cair abaixo do limite definido por módulo.

## Q6
<!-- pfq-id: eede4c46-9410-42bc-99ca-0b5edc2c35cd -->

**Pergunta**: Qual é o plano de testes para o MVP? Quais frameworks serão adotados?

**Resposta**:

Os frameworks recomendados são: pytest para backend Python, Jest/Vitest e React Testing Library para frontend, Playwright para testes E2E e acessibilidade automatizada, Pact ou Schemathesis para testes de contrato/API, Testcontainers para dependências como PostgreSQL/Redis, k6 ou Locust para carga, OWASP ZAP para DAST e fixtures/mocks versionados para DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e PJe/MNI.

## Q7
<!-- pfq-id: 4109b444-96df-4877-bc35-ebe05bd91d52 -->

**Pergunta**: Quais são os cenários críticos de E2E identificados para o MVP?

**Resposta**:

Cenários E2E críticos do MVP: login/MFA; criação de tenant; cadastro de usuário/RBAC; criação de caso; verificação de conflito de interesses; ingestão de documento; geração de minuta por IA com anonimização; revisão humana obrigatória; aprovação de template; consulta DataJud com cache/fallback; validação CNA/OAB; cálculo judicial com BCB/SGS; criação e revisão de prazo; exportação de documento; solicitação LGPD; trilha de auditoria; falha de conector externo e operação assíncrona com notificação.

## Q8
<!-- pfq-id: d0f570a0-341a-455e-ad1b-2ad3560ef043 -->

**Pergunta**: Qual é a meta de cobertura de código para o conector?

**Resposta**:

A meta mínima para conectores críticos é 85% de cobertura unitária e 100% de cobertura dos fluxos de erro conhecidos, incluindo sucesso, timeout, rate limit, autenticação inválida, resposta inválida, cache, retry, circuit breaker e fallback manual.

## Q9
<!-- pfq-id: 1d1644c2-8d2a-4169-aa4a-f553f77fc4a1 -->

**Pergunta**: Qual o ambiente de homologação (sandbox) disponível para execução dos testes?

**Resposta**:

Para o MVP, os testes usarão ambiente de homologação próprio do AJA com mocks/fixtures versionados dos conectores DataJud, CNA/OAB e BCB/SGS. Quando houver credenciais reais, serão adicionados ambientes de homologação PDPJ/DJE e PJe/MNI por tribunal piloto. Até lá, contratos sintéticos e mocks baseados em formatos reais deverão cobrir os testes de integração.

## Q10
<!-- pfq-id: 46c56c67-d4c7-4c5f-8d69-08b29d9f040c -->

**Pergunta**: Quais frameworks de teste unitário serão usados?

**Resposta**:

Os frameworks recomendados são: pytest para backend Python, Jest/Vitest e React Testing Library para frontend, Playwright para testes E2E e acessibilidade automatizada, Pact ou Schemathesis para testes de contrato/API, Testcontainers para dependências como PostgreSQL/Redis, k6 ou Locust para carga, OWASP ZAP para DAST e fixtures/mocks versionados para DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e PJe/MNI.

## Q11
<!-- pfq-id: 11936916-4f8e-4295-b156-3630849f5f55 -->

**Pergunta**: Há requisito de conformidade com WCAG AA para a versão inicial? Qual o orçamento para testes de acessibilidade?

**Resposta**:

Sim. O MVP deverá cumprir WCAG 2.2 nível AA como referência mínima. O contraste mínimo será de 4,5:1 para texto normal e 3:1 para texto grande, ícones informativos e componentes essenciais. A interface deverá suportar zoom/redimensionamento de texto até 200% sem perda de conteúdo ou funcionalidade. A validação deverá incluir axe-core, Lighthouse, testes com Playwright, revisão manual de teclado, foco visível, mensagens de erro acessíveis, labels em campos e ausência de dependência exclusiva de cor.

## Q12
<!-- pfq-id: 3aff064b-be84-426c-90b1-2ff7d54719c8 -->

**Pergunta**: Quais cenários críticos devem ter testes E2E?

**Resposta**:

Cenários E2E críticos do MVP: login/MFA; criação de tenant; cadastro de usuário/RBAC; criação de caso; verificação de conflito de interesses; ingestão de documento; geração de minuta por IA com anonimização; revisão humana obrigatória; aprovação de template; consulta DataJud com cache/fallback; validação CNA/OAB; cálculo judicial com BCB/SGS; criação e revisão de prazo; exportação de documento; solicitação LGPD; trilha de auditoria; falha de conector externo e operação assíncrona com notificação.

## Q13
<!-- pfq-id: 659f00f4-49d7-4e0d-adfe-5a8b6e64e401 -->

**Pergunta**: Quais ferramentas de automação de testes serão adotadas para integração e E2E?

**Resposta**:

Os frameworks recomendados são: pytest para backend Python, Jest/Vitest e React Testing Library para frontend, Playwright para testes E2E e acessibilidade automatizada, Pact ou Schemathesis para testes de contrato/API, Testcontainers para dependências como PostgreSQL/Redis, k6 ou Locust para carga, OWASP ZAP para DAST e fixtures/mocks versionados para DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e PJe/MNI.

## Q14
<!-- pfq-id: 26cd66e9-71a6-4380-8866-732a6259434d -->

**Pergunta**: Quais frameworks de teste (ex.: Jest, pytest, JUnit) serão adotados?

**Resposta**:

Os frameworks recomendados são: pytest para backend Python, Jest/Vitest e React Testing Library para frontend, Playwright para testes E2E e acessibilidade automatizada, Pact ou Schemathesis para testes de contrato/API, Testcontainers para dependências como PostgreSQL/Redis, k6 ou Locust para carga, OWASP ZAP para DAST e fixtures/mocks versionados para DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e PJe/MNI.

## Q15
<!-- pfq-id: 48eeacca-734d-447e-841d-572975a7be2c -->

**Pergunta**: Quais cenários críticos devem ser cobertos por testes E2E?

**Resposta**:

Cenários E2E críticos do MVP: login/MFA; criação de tenant; cadastro de usuário/RBAC; criação de caso; verificação de conflito de interesses; ingestão de documento; geração de minuta por IA com anonimização; revisão humana obrigatória; aprovação de template; consulta DataJud com cache/fallback; validação CNA/OAB; cálculo judicial com BCB/SGS; criação e revisão de prazo; exportação de documento; solicitação LGPD; trilha de auditoria; falha de conector externo e operação assíncrona com notificação.

## Q16
<!-- pfq-id: e385d1d9-b32d-49bc-bb80-89007913f65b -->

**Pergunta**: Qual meta de cobertura mínima de código por domínio será estabelecida?

**Resposta**:

A meta por domínio será: regras críticas de prazos, cálculos, RBAC, LGPD, anonimização e conectores com mínimo de 85%; frontend e componentes UI com mínimo de 80%; utilitários simples com mínimo de 75%. Qualquer redução deverá ser justificada por exceção técnica aprovada.

## Q17
<!-- pfq-id: 14f6532f-4acd-4a7e-877f-b8ddd84e77dd -->

**Pergunta**: Quais frameworks de teste serão usados (ex.: JUnit, pytest, Go testing)?

**Resposta**:

Os frameworks recomendados são: pytest para backend Python, Jest/Vitest e React Testing Library para frontend, Playwright para testes E2E e acessibilidade automatizada, Pact ou Schemathesis para testes de contrato/API, Testcontainers para dependências como PostgreSQL/Redis, k6 ou Locust para carga, OWASP ZAP para DAST e fixtures/mocks versionados para DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e PJe/MNI.

## Q18
<!-- pfq-id: a9def561-2e85-4ced-a782-9be1fb432eff -->

**Pergunta**: Quem será responsável por escrever e manter os testes automatizados (QA/DEV)?

**Resposta**:

A responsabilidade será compartilhada. Desenvolvedores devem escrever testes unitários e de integração dos módulos que implementarem; QA/Testing Lead define estratégia, cenários, critérios de aceite, E2E, regressão e qualidade da suíte; DevOps garante execução na pipeline; PO/advogado sênior validam cenários jurídicos; DPO valida cenários LGPD e dados sensíveis.

## Q19
<!-- pfq-id: 6dfc39da-5391-495a-aef0-710ad26c71ec -->

**Pergunta**: Haverá testes de integração entre componentes locais?

**Resposta**:

Sim. Haverá testes de integração entre frontend, backend, banco, Redis, storage, LLM Gateway, Integration Gateway e conectores. Os conectores externos deverão ter testes contra mocks, testes de contrato e, quando disponíveis, testes em sandbox/homologação. Falhas externas devem validar retry, cache, circuit breaker, fallback manual e mensagens ao usuário.

## Q20
<!-- pfq-id: 4ca1a911-a489-45fe-b07e-90d618287dfb -->

**Pergunta**: Quais telas/fluxos E2E são considerados críticos e precisam ser automatizados antes da entrega?

**Resposta**:

Cenários E2E críticos do MVP: login/MFA; criação de tenant; cadastro de usuário/RBAC; criação de caso; verificação de conflito de interesses; ingestão de documento; geração de minuta por IA com anonimização; revisão humana obrigatória; aprovação de template; consulta DataJud com cache/fallback; validação CNA/OAB; cálculo judicial com BCB/SGS; criação e revisão de prazo; exportação de documento; solicitação LGPD; trilha de auditoria; falha de conector externo e operação assíncrona com notificação.

## Q21
<!-- pfq-id: cbc48ee8-be40-4fe2-a331-d2559ec068a1 -->

**Pergunta**: Há requisitos de acessibilidade (WCAG AA) a serem cobertos?

**Resposta**:

Sim. O MVP deverá cumprir WCAG 2.2 nível AA como referência mínima. O contraste mínimo será de 4,5:1 para texto normal e 3:1 para texto grande, ícones informativos e componentes essenciais. A interface deverá suportar zoom/redimensionamento de texto até 200% sem perda de conteúdo ou funcionalidade. A validação deverá incluir axe-core, Lighthouse, testes com Playwright, revisão manual de teclado, foco visível, mensagens de erro acessíveis, labels em campos e ausência de dependência exclusiva de cor.

## Q22
<!-- pfq-id: 6c1b9ac5-cb5c-4315-a28d-ba8864f48b19 -->

**Pergunta**: Há um ambiente de CI/CD previsto para execução contínua dos testes?

**Resposta**:

Os testes unitários e lint devem entrar na pipeline desde a Sprint 0. Testes de integração e contrato entram até o fim da fundação técnica. Testes E2E, acessibilidade, carga básica e segurança entram antes do fechamento do MVP 1. A pipeline deverá bloquear merge em falha crítica e gerar evidências para o GCA/Gatekeeper.

## Q23
<!-- pfq-id: 0377dc7c-af34-49d7-b633-d022666f22a2 -->

**Pergunta**: Existe estratégia para testes de integração entre módulos locais e conectores?

**Resposta**:

Sim. Haverá testes de integração entre frontend, backend, banco, Redis, storage, LLM Gateway, Integration Gateway e conectores. Os conectores externos deverão ter testes contra mocks, testes de contrato e, quando disponíveis, testes em sandbox/homologação. Falhas externas devem validar retry, cache, circuit breaker, fallback manual e mensagens ao usuário.

## Q24
<!-- pfq-id: 81ac69fa-dfd2-491f-9921-64c646235d76 -->

**Pergunta**: Qual cobertura mínima de código (unitário) é esperada para o AJA?

**Resposta**:

A meta mínima de cobertura de código para o AJA será 80% no MVP, com meta recomendada de 85% para módulos críticos como RBAC, prazos, cálculo judicial, anonimização, LLM Gateway, auditoria e conectores externos. A cobertura deverá bloquear merge quando cair abaixo do limite definido por módulo.

## Q25
<!-- pfq-id: d1ab4c87-3f9d-4f5d-90d9-cd94f1a8bca1 -->

**Pergunta**: Já existe algum ambiente de CI rodando (mesmo sem testes)?

**Resposta**:

Ainda não há suíte de testes atual aprovada para o AJA. Como requisito da Sprint 0, deverá ser criada a base de testes unitários, integração, contrato, E2E, acessibilidade e segurança, com pipeline CI executando em pull requests e builds de release. A cobertura inicial será zero até implantação da esteira e deverá evoluir progressivamente até os limites definidos para o MVP.

## Q26
<!-- pfq-id: 1554fd1e-84c2-4d2e-9643-54768af98288 -->

**Pergunta**: Como serão simuladas as respostas da API DataJud nos testes de integração? Haverá mocks/fixtures baseados no formato real?

**Resposta**:

As respostas DataJud serão simuladas com fixtures JSON versionadas, baseadas nos formatos oficiais observados, cobrindo processo encontrado, não encontrado, tribunal indisponível, rate limit, timeout, resposta parcial, erro de autenticação, cache hit/cache miss e mudança de schema. Os mocks devem ter contratos OpenAPI/JSON Schema e revisão periódica conforme documentação pública do CNJ.

## Q27
<!-- pfq-id: e1df0fef-a3cb-4f71-871c-740bc740f8e4 -->

**Pergunta**: Quando os testes unitários, de integração e E2E serão integrados à pipeline CI/CD?

**Resposta**:

Os frameworks recomendados são: pytest para backend Python, Jest/Vitest e React Testing Library para frontend, Playwright para testes E2E e acessibilidade automatizada, Pact ou Schemathesis para testes de contrato/API, Testcontainers para dependências como PostgreSQL/Redis, k6 ou Locust para carga, OWASP ZAP para DAST e fixtures/mocks versionados para DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e PJe/MNI.

## Q28
<!-- pfq-id: f25a61e8-c15c-4391-8b84-cfef81df0373 -->

**Pergunta**: Quais cenários críticos E2E precisam ser testados (ex: fluxo de criação de petição até exportação)?

**Resposta**:

Cenários E2E críticos do MVP: login/MFA; criação de tenant; cadastro de usuário/RBAC; criação de caso; verificação de conflito de interesses; ingestão de documento; geração de minuta por IA com anonimização; revisão humana obrigatória; aprovação de template; consulta DataJud com cache/fallback; validação CNA/OAB; cálculo judicial com BCB/SGS; criação e revisão de prazo; exportação de documento; solicitação LGPD; trilha de auditoria; falha de conector externo e operação assíncrona com notificação.

## Q29
<!-- pfq-id: 312dcf42-c9ec-479a-ae62-0558a228ae3b -->

**Pergunta**: Qual SLA de uptime esperado para os sistemas externos para calibrar timeouts e políticas de retry?

**Resposta**:

Como sistemas externos públicos podem não oferecer SLA contratual, os testes devem assumir indisponibilidade e latência variável. O AJA deverá usar timeouts curtos, retry com backoff, cache, circuit breaker e fallback manual. Para calibragem inicial: timeout de conexão 3s, timeout total 10s por tentativa, até 3 tentativas para operações idempotentes e abertura de circuito após falhas consecutivas configuráveis.

## Q30
<!-- pfq-id: 0a50049d-0976-425d-b58b-3498c1947287 -->

**Pergunta**: Qual a expectativa de volume de requisições para definir testes de carga?

**Resposta**:

Para testes de carga do MVP, a premissa inicial será escritório pequeno/médio com 1 a 10 advogados e equipe de apoio, simulando 20 usuários simultâneos por tenant, 100 usuários simultâneos na plataforma, 10.000 processos por tenant, 100.000 documentos por tenant e picos controlados de consultas externas. Os volumes devem ser revisados na Sprint 0 conforme o escritório piloto.

## Q31
<!-- pfq-id: 8a7f8880-ae83-41ec-8b2e-f357389e0e61 -->

**Pergunta**: Qual o volume máximo de documentos e casos que o sistema deve suportar em testes de carga?

**Resposta**:

Para testes de carga do MVP, a premissa inicial será escritório pequeno/médio com 1 a 10 advogados e equipe de apoio, simulando 20 usuários simultâneos por tenant, 100 usuários simultâneos na plataforma, 10.000 processos por tenant, 100.000 documentos por tenant e picos controlados de consultas externas. Os volumes devem ser revisados na Sprint 0 conforme o escritório piloto.

## Q32
<!-- pfq-id: 0c77c22a-d6f3-469a-a0f0-0780ec42d8d5 -->

**Pergunta**: Quais cenários E2E críticos devem ser cobertos automatizados (ex.: ciclo de revisão humana obrigatória, falha de conector, conflito de interesses)?

**Resposta**:

Cenários E2E críticos do MVP: login/MFA; criação de tenant; cadastro de usuário/RBAC; criação de caso; verificação de conflito de interesses; ingestão de documento; geração de minuta por IA com anonimização; revisão humana obrigatória; aprovação de template; consulta DataJud com cache/fallback; validação CNA/OAB; cálculo judicial com BCB/SGS; criação e revisão de prazo; exportação de documento; solicitação LGPD; trilha de auditoria; falha de conector externo e operação assíncrona com notificação.

## Q33
<!-- pfq-id: ff9b745c-fc90-4b38-80d6-7b686cc2430a -->

**Pergunta**: Há intenção de testes automatizados de acessibilidade (ex.: axe-core, lighthouse)?

**Resposta**:

Sim. O MVP deverá cumprir WCAG 2.2 nível AA como referência mínima. O contraste mínimo será de 4,5:1 para texto normal e 3:1 para texto grande, ícones informativos e componentes essenciais. A interface deverá suportar zoom/redimensionamento de texto até 200% sem perda de conteúdo ou funcionalidade. A validação deverá incluir axe-core, Lighthouse, testes com Playwright, revisão manual de teclado, foco visível, mensagens de erro acessíveis, labels em campos e ausência de dependência exclusiva de cor.

## Q34
<!-- pfq-id: 535e2f08-5c01-404b-b32c-cfc0837cd6ea -->

**Pergunta**: Quais cenários críticos de negócio precisam ser cobertos por testes E2E (ex.: consulta por número de processo, paginação, falha de autenticação)?

**Resposta**:

Cenários E2E críticos do MVP: login/MFA; criação de tenant; cadastro de usuário/RBAC; criação de caso; verificação de conflito de interesses; ingestão de documento; geração de minuta por IA com anonimização; revisão humana obrigatória; aprovação de template; consulta DataJud com cache/fallback; validação CNA/OAB; cálculo judicial com BCB/SGS; criação e revisão de prazo; exportação de documento; solicitação LGPD; trilha de auditoria; falha de conector externo e operação assíncrona com notificação.

## Q35
<!-- pfq-id: 65856c99-c354-4c68-b3c6-d2d6c36513d7 -->

**Pergunta**: Como serão gerados dados de teste anonimizados que simulem cenários reais sem PII?

**Resposta**:

O item deverá ser coberto no plano de QA do AJA antes do piloto produtivo, com critério de aceite testável, evidência na pipeline, massa de teste controlada, logs e aprovação do responsável pelo módulo.

## Q36
<!-- pfq-id: 2e49d470-9915-4c9b-a907-62d111335e77 -->

**Pergunta**: Como serão realizados os testes de regressão de templates e cálculos?

**Resposta**:

O item deverá ser coberto no plano de QA do AJA antes do piloto produtivo, com critério de aceite testável, evidência na pipeline, massa de teste controlada, logs e aprovação do responsável pelo módulo.

## Q37
<!-- pfq-id: 6f6a4860-ca35-4ea4-8f85-588eab316a5c -->

**Pergunta**: Haverá integração com ferramenta de métricas de cobertura (ex: Istanbul, JaCoCo) no CI?

**Resposta**:

A meta mínima de cobertura de código para o AJA será 80% no MVP, com meta recomendada de 85% para módulos críticos como RBAC, prazos, cálculo judicial, anonimização, LLM Gateway, auditoria e conectores externos. A cobertura deverá bloquear merge quando cair abaixo do limite definido por módulo.

## Q38
<!-- pfq-id: 0bff9a1f-e358-42ce-9c4b-044d09e65c77 -->

**Pergunta**: Existe algum requisito de conformidade com WCAG 2.1 AA que deva ser validado?

**Resposta**:

Sim. O MVP deverá cumprir WCAG 2.2 nível AA como referência mínima. O contraste mínimo será de 4,5:1 para texto normal e 3:1 para texto grande, ícones informativos e componentes essenciais. A interface deverá suportar zoom/redimensionamento de texto até 200% sem perda de conteúdo ou funcionalidade. A validação deverá incluir axe-core, Lighthouse, testes com Playwright, revisão manual de teclado, foco visível, mensagens de erro acessíveis, labels em campos e ausência de dependência exclusiva de cor.

## Q39
<!-- pfq-id: d3c875fa-9fce-4038-9496-25ad947fca36 -->

**Pergunta**: Como será garantida a detecção de regressões a cada release? Há suíte de regressão automatizada?

**Resposta**:

Ainda não há suíte de testes atual aprovada para o AJA. Como requisito da Sprint 0, deverá ser criada a base de testes unitários, integração, contrato, E2E, acessibilidade e segurança, com pipeline CI executando em pull requests e builds de release. A cobertura inicial será zero até implantação da esteira e deverá evoluir progressivamente até os limites definidos para o MVP.

## Q40
<!-- pfq-id: 5700d70d-2501-4d15-af79-176f3f9ecb77 -->

**Pergunta**: Qual o volume esperado de requisições e usuários simultâneos para orientar testes de carga?

**Resposta**:

Para testes de carga do MVP, a premissa inicial será escritório pequeno/médio com 1 a 10 advogados e equipe de apoio, simulando 20 usuários simultâneos por tenant, 100 usuários simultâneos na plataforma, 10.000 processos por tenant, 100.000 documentos por tenant e picos controlados de consultas externas. Os volumes devem ser revisados na Sprint 0 conforme o escritório piloto.

## Q41
<!-- pfq-id: 80c7c264-5833-4d90-a927-3e08ccf1c240 -->

**Pergunta**: Qual o SLA de desempenho esperado para as consultas? Haverá testes de carga com volume de usuários simultâneos?

**Resposta**:

Para testes de carga do MVP, a premissa inicial será escritório pequeno/médio com 1 a 10 advogados e equipe de apoio, simulando 20 usuários simultâneos por tenant, 100 usuários simultâneos na plataforma, 10.000 processos por tenant, 100.000 documentos por tenant e picos controlados de consultas externas. Os volumes devem ser revisados na Sprint 0 conforme o escritório piloto.

## Q42
<!-- pfq-id: fed1a416-1751-4fff-a99e-098ffa521c07 -->

**Pergunta**: Qual o SLA de uptime e latência esperado para que os testes de performance sejam desenhados?

**Resposta**:

Como sistemas externos públicos podem não oferecer SLA contratual, os testes devem assumir indisponibilidade e latência variável. O AJA deverá usar timeouts curtos, retry com backoff, cache, circuit breaker e fallback manual. Para calibragem inicial: timeout de conexão 3s, timeout total 10s por tentativa, até 3 tentativas para operações idempotentes e abertura de circuito após falhas consecutivas configuráveis.

## Q43
<!-- pfq-id: f5e4dc35-8ed1-49f1-b6d6-64b86f9234a6 -->

**Pergunta**: Quais ferramentas de teste de performance serão empregadas (ex: JMeter)?

**Resposta**:

Os frameworks recomendados são: pytest para backend Python, Jest/Vitest e React Testing Library para frontend, Playwright para testes E2E e acessibilidade automatizada, Pact ou Schemathesis para testes de contrato/API, Testcontainers para dependências como PostgreSQL/Redis, k6 ou Locust para carga, OWASP ZAP para DAST e fixtures/mocks versionados para DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e PJe/MNI.

## Q44
<!-- pfq-id: 2b45533c-7648-46f4-9bde-de7af90ad6e5 -->

**Pergunta**: Como será tratada a regressão em atualizações com migração de dados locais?

**Resposta**:

O item deverá ser coberto no plano de QA do AJA antes do piloto produtivo, com critério de aceite testável, evidência na pipeline, massa de teste controlada, logs e aprovação do responsável pelo módulo.

## Q45
<!-- pfq-id: 6ad17091-dee1-470f-a50f-f88bb09ddcac -->

**Pergunta**: O produto possui requisitos de acessibilidade WCAG? Serão realizados testes de acessibilidade automatizados ou manuais?

**Resposta**:

Sim. O MVP deverá cumprir WCAG 2.2 nível AA como referência mínima. O contraste mínimo será de 4,5:1 para texto normal e 3:1 para texto grande, ícones informativos e componentes essenciais. A interface deverá suportar zoom/redimensionamento de texto até 200% sem perda de conteúdo ou funcionalidade. A validação deverá incluir axe-core, Lighthouse, testes com Playwright, revisão manual de teclado, foco visível, mensagens de erro acessíveis, labels em campos e ausência de dependência exclusiva de cor.

## Q46
<!-- pfq-id: 2d7345d5-2ba4-4e2e-ac3b-457c268ffc1b -->

**Pergunta**: Existe alguma exigência de conformidade com WCAG AA para as interfaces que consumirão os dados?

**Resposta**:

Sim. O MVP deverá cumprir WCAG 2.2 nível AA como referência mínima. O contraste mínimo será de 4,5:1 para texto normal e 3:1 para texto grande, ícones informativos e componentes essenciais. A interface deverá suportar zoom/redimensionamento de texto até 200% sem perda de conteúdo ou funcionalidade. A validação deverá incluir axe-core, Lighthouse, testes com Playwright, revisão manual de teclado, foco visível, mensagens de erro acessíveis, labels em campos e ausência de dependência exclusiva de cor.

## Q47
<!-- pfq-id: 0d0d7aac-3d6e-48aa-9464-b4785c4e2387 -->

**Pergunta**: Quais testes de carga/stress estão previstos para o ambiente local e para os conectores?

**Resposta**:

Para testes de carga do MVP, a premissa inicial será escritório pequeno/médio com 1 a 10 advogados e equipe de apoio, simulando 20 usuários simultâneos por tenant, 100 usuários simultâneos na plataforma, 10.000 processos por tenant, 100.000 documentos por tenant e picos controlados de consultas externas. Os volumes devem ser revisados na Sprint 0 conforme o escritório piloto.

## Q48
<!-- pfq-id: 9162b3ef-c416-4e48-8a10-a79c427ad524 -->

**Pergunta**: Qual será a frequência de execução dos testes de regressão (ex.: a cada commit, diariamente)?

**Resposta**:

O item deverá ser coberto no plano de QA do AJA antes do piloto produtivo, com critério de aceite testável, evidência na pipeline, massa de teste controlada, logs e aprovação do responsável pelo módulo.

## Q49
<!-- pfq-id: 12d846c4-2797-4c2d-b3f4-c7bd2b2ecd1c -->

**Pergunta**: Qual SLA de disponibilidade para os módulos offline e online é esperado?

**Resposta**:

O item deverá ser coberto no plano de QA do AJA antes do piloto produtivo, com critério de aceite testável, evidência na pipeline, massa de teste controlada, logs e aprovação do responsável pelo módulo.

## Q50
<!-- pfq-id: dabc2618-864a-4310-bcfd-c6cbbce83542 -->

**Pergunta**: O time adota práticas de BDD (Gherkin/Cucumber) ou prefere testes baseados em contratos?

**Resposta**:

O item deverá ser coberto no plano de QA do AJA antes do piloto produtivo, com critério de aceite testável, evidência na pipeline, massa de teste controlada, logs e aprovação do responsável pelo módulo.

## Q51
<!-- pfq-id: 3b22846d-ed27-4a4c-8462-9a8b2b662ed1 -->

**Pergunta**: Há plano para validação de acessibilidade (ex.: WCAG AA)?

**Resposta**:

Sim. O MVP deverá cumprir WCAG 2.2 nível AA como referência mínima. O contraste mínimo será de 4,5:1 para texto normal e 3:1 para texto grande, ícones informativos e componentes essenciais. A interface deverá suportar zoom/redimensionamento de texto até 200% sem perda de conteúdo ou funcionalidade. A validação deverá incluir axe-core, Lighthouse, testes com Playwright, revisão manual de teclado, foco visível, mensagens de erro acessíveis, labels em campos e ausência de dependência exclusiva de cor.
