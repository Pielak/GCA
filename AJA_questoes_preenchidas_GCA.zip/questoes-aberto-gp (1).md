---
gca-followup-marker: v1
project_id: 24bf72c3-2ee8-45fd-b879-d3a00b347c39
persona_id: GP
persona_name: Gerente de Projetos
generated_at: 2026-05-05T01:39:10.543335+00:00
question_count: 70
---

# Perguntas em aberto — Gerente de Projetos — Assistente Judicial para Advogados

Preencha as respostas abaixo de cada pergunta (substitua `<sua resposta aqui>`). Faça upload deste arquivo pela aba **Ingestão de Documentos**. NÃO altere as linhas com `<!-- pfq-id: ... -->`.

## Q1
<!-- pfq-id: acd592e6-5c5b-4e6d-9e18-689227c77505 -->

**Pergunta**: Qual o cronograma previsto (datas de início e conclusão de cada fase) e qual a equipe alocada (número de desenvolvedores, especialistas jurídicos)?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q2
<!-- pfq-id: 626bd2a7-8e30-4e8d-9bc2-361e4d14af13 -->

**Pergunta**: Qual o cronograma proposto e a equipe alocada para desenvolvimento e implantação?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q3
<!-- pfq-id: 02363951-b444-4126-8471-14524ffe62d0 -->

**Pergunta**: O encarregado/responsável por privacidade do escritório já foi designado e revisará este RIPD?

**Resposta**:

O responsável de privacidade/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Ele deverá revisar o RIPD, bases legais, retenção, transferência internacional, anonimização para LLM, contratos com operadores/suboperadores e política de incidentes. Sem essa validação, o sistema não deve ir para produção com dados reais.

## Q4
<!-- pfq-id: c08be617-443c-47d9-b392-cc81517e5366 -->

**Pergunta**: Quais são os stakeholders principais (produto, negócio, jurídico, TI) e qual o grau de comprometimento de cada um?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q5
<!-- pfq-id: dddf31a3-cbe7-4424-8a92-c2366161d7d1 -->

**Pergunta**: Quem são os stakeholders e qual o consenso sobre a estratégia de mockagem?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q6
<!-- pfq-id: 2d9eda60-3e22-45b0-94c9-3c3f82deca5f -->

**Pergunta**: Qual é o objetivo do projeto? (ex: sistema de consulta processual, dashboard, integração)

**Resposta**:

O objetivo do AJA é criar uma plataforma multi-tenant de automação jurídica assistida para escritórios de advocacia, apoiando cadastro de casos, controle de processos, gestão de documentos e templates, geração assistida de minutas, gestão de prazos, calculadora judicial, consulta a fontes oficiais, trilha de auditoria, governança de IA, segurança, LGPD e RBAC.

## Q7
<!-- pfq-id: 00dbebee-a973-40cc-a956-10b92f79e899 -->

**Pergunta**: Qual o prazo alvo para o MVP e marcos intermediários?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q8
<!-- pfq-id: f7020bbb-120b-4ab1-88cf-bc57eb07caba -->

**Pergunta**: Who are all project stakeholders beyond the mentioned audience?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q9
<!-- pfq-id: b5024bb0-7a12-4e4b-ad81-5906e30c83e0 -->

**Pergunta**: Qual o cronograma realista para produzir e aprovar a Política de Segurança e os demais artefatos (SoA, plano de continuidade, etc.)?

**Resposta**:

Estratégia de continuidade: cache, fila, circuit breaker, retentativas com backoff, fallback manual, evidência de consulta externa e rollback de configuração. Se um conector falhar, o AJA deve manter o caso operável manualmente, registrar o incidente e impedir decisões automáticas baseadas em dados externos vencidos ou incompletos.

## Q10
<!-- pfq-id: 50078fcd-7a18-44aa-92e6-d88cff6445bb -->

**Pergunta**: Quais são os requisitos funcionais do sistema? Favor classificar os módulos do backlog como functional/non_functional/business_rule.

**Resposta**:

Classificação do backlog: Funcionais: tenant/Admin, usuários/RBAC, casos, processos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos, calculadora, portal LGPD, auditoria e relatórios. Não funcionais: segurança, criptografia, disponibilidade, performance, observabilidade, backup, RPO/RTO, escalabilidade, acessibilidade, testes e isolamento multi-tenant. Regras de negócio: revisão humana obrigatória, IA apenas como minuta/apoio, conflito de interesses, templates aprovados, rate limit/cache, retenção, base legal, fallback manual e bloqueio por orçamento/consumo.

## Q11
<!-- pfq-id: 43a8e2d6-665f-40fc-a30b-31cb08e7bfa1 -->

**Pergunta**: O documento foi revisado e aprovado por um advogado sênior e pelo encarregado de privacidade, conforme orientação no cabeçalho?

**Resposta**:

O responsável de privacidade/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Ele deverá revisar o RIPD, bases legais, retenção, transferência internacional, anonimização para LLM, contratos com operadores/suboperadores e política de incidentes. Sem essa validação, o sistema não deve ir para produção com dados reais.

## Q12
<!-- pfq-id: c487d32b-33cf-4ee9-8ba0-ab8241b7ef6c -->

**Pergunta**: Quem são os representantes (advogado sênior e DPO) que validarão os requisitos e quando essa validação será realizada?

**Resposta**:

O responsável de privacidade/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Ele deverá revisar o RIPD, bases legais, retenção, transferência internacional, anonimização para LLM, contratos com operadores/suboperadores e política de incidentes. Sem essa validação, o sistema não deve ir para produção com dados reais.

## Q13
<!-- pfq-id: 2181c116-334d-4d39-9ea4-fffa4994471d -->

**Pergunta**: Há uma lista final de stakeholders e seus papéis na aprovação do projeto? Quem assina o aceite formal?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q14
<!-- pfq-id: 7ff9ab9e-1202-4e54-a45e-96b5c3a62516 -->

**Pergunta**: Quem são os stakeholders-chave para aprovação e sign-off (advogados responsáveis, gestores do escritório, TI)?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q15
<!-- pfq-id: b4b29802-bff2-463a-9de6-48ec77eaf947 -->

**Pergunta**: A equipe de desenvolvimento possui experiência comprovada com SQLCipher e gestão segura de chaves locais?

**Resposta**:

Equipe mínima recomendada: 1 PO/representante jurídico, 1 gerente de projetos/BA, 1 arquiteto, 2 desenvolvedores backend, 1 desenvolvedor frontend, 1 QA/tester, 1 DevOps/SecOps parcial, 1 advogado sênior curador, 1 responsável de privacidade/DPO e 1 especialista contábil/perito sob demanda para cálculos. Nomes e dedicação real ainda precisam ser definidos antes da Sprint 0.

## Q16
<!-- pfq-id: 42e63bd7-5080-46da-a5fd-099f82c7a62c -->

**Pergunta**: Existe um cronograma com milestones realistas baseado na capacidade da equipe? Se sim, solicitamos apresentação.

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q17
<!-- pfq-id: 15b8c0b6-4de6-4191-93bb-39924558a3c9 -->

**Pergunta**: Qual é a timeline realista para implantação dos mocks e integração com o AJA?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q18
<!-- pfq-id: b614d29f-6293-49b6-aa3f-7e1dbb33d53d -->

**Pergunta**: Quem são os stakeholders principais (cliente, patrocinador, usuários finais)?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q19
<!-- pfq-id: 410c1b23-a6f0-45f7-913e-6037416f7551 -->

**Pergunta**: Quem são os stakeholders específicos (nomes/cargos) que devem aprovar cada etapa?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q20
<!-- pfq-id: 727dcaec-6ee7-44bb-b570-3a69cf1d3b3a -->

**Pergunta**: What is the project timeline and resource plan?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q21
<!-- pfq-id: 8d07f81d-be69-4604-a2d5-5794603b8070 -->

**Pergunta**: Quem serão os responsáveis por cada artefato (sócios, GCA, jurídico)?

**Resposta**:

Resposta de GP consolidada: o item será controlado como decisão de projeto, com dono, prazo, dependência, critério de aceite e status no roadmap. Dados ainda não aprovados, como orçamento, nomes, equipe real, DPO e tribunal piloto, ficam como pendência obrigatória antes da Sprint 0 ou antes do piloto produtivo, conforme risco.

## Q22
<!-- pfq-id: 11ed9801-cacd-4091-bebd-0420aea18d4a -->

**Pergunta**: Quem são os stakeholders principais (além dos papéis canônicos) e há consenso sobre prioridades?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q23
<!-- pfq-id: 344afd38-51ec-45ff-9aa1-ac6f6ba27522 -->

**Pergunta**: Já existe acordo com o tribunal piloto para homologação do PJe/MNI, e qual a expectativa realista de duração?

**Resposta**:

Ainda não há acordo formal com tribunal piloto para PJe/MNI. Estratégia: tratar PJe/MNI como trilha técnica separada, escolher tribunal piloto após validação de viabilidade, abrir solicitação formal/ofício/SEI quando exigido, registrar credenciais, ambiente, versão MNI, certificado e endpoints no Admin. Expectativa realista: 4 a 8 semanas por piloto após obtenção de acesso/homologação.

## Q24
<!-- pfq-id: bc3959e8-1565-4a65-a295-901a579dab5f -->

**Pergunta**: Qual a equipe de desenvolvimento prevista e sua velocidade/experiência com as tecnologias propostas?

**Resposta**:

Equipe mínima recomendada: 1 PO/representante jurídico, 1 gerente de projetos/BA, 1 arquiteto, 2 desenvolvedores backend, 1 desenvolvedor frontend, 1 QA/tester, 1 DevOps/SecOps parcial, 1 advogado sênior curador, 1 responsável de privacidade/DPO e 1 especialista contábil/perito sob demanda para cálculos. Nomes e dedicação real ainda precisam ser definidos antes da Sprint 0.

## Q25
<!-- pfq-id: 2f22a142-045f-4d39-8338-60bed8d519cb -->

**Pergunta**: Quais áreas jurídicas e conectores são considerados obrigatórios para o MVP (Must Have) versus desejáveis (Should/Could Have)?

**Resposta**:

Must Have MVP: áreas cível/contratual, trabalhista e administrativo básico; tenant/RBAC; casos/processos; documentos/templates; LLM Gateway; DataJud; CNA/OAB; BCB/SGS; prazos; calculadora; auditoria; LGPD; repositório documental. Should Have: família, tributário, portal do cliente, PDPJ/DJE. Could Have: criminal, PJe/MNI piloto, IA local, dashboards avançados e conectores privados.

## Q26
<!-- pfq-id: c02fef9a-ba7d-44f7-b873-0f094d263dbb -->

**Pergunta**: Como será a integração com o dossiê eletrônico existente? Existem APIs ou bases definidas?

**Resposta**:

O modelo de dados previsto inclui tenants, usuários, papéis, clientes, casos, processos, documentos, templates, contratos de integração, eventos de integração, uso de IA, prazos, cálculos, solicitações LGPD e auditoria. Dossiê eletrônico existente, se houver, será integrado por importação controlada/API ou carga inicial com mapeamento de campos, hash de documentos, metadados e permissões. Fluxos com IA passam obrigatoriamente pelo LLM Gateway com anonimização, log, custo e revisão humana.

## Q27
<!-- pfq-id: 9c763411-7be2-4250-938c-729248c3a0cd -->

**Pergunta**: O cronograma do MVP e os recursos (orçamento, desenvolvedores) já estão aprovados para iniciar as sprints de fundação?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q28
<!-- pfq-id: c96654be-f400-46bf-9476-165d0027279b -->

**Pergunta**: Qual o orçamento aprovado e a expectativa de retorno (ROI) para justificar o investimento?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q29
<!-- pfq-id: 615eea77-3484-4d06-a4c3-835997f8153a -->

**Pergunta**: Há orçamento aprovado para este complemento técnico?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q30
<!-- pfq-id: 0728a69c-3028-435e-b588-1d2aba4383f6 -->

**Pergunta**: Qual o cronograma previsto e equipe alocada?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q31
<!-- pfq-id: b6bbb646-e2aa-4895-8ab5-b8493c6737e3 -->

**Pergunta**: Qual stack tecnológica prevista (linguagens, frameworks, bibliotecas de criptografia, banco de dados local)?

**Resposta**:

Stack proposta: frontend React/TypeScript; backend Python FastAPI; banco PostgreSQL; cache Redis; storage S3/MinIO; filas Celery/RQ ou equivalente; LLM Gateway; integrações via adapters; Docker para empacotamento; GitHub Actions para CI/CD. Para cache/local offline, quando necessário, usar SQLite + SQLCipher. A capacidade da equipe com SQLCipher, cofre de segredos e criptografia deve ser confirmada na Sprint 0.

## Q32
<!-- pfq-id: a0fbfd1d-773e-42b4-9306-bb0eaafad818 -->

**Pergunta**: What is the technical stack and does the team have the required capabilities?

**Resposta**:

Stack proposta: frontend React/TypeScript; backend Python FastAPI; banco PostgreSQL; cache Redis; storage S3/MinIO; filas Celery/RQ ou equivalente; LLM Gateway; integrações via adapters; Docker para empacotamento; GitHub Actions para CI/CD. Para cache/local offline, quando necessário, usar SQLite + SQLCipher. A capacidade da equipe com SQLCipher, cofre de segredos e criptografia deve ser confirmada na Sprint 0.

## Q33
<!-- pfq-id: 4244a65f-6e46-4a5b-979e-34aa3b6b7655 -->

**Pergunta**: A direção está ciente e disposta a aprovar os documentos necessários antes do piloto produtivo?

**Resposta**:

Stakeholders principais: patrocinador/direção, sócio gestor jurídico, advogado sênior, PO, usuários advogados, paralegais, estagiários, financeiro, TI/DevOps, segurança, DPO/responsável de privacidade, QA, suporte e clientes externos quando houver portal. O sign-off de negócio deve ser assinado pelo patrocinador/sócio gestor; o sign-off jurídico por advogado sênior; o sign-off LGPD pelo DPO/responsável de privacidade; o sign-off técnico pelo arquiteto/tech lead; e o aceite de operação pelo gerente do projeto.

## Q34
<!-- pfq-id: 7c2970e3-a2cf-4e1e-9766-9c4d0c2928c0 -->

**Pergunta**: Qual é a expectativa de timeline para as fases MVP, v1.0 e futuras?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q35
<!-- pfq-id: d0c64dd3-5c03-474b-aef9-7a9c9ddf34b3 -->

**Pergunta**: Qual é a composição prevista da equipe de desenvolvimento (quantidade e perfis) para as fases?

**Resposta**:

Cronograma proposto a partir do aceite formal do projeto: Fase 0/Fundação e governança: 2 a 4 semanas; MVP 1/Núcleo operacional (tenant, RBAC, casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora): 8 a 12 semanas; MVP 2/Integrações judiciais avançadas (PDPJ/DJE, eventos, comunicações e fallback): 6 a 10 semanas; Piloto PJe/MNI por tribunal: 4 a 8 semanas por tribunal, condicionado a credenciamento/homologação. Datas exatas dependem da aprovação de orçamento, equipe e tribunal piloto.

## Q36
<!-- pfq-id: 812315c3-98ca-4407-88a1-0bc2f41224ba -->

**Pergunta**: Existe uma expectativa de ROI quantificada (ex.: redução de horas/peça, economia anual) aprovada pelo negócio?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q37
<!-- pfq-id: fd946b3e-2e5a-430f-9c34-81e4f15048d3 -->

**Pergunta**: Foi realizada uma validação jurídica independente para garantir que funcionalidades como 'pesquisa assistida' e 'revisão humana' atendem integralmente ao Estatuto da OAB e resoluções do CNJ?

**Resposta**:

Ainda não há evidência de aprovação formal por advogado sênior, DPO ou consultoria jurídica independente. A validação é requisito obrigatório antes do piloto produtivo, especialmente para uso de IA, geração de peças, sigilo profissional, LGPD, revisão humana, prazos, cálculos e integrações judiciais.

## Q38
<!-- pfq-id: 9c63a5dd-7011-4e28-9e6f-db20996e11f1 -->

**Pergunta**: Existe orçamento aprovado para o módulo, incluindo acesso a fontes de dados pagas?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q39
<!-- pfq-id: 7d765d30-75db-4515-b4aa-57955b23851f -->

**Pergunta**: Como será tratada a dependência de APIs privadas? Há acordos de acesso ou previsão de substituição por fontes alternativas?

**Resposta**:

Resposta de GP consolidada: o item será controlado como decisão de projeto, com dono, prazo, dependência, critério de aceite e status no roadmap. Dados ainda não aprovados, como orçamento, nomes, equipe real, DPO e tribunal piloto, ficam como pendência obrigatória antes da Sprint 0 ou antes do piloto produtivo, conforme risco.

## Q40
<!-- pfq-id: 62898956-bbee-438c-a349-a51029ab5e4f -->

**Pergunta**: Os responsáveis pela segurança/LGPD validaram o uso de dados sintéticos nesses moldes?

**Resposta**:

O responsável de privacidade/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Ele deverá revisar o RIPD, bases legais, retenção, transferência internacional, anonimização para LLM, contratos com operadores/suboperadores e política de incidentes. Sem essa validação, o sistema não deve ir para produção com dados reais.

## Q41
<!-- pfq-id: fcfc7ed4-d777-4582-b653-53b1f436c7ea -->

**Pergunta**: Há requisitos de segurança, autenticação na API? (a API é pública, mas o projeto pode precisar de chaves?)

**Resposta**:

Resposta de GP consolidada: o item será controlado como decisão de projeto, com dono, prazo, dependência, critério de aceite e status no roadmap. Dados ainda não aprovados, como orçamento, nomes, equipe real, DPO e tribunal piloto, ficam como pendência obrigatória antes da Sprint 0 ou antes do piloto produtivo, conforme risco.

## Q42
<!-- pfq-id: 4757a451-b0d4-4cbe-ba2f-58fc9bece044 -->

**Pergunta**: Existe um documento separado com casos de uso e jornadas de usuário que complementem estes requisitos?

**Resposta**:

Resposta de GP consolidada: o item será controlado como decisão de projeto, com dono, prazo, dependência, critério de aceite e status no roadmap. Dados ainda não aprovados, como orçamento, nomes, equipe real, DPO e tribunal piloto, ficam como pendência obrigatória antes da Sprint 0 ou antes do piloto produtivo, conforme risco.

## Q43
<!-- pfq-id: c25e2f6e-9854-493a-b812-ebf68e423572 -->

**Pergunta**: Have legal and compliance risks been assessed, especially regarding AI-generated legal documents?

**Resposta**:

Resposta de GP consolidada: o item será controlado como decisão de projeto, com dono, prazo, dependência, critério de aceite e status no roadmap. Dados ainda não aprovados, como orçamento, nomes, equipe real, DPO e tribunal piloto, ficam como pendência obrigatória antes da Sprint 0 ou antes do piloto produtivo, conforme risco.

## Q44
<!-- pfq-id: c47c8986-07da-4c88-a772-8a3584603973 -->

**Pergunta**: Existe orçamento ou recursos alocados para implementar os controles de governança faltantes?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q45
<!-- pfq-id: 07a91314-0599-43d9-89c6-024411a519cd -->

**Pergunta**: Quais são os recursos humanos e orçamento disponíveis?

**Resposta**:

Equipe mínima recomendada: 1 PO/representante jurídico, 1 gerente de projetos/BA, 1 arquiteto, 2 desenvolvedores backend, 1 desenvolvedor frontend, 1 QA/tester, 1 DevOps/SecOps parcial, 1 advogado sênior curador, 1 responsável de privacidade/DPO e 1 especialista contábil/perito sob demanda para cálculos. Nomes e dedicação real ainda precisam ser definidos antes da Sprint 0.

## Q46
<!-- pfq-id: 62d1fbf9-23ce-4090-a4d0-2e1b20d0791b -->

**Pergunta**: O orçamento para consumo de LLM foi aprovado pelo escritório/área financeira? Há teto mensal definido?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q47
<!-- pfq-id: a71b6e00-a601-491c-adfc-38cf93369798 -->

**Pergunta**: Há um orçamento total aprovado e quais são os limites de investimento para cada fase?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q48
<!-- pfq-id: 1c9c56e6-8eb5-4d68-b9bd-fd452987db21 -->

**Pergunta**: Qual a estratégia para conectores cuja API não está disponível ou exige convênio (ex.: MNI, PJe/MNI)? O fallback manual é suficiente para os objetivos de negócio?

**Resposta**:

Conectores sem API disponível ou que exigem convênio serão tratados em três níveis: mock/contrato sintético para desenvolvimento, fallback manual para operação do MVP e trilha de credenciamento/homologação para produção. Para PJe/MNI e integrações dependentes de tribunal, o item só será considerado concluído após aceite formal do órgão/tribunal ou decisão de excluir do escopo produtivo.

## Q49
<!-- pfq-id: 73f6384e-f1f7-4c01-91f2-2abf715456f8 -->

**Pergunta**: Como serão validadas juridicamente as fórmulas e regras em múltiplas jurisdições? Há consultoria jurídica dedicada?

**Resposta**:

Fórmulas, prazos e regras em múltiplas jurisdições deverão ser validados por advogado responsável e, quando envolver valores, por contador/perito parceiro. Cada regra terá fonte normativa, versão, vigência, UF/tribunal aplicável, casos de teste e memória de cálculo. Divergência entre jurisdições deve exigir seleção explícita do tribunal/UF e revisão humana.

## Q50
<!-- pfq-id: 5f6abf49-e852-4503-be61-d18f51a4234e -->

**Pergunta**: Qual a estratégia de rollback e continuidade do negócio em caso de falhas nos conectores externos?

**Resposta**:

Estratégia de continuidade: cache, fila, circuit breaker, retentativas com backoff, fallback manual, evidência de consulta externa e rollback de configuração. Se um conector falhar, o AJA deve manter o caso operável manualmente, registrar o incidente e impedir decisões automáticas baseadas em dados externos vencidos ou incompletos.

## Q51
<!-- pfq-id: 9c48449c-22b6-4b16-a9dd-897ea47f2ed0 -->

**Pergunta**: Como será feito o monitoramento de alterações nas fontes oficiais para manter contratos e mocks atualizados?

**Resposta**:

A estratégia de mockagem será usar contratos sintéticos baseados na documentação oficial e fixtures anonimizadas, sem PII real. Os mocks cobrirão DataJud, CNA/OAB, BCB/SGS, LLM e, em fase posterior, PDPJ/DJE e PJe/MNI. Consenso esperado: mocks servem para desenvolvimento e testes automatizados, mas não substituem homologação com credenciais reais antes de produção.

## Q52
<!-- pfq-id: a8787d16-d73e-457b-ba41-07988a11c5c3 -->

**Pergunta**: Qual o modelo de dados que o sistema irá manusear? Apenas consultar endpoints e exibir dados?

**Resposta**:

O modelo de dados planejado não será apenas consulta e exibição de endpoints. O AJA manipulará tenants, usuários, papéis, clientes, casos, processos, documentos, templates, contratos de integração, eventos de integração, uso de IA, prazos, cálculos, solicitações LGPD e auditoria. Integrações externas alimentarão metadados rastreáveis, sem substituir validação humana quando houver impacto jurídico.

## Q53
<!-- pfq-id: 3d6d8005-be65-4309-9cf5-7c9b3fec4d44 -->

**Pergunta**: Há requisitos de certificação (ex: OAB, normas de segurança) que impactem o escopo?

**Resposta**:

Não há requisito geral de certificação OAB identificado para o produto AJA. O escopo deve observar Estatuto/Código de Ética da OAB, LGPD, sigilo profissional e regras de cada integração judicial. ISO 27001 pode ser usada como referência de segurança, mas certificação formal não é requisito obrigatório do MVP, salvo decisão comercial/regulatória futura.

## Q54
<!-- pfq-id: d97e7901-7387-4d9c-9b57-f112a25ce165 -->

**Pergunta**: What is the acceptance testing strategy?

**Resposta**:

Estratégia de aceite: testes unitários, integração, contrato, e2e, segurança, carga, RBAC, anonimização, prazos, cálculos, templates e regressão. Antes de produção, executar SAST, DAST, revisão de dependências, teste de restauração de backup, teste de isolamento multi-tenant e pentest independente com escopo mínimo: autenticação, autorização, tenants, APIs, upload/download de documentos, LLM Gateway e cofre de segredos.

## Q55
<!-- pfq-id: 10325fcd-de5c-496f-9695-ec8759c04df5 -->

**Pergunta**: Como será validada a eficácia dos controles técnicos (testes de penetração, auditoria de código) antes da produção?

**Resposta**:

Estratégia de aceite: testes unitários, integração, contrato, e2e, segurança, carga, RBAC, anonimização, prazos, cálculos, templates e regressão. Antes de produção, executar SAST, DAST, revisão de dependências, teste de restauração de backup, teste de isolamento multi-tenant e pentest independente com escopo mínimo: autenticação, autorização, tenants, APIs, upload/download de documentos, LLM Gateway e cofre de segredos.

## Q56
<!-- pfq-id: a5caf7b4-4549-435b-9d1a-bc5af2f76568 -->

**Pergunta**: Qual é o modelo de dados planejado e os principais fluxos de integração com IA?

**Resposta**:

O modelo de dados planejado não será apenas consulta e exibição de endpoints. O AJA manipulará tenants, usuários, papéis, clientes, casos, processos, documentos, templates, contratos de integração, eventos de integração, uso de IA, prazos, cálculos, solicitações LGPD e auditoria. Integrações externas alimentarão metadados rastreáveis, sem substituir validação humana quando houver impacto jurídico.

## Q57
<!-- pfq-id: 09f2a1ff-63de-49e0-b218-3eaae3dc5aa4 -->

**Pergunta**: Há algum alinhamento prévio com os provedores das APIs (DataJud, PDPJ, etc.) quanto a credenciamento e limites de uso em produção?

**Resposta**:

Ainda não há alinhamento formal comprovado com provedores/órgãos para todas as APIs. DataJud/BCB/CNA podem ser tratados inicialmente como fontes públicas/consultáveis; PDPJ/DJE e PJe/MNI exigem credenciamento/homologação conforme serviço. A pendência deve constar no roadmap e bloquear aceite produtivo do conector quando houver dependência formal.

## Q58
<!-- pfq-id: a5580a9b-2a4d-48e2-a086-b002052d96f0 -->

**Pergunta**: Qual tribunal será escolhido como piloto para a integração PJe/MNI?

**Resposta**:

Ainda não há acordo formal com tribunal piloto para PJe/MNI. Estratégia: tratar PJe/MNI como trilha técnica separada, escolher tribunal piloto após validação de viabilidade, abrir solicitação formal/ofício/SEI quando exigido, registrar credenciais, ambiente, versão MNI, certificado e endpoints no Admin. Expectativa realista: 4 a 8 semanas por piloto após obtenção de acesso/homologação.

## Q59
<!-- pfq-id: 8377956a-724e-4c0d-9299-bcd1aafc8852 -->

**Pergunta**: Os módulos financeiros e de portal do cliente são previstos para curto prazo ou podem ser postergados sem impacto nos indicadores de negócio (ON-04)?

**Resposta**:

Módulos financeiros e portal do cliente podem ser postergados se não forem necessários aos indicadores de MVP. Para o MVP, financeiro deve limitar-se a controle de custos/consumo do AJA. Portal do cliente é Should Have, não Must Have, salvo se o escritório definir atendimento externo como objetivo central do piloto.

## Q60
<!-- pfq-id: 04cfc4ae-b193-405b-a3ab-f9716203d0c1 -->

**Pergunta**: Como lidaremos com fontes de índices que mudam de formato (PDF, HTML) ou ficam indisponíveis?

**Resposta**:

Para índices, priorizar APIs/fontes oficiais estruturadas, especialmente BCB/SGS quando aplicável. Se a fonte mudar de formato, ficar indisponível ou exigir PDF/HTML, o sistema deve usar último cache válido, marcar cálculo como pendente de validação, permitir input manual com evidência e impedir uso automático sem revisão jurídica/contábil.

## Q61
<!-- pfq-id: 2391c20f-96ad-4437-8664-af4f53382ac6 -->

**Pergunta**: Qual a estratégia de teste (testes de integração, carga, etc.)?

**Resposta**:

Estratégia de aceite: testes unitários, integração, contrato, e2e, segurança, carga, RBAC, anonimização, prazos, cálculos, templates e regressão. Antes de produção, executar SAST, DAST, revisão de dependências, teste de restauração de backup, teste de isolamento multi-tenant e pentest independente com escopo mínimo: autenticação, autorização, tenants, APIs, upload/download de documentos, LLM Gateway e cofre de segredos.

## Q62
<!-- pfq-id: 006008c0-19d6-4f5f-96d1-72af24dc8f61 -->

**Pergunta**: Qual a estimativa de custos e tamanho da equipe para cada fase?

**Resposta**:

Equipe mínima recomendada: 1 PO/representante jurídico, 1 gerente de projetos/BA, 1 arquiteto, 2 desenvolvedores backend, 1 desenvolvedor frontend, 1 QA/tester, 1 DevOps/SecOps parcial, 1 advogado sênior curador, 1 responsável de privacidade/DPO e 1 especialista contábil/perito sob demanda para cálculos. Nomes e dedicação real ainda precisam ser definidos antes da Sprint 0.

## Q63
<!-- pfq-id: eb2a1a69-eee6-4229-900e-309e0e583479 -->

**Pergunta**: How will user onboarding and training be handled?

**Resposta**:

O onboarding terá trilhas por papel: administrador, sócio/gestor, advogado, paralegal, estagiário, financeiro e DPO. Conteúdo: uso do AJA, templates, revisão humana, IA, LGPD, sigilo profissional, prazos, cálculos, incidentes, fallback manual e boas práticas de segurança. Deve haver aceite da política de uso e checklist de capacitação antes de liberar produção.

## Q64
<!-- pfq-id: 4c9da381-c0ab-4992-aeb5-45d2fffd01a7 -->

**Pergunta**: Quais são os testes de aceitação esperados para cada entrega?

**Resposta**:

Estratégia de aceite: testes unitários, integração, contrato, e2e, segurança, carga, RBAC, anonimização, prazos, cálculos, templates e regressão. Antes de produção, executar SAST, DAST, revisão de dependências, teste de restauração de backup, teste de isolamento multi-tenant e pentest independente com escopo mínimo: autenticação, autorização, tenants, APIs, upload/download de documentos, LLM Gateway e cofre de segredos.

## Q65
<!-- pfq-id: 1bb1bfc4-b210-4ad0-a164-2c8172665c7d -->

**Pergunta**: O catálogo inicial de templates será curado por quem e em qual prazo? Já existe conteúdo pré-existente?

**Resposta**:

Resposta de GP consolidada: o item será controlado como decisão de projeto, com dono, prazo, dependência, critério de aceite e status no roadmap. Dados ainda não aprovados, como orçamento, nomes, equipe real, DPO e tribunal piloto, ficam como pendência obrigatória antes da Sprint 0 ou antes do piloto produtivo, conforme risco.

## Q66
<!-- pfq-id: b63854b9-de43-42a3-b570-4afc7058c1e7 -->

**Pergunta**: Como o projeto lidará com indisponibilidade prolongada de uma API externa (fallback manual, alternativa de consulta)?

**Resposta**:

A continuidade será garantida por cache, fila, circuit breaker, retentativas com backoff, fallback manual, registro de evidências e plano de rollback. Se DataJud/PDPJ/MNI/BCB/CNA ficarem indisponíveis, o AJA deverá informar status da fonte, usar último cache válido quando permitido, permitir lançamento manual e bloquear decisões automáticas baseadas em dado vencido.

## Q67
<!-- pfq-id: e08d957e-e165-4c64-bbec-2451ce647fdc -->

**Pergunta**: Existe análise de viabilidade técnica e de negócio? Qual o ROI esperado?

**Resposta**:

O orçamento ainda não está formalmente aprovado. Para planejamento, separar custos por fase: desenvolvimento, infraestrutura, LLM, storage, observabilidade, segurança/pentest, certificação/assinatura de código, certificados digitais, curadoria jurídica de templates, DPO/LGPD e eventual integração privada/convênio. ROI esperado: redução de horas por peça, redução de retrabalho, redução de risco operacional e maior rastreabilidade; a linha de base deve ser medida no piloto.

## Q68
<!-- pfq-id: 4f66e3b2-dc30-499c-995f-7b7bb43eb660 -->

**Pergunta**: Como será tratada a evolução do modelo de IA e a manutenção dos índices de cálculo?

**Resposta**:

Resposta de GP consolidada: o item será controlado como decisão de projeto, com dono, prazo, dependência, critério de aceite e status no roadmap. Dados ainda não aprovados, como orçamento, nomes, equipe real, DPO e tribunal piloto, ficam como pendência obrigatória antes da Sprint 0 ou antes do piloto produtivo, conforme risco.

## Q69
<!-- pfq-id: efc053b9-c073-4d91-b1cf-c32ff018abcf -->

**Pergunta**: Os requisitos de LGPD e sigilo profissional já foram revisados e aprovados por um DPO ou consultor jurídico?

**Resposta**:

O responsável de privacidade/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Ele deverá revisar o RIPD, bases legais, retenção, transferência internacional, anonimização para LLM, contratos com operadores/suboperadores e política de incidentes. Sem essa validação, o sistema não deve ir para produção com dados reais.

## Q70
<!-- pfq-id: 029e553f-19c7-4d3e-9037-df17424110cb -->

**Pergunta**: Já foram realizadas provas de conceito para os conectores críticos (DataJud, PJe, etc.)?

**Resposta**:

Must Have MVP: áreas cível/contratual, trabalhista e administrativo básico; tenant/RBAC; casos/processos; documentos/templates; LLM Gateway; DataJud; CNA/OAB; BCB/SGS; prazos; calculadora; auditoria; LGPD; repositório documental. Should Have: família, tributário, portal do cliente, PDPJ/DJE. Could Have: criminal, PJe/MNI piloto, IA local, dashboards avançados e conectores privados.


---
