---
gca-followup-marker: v1
project_id: 24bf72c3-2ee8-45fd-b879-d3a00b347c39
persona_id: NEG
persona_name: Negócio
generated_at: 2026-05-05T01:39:15.347881+00:00
question_count: 51
---

# Perguntas em aberto — Negócio — Assistente Judicial para Advogados

Preencha as respostas abaixo de cada pergunta (substitua `<sua resposta aqui>`). Faça upload deste arquivo pela aba **Ingestão de Documentos**. NÃO altere as linhas com `<!-- pfq-id: ... -->`.

## Q1
<!-- pfq-id: ba388b20-08f0-4c5c-bfe2-93b48e0b6119 -->

**Pergunta**: Quais técnicas de elicitação foram aplicadas (entrevistas, workshops, análise documental etc.) e como os resultados foram confirmados com as fontes? (KA 4)

**Resposta**:

Foram consideradas como técnicas de elicitação: análise documental dos cadernos técnicos e requisitos já produzidos para o AJA, análise de fontes oficiais públicas (CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB, BCB/SGS, LGPD/ANPD e recomendações da OAB sobre IA), benchmark funcional de soluções jurídicas, decomposição de jornadas do escritório, análise de riscos, levantamento de personas e validação iterativa com o patrocinador do projeto. A confirmação formal com as fontes de negócio ainda deve ocorrer por workshop de validação com advogado sênior, responsável de privacidade/DPO e representante técnico antes do piloto produtivo.

## Q2
<!-- pfq-id: 6d732a54-5ab7-4526-bb26-b0b6e40c042c -->

**Pergunta**: Quais técnicas de elicitação (BABOK §10) foram utilizadas para levantar a necessidade deste caderno técnico?

**Resposta**:

Foram consideradas como técnicas de elicitação: análise documental dos cadernos técnicos e requisitos já produzidos para o AJA, análise de fontes oficiais públicas (CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB, BCB/SGS, LGPD/ANPD e recomendações da OAB sobre IA), benchmark funcional de soluções jurídicas, decomposição de jornadas do escritório, análise de riscos, levantamento de personas e validação iterativa com o patrocinador do projeto. A confirmação formal com as fontes de negócio ainda deve ocorrer por workshop de validação com advogado sênior, responsável de privacidade/DPO e representante técnico antes do piloto produtivo.

## Q3
<!-- pfq-id: a85ef621-5ce3-4cbe-aab8-a1412f6908b7 -->

**Pergunta**: Quais técnicas de elicitação foram aplicadas (BABOK §10): entrevistas com advogados, observação de rotinas, análise de documentos existentes?

**Resposta**:

Foram consideradas como técnicas de elicitação: análise documental dos cadernos técnicos e requisitos já produzidos para o AJA, análise de fontes oficiais públicas (CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB, BCB/SGS, LGPD/ANPD e recomendações da OAB sobre IA), benchmark funcional de soluções jurídicas, decomposição de jornadas do escritório, análise de riscos, levantamento de personas e validação iterativa com o patrocinador do projeto. A confirmação formal com as fontes de negócio ainda deve ocorrer por workshop de validação com advogado sênior, responsável de privacidade/DPO e representante técnico antes do piloto produtivo.

## Q4
<!-- pfq-id: 7fee300a-445c-4eee-b43b-d635d3171198 -->

**Pergunta**: Quais técnicas de elicitação foram aplicadas para levantar os riscos e derivar requisitos (BABOK §10)?

**Resposta**:

Foram consideradas como técnicas de elicitação: análise documental dos cadernos técnicos e requisitos já produzidos para o AJA, análise de fontes oficiais públicas (CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB, BCB/SGS, LGPD/ANPD e recomendações da OAB sobre IA), benchmark funcional de soluções jurídicas, decomposição de jornadas do escritório, análise de riscos, levantamento de personas e validação iterativa com o patrocinador do projeto. A confirmação formal com as fontes de negócio ainda deve ocorrer por workshop de validação com advogado sênior, responsável de privacidade/DPO e representante técnico antes do piloto produtivo.

## Q5
<!-- pfq-id: 2163bd4f-f9b5-4546-9526-4948c16c4b78 -->

**Pergunta**: Quais técnicas de elicitação foram aplicadas (BABOK §10)? Ex: entrevistas, observação, workshops, document analysis?

**Resposta**:

Foram consideradas como técnicas de elicitação: análise documental dos cadernos técnicos e requisitos já produzidos para o AJA, análise de fontes oficiais públicas (CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB, BCB/SGS, LGPD/ANPD e recomendações da OAB sobre IA), benchmark funcional de soluções jurídicas, decomposição de jornadas do escritório, análise de riscos, levantamento de personas e validação iterativa com o patrocinador do projeto. A confirmação formal com as fontes de negócio ainda deve ocorrer por workshop de validação com advogado sênior, responsável de privacidade/DPO e representante técnico antes do piloto produtivo.

## Q6
<!-- pfq-id: 43f60818-1ecf-4208-a8d8-f015152e89ec -->

**Pergunta**: Quais técnicas de elicitação foram aplicadas para levantar os requisitos do AJA (BABOK §10)?

**Resposta**:

Foram consideradas como técnicas de elicitação: análise documental dos cadernos técnicos e requisitos já produzidos para o AJA, análise de fontes oficiais públicas (CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB, BCB/SGS, LGPD/ANPD e recomendações da OAB sobre IA), benchmark funcional de soluções jurídicas, decomposição de jornadas do escritório, análise de riscos, levantamento de personas e validação iterativa com o patrocinador do projeto. A confirmação formal com as fontes de negócio ainda deve ocorrer por workshop de validação com advogado sênior, responsável de privacidade/DPO e representante técnico antes do piloto produtivo.

## Q7
<!-- pfq-id: 3375c1ac-4474-4655-93dc-b67d556713e0 -->

**Pergunta**: Onde está a matriz de rastreabilidade completa, vinculando cada requisito a objetivos de negócio, fontes, riscos e critérios de aceitação (KA 5 §5.2)?

**Resposta**:

A matriz de rastreabilidade deverá ser mantida como artefato obrigatório do GCA, vinculando cada requisito a objetivo de negócio, fonte de elicitação, stakeholder, risco, critério de aceite, módulo, prioridade e evidência de teste. No estado atual, a rastreabilidade está parcialmente representada pelos IDs de requisitos, critérios de aceite, papéis e integrações documentados; antes do piloto produtivo, deve ser consolidada em tabela específica ou backlog rastreável no GCA/JIRA.

## Q8
<!-- pfq-id: 086cc080-6d55-4cb7-a08e-7fb81be151f1 -->

**Pergunta**: Quem são os stakeholders além dos perfis de acesso? Qual o plano de engajamento, comunicação e matriz de poder/interesse? (KA 3)

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q9
<!-- pfq-id: 3d14646b-af2d-4b94-aa12-4adf5df41421 -->

**Pergunta**: Quem são os stakeholders chave e qual o plano de engajamento (RACI ou matriz de poder/interesse) para este projeto (KA 3)?

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q10
<!-- pfq-id: 7c241746-8da6-41fe-ba8e-90ae6494f01a -->

**Pergunta**: Quem são os stakeholders além dos usuários finais? Existe um plano de engajamento com OAB, CNJ, escritórios, desenvolvedores (KA 3)?

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q11
<!-- pfq-id: 72840e32-e29e-4528-9ab9-0ac88383a87a -->

**Pergunta**: Quem são os stakeholders chave além dos papéis no RACI, e qual o plano de engajamento contínuo (KA 3)?

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q12
<!-- pfq-id: 66a81472-a2ae-4e05-9dcc-6eb8d77b4e4a -->

**Pergunta**: Quem são os stakeholders e qual o plano de engajamento (KA 3)? Como foram classificados e como serão envolvidos na validação?

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q13
<!-- pfq-id: 219d06a1-affb-4670-8c7d-74708303c8ef -->

**Pergunta**: Quem são os stakeholders do projeto e qual o plano de engajamento (KA 3)?

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q14
<!-- pfq-id: 391ff35a-9a44-4ff8-9f91-7ac847c795ce -->

**Pergunta**: Quando será realizada a confirmação formal das elicitações por meio de workshop com advogado sênior, DPO e representante técnico (KA 4 §4.3.2)?

**Resposta**:

Para o AJA, este item deve ser tratado como requisito de negócio a ser formalizado no GCA com responsável, prioridade, critério de aceite, risco associado e evidência. Quando depender de decisão externa ou aprovação formal, a resposta deve permanecer como pendente antes do piloto produtivo, sem bloquear a especificação do MVP desde que exista fallback manual.

## Q15
<!-- pfq-id: 3f3cf6ae-c5df-4a3b-9035-5a6f263b66cc -->

**Pergunta**: Onde está a matriz de rastreabilidade que liga cada requisito aos objetivos de negócio, fontes de elicitação, riscos e critérios de aceitação? (KA 5)

**Resposta**:

Foram consideradas como técnicas de elicitação: análise documental dos cadernos técnicos e requisitos já produzidos para o AJA, análise de fontes oficiais públicas (CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB, BCB/SGS, LGPD/ANPD e recomendações da OAB sobre IA), benchmark funcional de soluções jurídicas, decomposição de jornadas do escritório, análise de riscos, levantamento de personas e validação iterativa com o patrocinador do projeto. A confirmação formal com as fontes de negócio ainda deve ocorrer por workshop de validação com advogado sênior, responsável de privacidade/DPO e representante técnico antes do piloto produtivo.

## Q16
<!-- pfq-id: d9a732eb-4863-4eda-a96e-c3fc0f6a88e4 -->

**Pergunta**: Onde está a matriz de rastreabilidade (KA 5) que vincula cada história técnica a requisitos de negócio da Especificação Técnica de Integrações e UX v3.0?

**Resposta**:

A matriz de rastreabilidade deverá ser mantida como artefato obrigatório do GCA, vinculando: ID do requisito, objetivo de negócio, fonte de elicitação, stakeholder responsável, risco associado, requisito funcional/não funcional/regra de negócio, critério de aceite, caso de teste, status e versão. No documento consolidado, essa rastreabilidade está parcialmente estruturada pelas seções de requisitos negociais, funcionais, não funcionais, integrações, segurança/LGPD, dados e critérios de aceite. Para fechamento definitivo do item, recomenda-se gerar a planilha/matriz RTM em formato tabular antes da Sprint 0.

## Q17
<!-- pfq-id: 720bc506-37fb-4048-a754-1c8b46a5e40e -->

**Pergunta**: Onde está a matriz de rastreabilidade (KA 5) que liga cada requisito funcional a objetivos de negócio, stakeholders e critérios de aceite?

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q18
<!-- pfq-id: ae9624f1-af80-4c18-a17c-e29be1cf3fb5 -->

**Pergunta**: Onde estão os critérios de aceitação específicos para cada requisito RQP-RSK (KA 7)?

**Resposta**:

Cada requisito deverá ter critérios de aceite no padrão: dado/contexto, quando/ação, então/resultado esperado, evidência de teste e responsável pelo aceite. Exemplos mínimos: usuário sem permissão não acessa caso protegido; peça gerada por IA permanece como minuta até aprovação de advogado; consulta externa exibe fonte, data/hora, status e cache; prazo calculado exibe memória de cálculo; dados pessoais não são enviados a LLM externo sem anonimização/pseudonimização; falha de integração aciona fallback manual. Esses critérios serão detalhados no backlog por ID de requisito e vinculados aos casos de teste.

## Q19
<!-- pfq-id: f5e89d0e-0ad2-4c73-9115-95e65085bb04 -->

**Pergunta**: Onde está a matriz de rastreabilidade que vincula cada template (AJA-CIV-xxx) aos objetivos de negócio, riscos e critérios de aceitação (KA 5)?

**Resposta**:

A matriz de rastreabilidade deverá ser mantida como artefato obrigatório do GCA, vinculando: ID do requisito, objetivo de negócio, fonte de elicitação, stakeholder responsável, risco associado, requisito funcional/não funcional/regra de negócio, critério de aceite, caso de teste, status e versão. No documento consolidado, essa rastreabilidade está parcialmente estruturada pelas seções de requisitos negociais, funcionais, não funcionais, integrações, segurança/LGPD, dados e critérios de aceite. Para fechamento definitivo do item, recomenda-se gerar a planilha/matriz RTM em formato tabular antes da Sprint 0.

## Q20
<!-- pfq-id: 467dcdc9-328d-4d71-81e4-b12d481ea765 -->

**Pergunta**: Onde está a especificação formal de requisitos, com IDs únicos, descrições não ambíguas e critérios de aceitação (KA 7)?

**Resposta**:

Cada requisito deverá ter critérios de aceite no padrão: dado/contexto, quando/ação, então/resultado esperado, evidência de teste e responsável pelo aceite. Exemplos mínimos: usuário sem permissão não acessa caso protegido; peça gerada por IA permanece como minuta até aprovação de advogado; consulta externa exibe fonte, data/hora, status e cache; prazo calculado exibe memória de cálculo; dados pessoais não são enviados a LLM externo sem anonimização/pseudonimização; falha de integração aciona fallback manual. Esses critérios serão detalhados no backlog por ID de requisito e vinculados aos casos de teste.

## Q21
<!-- pfq-id: 3a99771a-3d5b-415d-9120-d22a1aa4f84a -->

**Pergunta**: Quais são os IDs únicos de cada requisito e sua especificação completa com descrição não ambígua e critérios de aceitação testáveis (KA 7 §7.3, §7.4)?

**Resposta**:

Os critérios de aceitação devem ser definidos por requisito, em formato testável: perfil autorizado, pré-condição, ação, resultado esperado, evidência gerada, log de auditoria, tratamento de erro e regra de segurança/LGPD aplicável. Para requisitos já especificados, os critérios constam nas seções de RF/RNF/RN; lacunas remanescentes devem ser convertidas em critérios Given/When/Then no backlog do GCA antes da Sprint de implementação.

## Q22
<!-- pfq-id: 88f7abb6-ca6a-4866-ac0b-d6d367311916 -->

**Pergunta**: Qual é exatamente o estado atual (as‑is) dos processos do escritório, e como foi realizada a análise de gap para definir o escopo futuro? (KA 6)

**Resposta**:

Estado atual (as-is): escritórios pequenos e médios tendem a operar com produção manual de peças, pesquisa jurisprudencial dispersa, controle de prazos em agenda/planilhas, armazenamento documental em pastas ou soluções genéricas, conferência manual de dados processuais e pouca rastreabilidade de uso de IA. Lacunas: retrabalho, risco de perda de prazo, dificuldade de versionamento de templates, ausência de trilha de auditoria, baixa governança de dados pessoais e dependência de consulta manual a fontes judiciais. Estado futuro (to-be): plataforma multi-tenant com RBAC, casos/processos/documentos centralizados, templates versionados, LLM Gateway com anonimização, DataJud/CNA/BCB integrados, gestão de prazos, calculadora judicial, auditoria, custos por caso e fallback para integrações externas. Métricas de transição devem ser coletadas no piloto: tempo por peça, tempo de conferência de prazo, número de retrabalhos, uso de templates aprovados e incidentes de conformidade.

## Q23
<!-- pfq-id: 062c154d-67ac-4b4d-8d2b-acd9f5617b8e -->

**Pergunta**: Qual é o estado atual (as-is) das integrações e quais lacunas específicas este caderno pretende resolver (KA 6)?

**Resposta**:

Estado atual (as-is): escritórios pequenos e médios tendem a operar com produção manual de peças, pesquisa jurisprudencial dispersa, controle de prazos em agenda/planilhas, armazenamento documental em pastas ou soluções genéricas, conferência manual de dados processuais e pouca rastreabilidade de uso de IA. Lacunas: retrabalho, risco de perda de prazo, dificuldade de versionamento de templates, ausência de trilha de auditoria, baixa governança de dados pessoais e dependência de consulta manual a fontes judiciais. Estado futuro (to-be): plataforma multi-tenant com RBAC, casos/processos/documentos centralizados, templates versionados, LLM Gateway com anonimização, DataJud/CNA/BCB integrados, gestão de prazos, calculadora judicial, auditoria, custos por caso e fallback para integrações externas. Métricas de transição devem ser coletadas no piloto: tempo por peça, tempo de conferência de prazo, número de retrabalhos, uso de templates aprovados e incidentes de conformidade.

## Q24
<!-- pfq-id: 478f5579-afd4-4d8b-bbe6-34c9508fa401 -->

**Pergunta**: Qual é o estado atual (as-is) documentado com métricas de produtividade manual, tempo gasto hoje, e como o to-be foi derivado (KA 6)?

**Resposta**:

Estado atual (as-is): escritórios pequenos e médios tendem a operar com produção manual de peças, pesquisa jurisprudencial dispersa, controle de prazos em agenda/planilhas, armazenamento documental em pastas ou soluções genéricas, conferência manual de dados processuais e pouca rastreabilidade de uso de IA. Lacunas: retrabalho, risco de perda de prazo, dificuldade de versionamento de templates, ausência de trilha de auditoria, baixa governança de dados pessoais e dependência de consulta manual a fontes judiciais. Estado futuro (to-be): plataforma multi-tenant com RBAC, casos/processos/documentos centralizados, templates versionados, LLM Gateway com anonimização, DataJud/CNA/BCB integrados, gestão de prazos, calculadora judicial, auditoria, custos por caso e fallback para integrações externas. Métricas de transição devem ser coletadas no piloto: tempo por peça, tempo de conferência de prazo, número de retrabalhos, uso de templates aprovados e incidentes de conformidade.

## Q25
<!-- pfq-id: 5056cffd-e39c-4bb6-904e-4a67e8ec3028 -->

**Pergunta**: Qual é o estado atual (as-is) e o estado futuro (to-be) da solução AJA em termos de funcionalidades e dados (KA 6)?

**Resposta**:

Estado atual (as-is): escritórios pequenos e médios tendem a operar com produção manual de peças, pesquisa jurisprudencial dispersa, controle de prazos em agenda/planilhas, armazenamento documental em pastas ou soluções genéricas, conferência manual de dados processuais e pouca rastreabilidade de uso de IA. Lacunas: retrabalho, risco de perda de prazo, dificuldade de versionamento de templates, ausência de trilha de auditoria, baixa governança de dados pessoais e dependência de consulta manual a fontes judiciais. Estado futuro (to-be): plataforma multi-tenant com RBAC, casos/processos/documentos centralizados, templates versionados, LLM Gateway com anonimização, DataJud/CNA/BCB integrados, gestão de prazos, calculadora judicial, auditoria, custos por caso e fallback para integrações externas. Métricas de transição devem ser coletadas no piloto: tempo por peça, tempo de conferência de prazo, número de retrabalhos, uso de templates aprovados e incidentes de conformidade.

## Q26
<!-- pfq-id: e6b28d03-1f9b-4e4d-8c28-d3c48c3e797e -->

**Pergunta**: Qual é o estado atual (as-is) detalhado dos processos de produção de peças e o estado futuro (to-be) com métricas de transição (KA 6)?

**Resposta**:

Estado atual (as-is): escritórios pequenos e médios tendem a operar com produção manual de peças, pesquisa jurisprudencial dispersa, controle de prazos em agenda/planilhas, armazenamento documental em pastas ou soluções genéricas, conferência manual de dados processuais e pouca rastreabilidade de uso de IA. Lacunas: retrabalho, risco de perda de prazo, dificuldade de versionamento de templates, ausência de trilha de auditoria, baixa governança de dados pessoais e dependência de consulta manual a fontes judiciais. Estado futuro (to-be): plataforma multi-tenant com RBAC, casos/processos/documentos centralizados, templates versionados, LLM Gateway com anonimização, DataJud/CNA/BCB integrados, gestão de prazos, calculadora judicial, auditoria, custos por caso e fallback para integrações externas. Métricas de transição devem ser coletadas no piloto: tempo por peça, tempo de conferência de prazo, número de retrabalhos, uso de templates aprovados e incidentes de conformidade.

## Q27
<!-- pfq-id: 1dd1c2cb-112d-433c-958c-12cea95a094a -->

**Pergunta**: Qual a matriz de rastreabilidade entre requisitos, fontes e outros artefatos (KA 5)?

**Resposta**:

A matriz de rastreabilidade deverá ser mantida como artefato obrigatório do GCA, vinculando: ID do requisito, objetivo de negócio, fonte de elicitação, stakeholder responsável, risco associado, requisito funcional/não funcional/regra de negócio, critério de aceite, caso de teste, status e versão. No documento consolidado, essa rastreabilidade está parcialmente estruturada pelas seções de requisitos negociais, funcionais, não funcionais, integrações, segurança/LGPD, dados e critérios de aceite. Para fechamento definitivo do item, recomenda-se gerar a planilha/matriz RTM em formato tabular antes da Sprint 0.

## Q28
<!-- pfq-id: 1536f2cd-45e4-45e3-a275-f7b9dd323d86 -->

**Pergunta**: O plano de engajamento de stakeholders (RACI, matriz poder/interesse) está formalizado e aprovado (KA 3 §3.2.2)?

**Resposta**:

Os stakeholders do AJA são: patrocinador do produto, gestor do escritório, sócios, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, financeiro, compliance/DPO, TI/DevOps, segurança da informação, clientes externos com acesso restrito, equipe de desenvolvimento, QA, fornecedores de LLM e provedores/órgãos externos como CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB e BCB/SGS. O plano de engajamento deve usar RACI e matriz poder/interesse: alta influência/alto interesse para sócios, patrocinador, advogado sênior, DPO e arquitetura; alto interesse/menor poder para usuários operacionais; influência externa para órgãos e provedores. A validação deve ocorrer por workshops de requisitos, revisões de protótipos, aceite de critérios e aprovação formal antes do piloto.

## Q29
<!-- pfq-id: 9a3010f7-baf7-4193-a6c8-17384955e653 -->

**Pergunta**: Para cada requisito, quais são os critérios de aceitação explícitos, testáveis e mensuráveis? (KA 7)

**Resposta**:

Cada requisito deverá ter critérios de aceite no padrão: dado/contexto, quando/ação, então/resultado esperado, evidência de teste e responsável pelo aceite. Exemplos mínimos: usuário sem permissão não acessa caso protegido; peça gerada por IA permanece como minuta até aprovação de advogado; consulta externa exibe fonte, data/hora, status e cache; prazo calculado exibe memória de cálculo; dados pessoais não são enviados a LLM externo sem anonimização/pseudonimização; falha de integração aciona fallback manual. Esses critérios serão detalhados no backlog por ID de requisito e vinculados aos casos de teste.

## Q30
<!-- pfq-id: 71da872c-7309-4197-b53c-6f8336f34d1d -->

**Pergunta**: Para os itens do backlog, quais são os critérios de aceitação específicos para os cenários não funcionais (ex.: desempenho do mock, resiliência) além do funcional (KA 7)?

**Resposta**:

Cada requisito deverá ter critérios de aceite no padrão: dado/contexto, quando/ação, então/resultado esperado, evidência de teste e responsável pelo aceite. Exemplos mínimos: usuário sem permissão não acessa caso protegido; peça gerada por IA permanece como minuta até aprovação de advogado; consulta externa exibe fonte, data/hora, status e cache; prazo calculado exibe memória de cálculo; dados pessoais não são enviados a LLM externo sem anonimização/pseudonimização; falha de integração aciona fallback manual. Esses critérios serão detalhados no backlog por ID de requisito e vinculados aos casos de teste.

## Q31
<!-- pfq-id: 89a48b4c-28ad-470b-bc0e-6fd6b2624516 -->

**Pergunta**: Quais são os critérios de aceitação para cada requisito funcional (ex: RF-27, RF-59)? Como serão testados?

**Resposta**:

Cada requisito deverá ter critérios de aceite no padrão: dado/contexto, quando/ação, então/resultado esperado, evidência de teste e responsável pelo aceite. Exemplos mínimos: usuário sem permissão não acessa caso protegido; peça gerada por IA permanece como minuta até aprovação de advogado; consulta externa exibe fonte, data/hora, status e cache; prazo calculado exibe memória de cálculo; dados pessoais não são enviados a LLM externo sem anonimização/pseudonimização; falha de integração aciona fallback manual. Esses critérios serão detalhados no backlog por ID de requisito e vinculados aos casos de teste.

## Q32
<!-- pfq-id: 644fb587-58e6-4e01-9274-c3afeb3baf27 -->

**Pergunta**: Quais métricas objetivas serão usadas para validar requisitos não funcionais como 'criptografia local' e 'recuperação testável' (KA 7/KA 8)?

**Resposta**:

As métricas de sucesso serão: redução de horas por peça, redução de retrabalho, percentual de documentos gerados a partir de templates aprovados, tempo médio para localizar processo/documento, percentual de prazos com memória de cálculo validada, número de consultas externas com sucesso/cache, custo de LLM por caso, incidentes de segurança/LGPD, taxa de aprovação de minutas sem retrabalho relevante, satisfação dos usuários e aderência aos critérios do Gatekeeper. A linha de base deve ser medida no piloto antes da automação, por amostragem de casos reais do escritório.

## Q33
<!-- pfq-id: c823da0e-5c9a-4824-b718-b57a2dee94e6 -->

**Pergunta**: Quais são os critérios de aceitação testáveis para cada requisito funcional do sistema AJA, não apenas para o conteúdo das peças (KA 7)?

**Resposta**:

Cada requisito deverá ter critérios de aceite no padrão: dado/contexto, quando/ação, então/resultado esperado, evidência de teste e responsável pelo aceite. Exemplos mínimos: usuário sem permissão não acessa caso protegido; peça gerada por IA permanece como minuta até aprovação de advogado; consulta externa exibe fonte, data/hora, status e cache; prazo calculado exibe memória de cálculo; dados pessoais não são enviados a LLM externo sem anonimização/pseudonimização; falha de integração aciona fallback manual. Esses critérios serão detalhados no backlog por ID de requisito e vinculados aos casos de teste.

## Q34
<!-- pfq-id: 68995377-64f0-47b9-8edd-cdf477ef9e41 -->

**Pergunta**: Qual é o estado atual (as-is) detalhado e o estado futuro (to-be) por requisito, com análise de lacunas (KA 6)?

**Resposta**:

Estado atual (as-is): escritórios pequenos e médios tendem a operar com produção manual de peças, pesquisa jurisprudencial dispersa, controle de prazos em agenda/planilhas, armazenamento documental em pastas ou soluções genéricas, conferência manual de dados processuais e pouca rastreabilidade de uso de IA. Lacunas: retrabalho, risco de perda de prazo, dificuldade de versionamento de templates, ausência de trilha de auditoria, baixa governança de dados pessoais e dependência de consulta manual a fontes judiciais. Estado futuro (to-be): plataforma multi-tenant com RBAC, casos/processos/documentos centralizados, templates versionados, LLM Gateway com anonimização, DataJud/CNA/BCB integrados, gestão de prazos, calculadora judicial, auditoria, custos por caso e fallback para integrações externas. Métricas de transição devem ser coletadas no piloto: tempo por peça, tempo de conferência de prazo, número de retrabalhos, uso de templates aprovados e incidentes de conformidade.

## Q35
<!-- pfq-id: 5737500a-9e8b-4b9d-8b11-6ff80eec3dc6 -->

**Pergunta**: Há alguma análise de gap documentada comparando estado atual (as‑is) e estado futuro (to‑be) com métricas de transição específicas (KA 6 §6.2)?

**Resposta**:

O estado atual presumido é majoritariamente manual: escritórios usam consulta direta a tribunais, planilhas, pastas locais/nuvem, modelos dispersos, conferência manual de prazos, cálculos externos e geração artesanal de peças. As lacunas são retrabalho, baixa rastreabilidade, risco de prazo, ausência de governança de IA, falta de repositório único, dificuldade de auditoria e dependência de consultas externas. O to-be do AJA centraliza casos, processos, documentos, templates, prazos, cálculos, IA assistida, integrações oficiais, auditoria, RBAC e LGPD, mantendo revisão humana obrigatória.

## Q36
<!-- pfq-id: ae441abc-8a32-48f4-9f25-af3df80d91ef -->

**Pergunta**: Como os requisitos serão priorizados (MoSCoW, por valor, etc.) e versionados ao longo do ciclo de vida? (KA 5)

**Resposta**:

A priorização seguirá MoSCoW combinada com valor de negócio, risco jurídico, risco LGPD, complexidade técnica e dependência externa. Must Have: multi-tenant/RBAC, casos, documentos, templates, LLM Gateway, anonimização, auditoria, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora. Should Have: PDPJ/DJE, portal do cliente, dashboards avançados e relatórios de ROI. Could Have: PJe/MNI por tribunal piloto, IA local e integrações privadas. Won't Have no MVP: peticionamento automatizado amplo e scraping como estratégia principal. Requisitos serão versionados por release, com changelog e rastreabilidade no GCA.

## Q37
<!-- pfq-id: ac19a078-a31d-43e4-b15a-10bf585f81fb -->

**Pergunta**: Quais métricas de sucesso serão monitoradas após a implantação dos mocks para avaliar a solução (KA 8)?

**Resposta**:

As métricas de sucesso serão: redução de horas por peça, redução de retrabalho, percentual de documentos gerados a partir de templates aprovados, tempo médio para localizar processo/documento, percentual de prazos com memória de cálculo validada, número de consultas externas com sucesso/cache, custo de LLM por caso, incidentes de segurança/LGPD, taxa de aprovação de minutas sem retrabalho relevante, satisfação dos usuários e aderência aos critérios do Gatekeeper. A linha de base deve ser medida no piloto antes da automação, por amostragem de casos reais do escritório.

## Q38
<!-- pfq-id: 194eb3ae-74ef-4bf5-ae3e-71583ffb7b0f -->

**Pergunta**: Como a solução será avaliada após implantação? Quais métricas de sucesso (além dos objetivos de negócio) serão mensuradas (KA 8)?

**Resposta**:

As métricas de sucesso serão: redução de horas por peça, redução de retrabalho, percentual de documentos gerados a partir de templates aprovados, tempo médio para localizar processo/documento, percentual de prazos com memória de cálculo validada, número de consultas externas com sucesso/cache, custo de LLM por caso, incidentes de segurança/LGPD, taxa de aprovação de minutas sem retrabalho relevante, satisfação dos usuários e aderência aos critérios do Gatekeeper. A linha de base deve ser medida no piloto antes da automação, por amostragem de casos reais do escritório.

## Q39
<!-- pfq-id: e106242b-1259-4184-b46a-bc2f05a483c5 -->

**Pergunta**: Como serão medidos os KPIs de ROI (economia de hora técnica, redução de retrabalho) e qual a linha de base (KA 8)?

**Resposta**:

As métricas de sucesso serão: redução de horas por peça, redução de retrabalho, percentual de documentos gerados a partir de templates aprovados, tempo médio para localizar processo/documento, percentual de prazos com memória de cálculo validada, número de consultas externas com sucesso/cache, custo de LLM por caso, incidentes de segurança/LGPD, taxa de aprovação de minutas sem retrabalho relevante, satisfação dos usuários e aderência aos critérios do Gatekeeper. A linha de base deve ser medida no piloto antes da automação, por amostragem de casos reais do escritório.

## Q40
<!-- pfq-id: bbd57b75-4144-42dd-afa3-681d816e6e18 -->

**Pergunta**: Quais são os critérios de aceitação mensuráveis para cada requisito funcional e não funcional (KA 7)?

**Resposta**:

Cada requisito deverá ter critérios de aceite no padrão: dado/contexto, quando/ação, então/resultado esperado, evidência de teste e responsável pelo aceite. Exemplos mínimos: usuário sem permissão não acessa caso protegido; peça gerada por IA permanece como minuta até aprovação de advogado; consulta externa exibe fonte, data/hora, status e cache; prazo calculado exibe memória de cálculo; dados pessoais não são enviados a LLM externo sem anonimização/pseudonimização; falha de integração aciona fallback manual. Esses critérios serão detalhados no backlog por ID de requisito e vinculados aos casos de teste.

## Q41
<!-- pfq-id: 7e207f80-d47d-4db8-8a1d-d5a0090062fe -->

**Pergunta**: Como os requisitos de transição (ex.: migração de documentos antigos, treinamento) serão rastreados e validados (KA 5 §5.3 e §5.4)?

**Resposta**:

O onboarding de usuários será dividido por perfil: Admin, advogado, paralegal, estagiário, DPO, financeiro e cliente externo. O material deve cobrir operação do sistema, limites da IA, revisão humana, sigilo profissional, LGPD, prazos, cálculo, ingestão/exportação documental e resposta a incidentes. O aceite da política de IA e segurança deve ser obrigatório antes do uso produtivo.

## Q42
<!-- pfq-id: d8ba60b6-df22-4fcc-9880-6541021f5d4e -->

**Pergunta**: Quais foram as fontes validadas para as regras de negócio e requisitos legais, e como asseguraram que não conflitam? (KA 4/5)

**Resposta**:

As fontes validadas/referenciadas para regras de negócio e requisitos legais são: documentação pública do DataJud/CNJ, PDPJ-Br/Domicílio Judicial Eletrônico, PJe/MNI Client, CNA/OAB, BCB/SGS, LGPD/ANPD, CPC/2015, CLT e recomendações da OAB sobre IA generativa na prática jurídica. Conflitos entre fontes deverão ser resolvidos pela hierarquia: lei/regulamento aplicável, norma do órgão competente, documentação oficial da API, política interna aprovada e decisão formal do advogado responsável/DPO.

## Q43
<!-- pfq-id: 11a9117d-24ed-4001-835b-30ff4cff47cd -->

**Pergunta**: Há requisitos de transição para migração de documentos legais antigos, treinamento dos advogados, ou período de operação paralela?

**Resposta**:

Sim. Os requisitos de transição incluem: inventário de documentos antigos, saneamento e classificação por caso/cliente, importação controlada para o repositório documental, treinamento de advogados e equipe de apoio, operação paralela por pelo menos 2 ciclos de prazos críticos, validação de templates por advogado sênior, checklist de privacidade e plano de rollback para retornar ao controle manual caso o piloto apresente falhas críticas.

## Q44
<!-- pfq-id: 230e3ef6-8a0e-47d1-98f8-b84de4d5e3a8 -->

**Pergunta**: Há análise de riscos formal (probabilidade, impacto e mitigação) para a implantação dos templates (KA 6)?

**Resposta**:

A análise de riscos deverá conter probabilidade, impacto, severidade, controles e dono do risco. Riscos principais: uso de template incorreto, alucinação de IA, vazamento de dados pessoais, perda de prazo, indisponibilidade de fonte externa, erro de cálculo, conflito de interesses não detectado, uso indevido de credenciais e ausência de revisão humana. Mitigações: aprovação por advogado sênior, versionamento, checklist, logs, RBAC, anonimização, fallback manual, testes de regressão e auditoria.

## Q45
<!-- pfq-id: 2f75d848-163a-4396-8fcc-30235caa11cf -->

**Pergunta**: Os critérios de aceitação para requisitos não funcionais críticos, como desempenho e segurança, estão definidos e mensuráveis (KA 7 §7.4.4)?

**Resposta**:

Os critérios de aceitação devem ser definidos por requisito, em formato testável: perfil autorizado, pré-condição, ação, resultado esperado, evidência gerada, log de auditoria, tratamento de erro e regra de segurança/LGPD aplicável. Para requisitos já especificados, os critérios constam nas seções de RF/RNF/RN; lacunas remanescentes devem ser convertidas em critérios Given/When/Then no backlog do GCA antes da Sprint de implementação.

## Q46
<!-- pfq-id: 50fcb0ad-c95e-4e43-8002-45d8874e918d -->

**Pergunta**: Qual é o plano de avaliação da solução após implantação, com KPIs operacionais e indicadores de conformidade contínua? (KA 8)

**Resposta**:

Os stakeholders-chave são: patrocinador do produto, sócio/gestor jurídico do escritório, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, responsável financeiro, responsável de TI, responsável de privacidade/DPO, equipe de desenvolvimento, QA, segurança, suporte, clientes externos com acesso controlado e órgãos/fontes externas (CNJ/DataJud, PDPJ/DJE, tribunais, OAB/CNA e BCB) como partes interessadas regulatórias/técnicas. O plano de engajamento será: reuniões quinzenais de validação do backlog com negócio e jurídico, revisão mensal de riscos/compliance, homologação assistida por usuários-chave e aceite formal por sócio/gestor jurídico, DPO e responsável técnico. Matriz poder/interesse: alto poder/alto interesse = sócio gestor, advogado sênior, DPO e PO; alto poder/baixo uso = direção/financeiro; alto uso/baixo poder = advogados, assistentes e estagiários; influência externa = CNJ, OAB e tribunais.

## Q47
<!-- pfq-id: 2d46d8ec-84d4-44a1-a22f-8b57da4b3d2b -->

**Pergunta**: Os requisitos não funcionais de segurança (RNF-01) e privacidade (RNF-02) foram validados com especialistas em LGPD e segurança da informação?

**Resposta**:

Requisitos não funcionais mínimos: disponibilidade interna alvo de 99,5% no MVP; criptografia em trânsito e em repouso; MFA para papéis sensíveis; cofre de segredos; logs e auditoria imutável para ações críticas; resposta de telas comuns em até 2 segundos quando sem dependência externa; operações externas assíncronas com fila; RPO máximo de 15 minutos e RTO máximo de 4 horas para dados críticos no MVP; segregação multi-tenant; testes automatizados de RBAC, integrações, anonimização, cálculos, prazos e documentos.

## Q48
<!-- pfq-id: f40b8133-6ad8-41cd-9fb0-ace5d1ecbe06 -->

**Pergunta**: Quais são os requisitos não funcionais (desempenho, segurança, disponibilidade) com metas quantificáveis (KA 7)?

**Resposta**:

Requisitos não funcionais mínimos: disponibilidade interna alvo de 99,5% no MVP; criptografia em trânsito e em repouso; MFA para papéis sensíveis; cofre de segredos; logs e auditoria imutável para ações críticas; resposta de telas comuns em até 2 segundos quando sem dependência externa; operações externas assíncronas com fila; RPO máximo de 15 minutos e RTO máximo de 4 horas para dados críticos no MVP; segregação multi-tenant; testes automatizados de RBAC, integrações, anonimização, cálculos, prazos e documentos.

## Q49
<!-- pfq-id: 9256d999-4499-4cb4-afb7-0daa8a03eba1 -->

**Pergunta**: Qual é o plano de avaliação da solução pós‑entrega, incluindo KPIs operacionais e indicadores de conformidade contínua (KA 8 §8.2)?

**Resposta**:

Os stakeholders do AJA são: patrocinador do produto, gestor do escritório, sócios, advogado sênior, advogados usuários, paralegais/assistentes, estagiários, financeiro, compliance/DPO, TI/DevOps, segurança da informação, clientes externos com acesso restrito, equipe de desenvolvimento, QA, fornecedores de LLM e provedores/órgãos externos como CNJ/DataJud, PDPJ/DJE, PJe/MNI, CNA/OAB e BCB/SGS. O plano de engajamento deve usar RACI e matriz poder/interesse: alta influência/alto interesse para sócios, patrocinador, advogado sênior, DPO e arquitetura; alto interesse/menor poder para usuários operacionais; influência externa para órgãos e provedores. A validação deve ocorrer por workshops de requisitos, revisões de protótipos, aceite de critérios e aprovação formal antes do piloto.

## Q50
<!-- pfq-id: 33b600d7-0f12-4ab7-bb78-c3a92d67b336 -->

**Pergunta**: Como os cálculos financeiros (RF-37 a RF-44) serão validados contra cálculos manuais de peritos contábeis?

**Resposta**:

Os cálculos financeiros deverão ser validados por dupla trilha: validação técnica contra séries oficiais configuradas (BCB/SGS para índices como Selic, IPCA, INPC e TR quando aplicável) e validação jurídica/contábil por amostra revisada por advogado responsável ou perito/contador parceiro. Cada cálculo deve gerar memória detalhada: índice, série, período, fórmula, juros, multa, honorários, versão da fórmula e data da atualização. Nenhum cálculo será tratado como oficial sem revisão humana.

## Q51
<!-- pfq-id: ff7eb6a5-d266-450b-9ce7-897239337b00 -->

**Pergunta**: A estratégia de IA (IA-01 a IA-08) foi discutida com advogados e técnicos de IA? Como a explicabilidade será garantida (KA 7)?

**Resposta**:

A estratégia de IA deverá ser validada em workshop com advogado sênior, responsável técnico de IA e DPO antes do piloto produtivo. A explicabilidade será garantida por registro de prompt, modelo, versão, fontes usadas, variáveis do template, motivo da recomendação, nível de confiança operacional, limitações conhecidas e obrigação de revisão humana. Toda saída de IA será classificada como minuta ou apoio analítico, nunca como decisão jurídica final automática.


---
