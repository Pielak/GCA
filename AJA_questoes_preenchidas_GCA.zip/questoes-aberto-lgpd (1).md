---
gca-followup-marker: v1
project_id: 24bf72c3-2ee8-45fd-b879-d3a00b347c39
persona_id: LGPD
persona_name: Proteção de Dados
generated_at: 2026-05-05T01:39:13.341115+00:00
question_count: 77
---

# Perguntas em aberto — Proteção de Dados — Assistente Judicial para Advogados

Preencha as respostas abaixo de cada pergunta (substitua `<sua resposta aqui>`). Faça upload deste arquivo pela aba **Ingestão de Documentos**. NÃO altere as linhas com `<!-- pfq-id: ... -->`.

## Q1
<!-- pfq-id: 0afcd8fe-8b23-4080-98f2-490150818d0a -->

**Pergunta**: Qual é a base legal para o tratamento dos dados pessoais e sensíveis dos titulares (Art. 7º e Art. 11 da LGPD)? O tratamento é por consentimento, obrigação legal, execução de contrato, legítimo interesse ou exercício de direitos em processo judicial?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q2
<!-- pfq-id: 4ee4da85-e3ac-48c6-aada-0774c42c87b1 -->

**Pergunta**: Qual é a base legal para o tratamento descrito (Art. 7º)?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q3
<!-- pfq-id: 5755778a-c7a7-4abd-b06b-d41bed6ebc2e -->

**Pergunta**: Quem é o Encarregado pelo Tratamento (Art. 41) designado pelo escritório?

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q4
<!-- pfq-id: 6dbb69f5-6500-44de-a569-8494bbf6b6d4 -->

**Pergunta**: Quem é o controlador dos dados pessoais tratados pelo aplicativo e qual é a base legal para cada finalidade de tratamento (Art. 7º)?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q5
<!-- pfq-id: 0a3e8e43-4c44-4e21-8295-131fc4d06b30 -->

**Pergunta**: Quem é o Controlador dos dados pessoais tratados pela plataforma AJA (escritório, empresa proprietária do software ou ambos em controladoria conjunta)?

**Resposta**:

No modelo SaaS/multi-tenant, o escritório de advocacia será o Controlador dos dados pessoais dos seus clientes, partes, contrapartes, testemunhas e usuários, pois define as finalidades e meios essenciais do tratamento jurídico. A empresa proprietária/operadora do AJA atuará, em regra, como Operadora, tratando dados em nome do escritório conforme contrato, instruções documentadas, política de segurança, confidencialidade e acordo de tratamento de dados. Poderá haver controladoria independente ou conjunta apenas em finalidades próprias do fornecedor, como faturamento, segurança da plataforma, suporte e melhoria do serviço, desde que documentadas em contrato e política de privacidade.

## Q6
<!-- pfq-id: c2657fb4-ffb6-4271-a259-e1aab518a771 -->

**Pergunta**: Qual é a base legal para o tratamento de dados pessoais realizado pelo AJA (Art. 7º)?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q7
<!-- pfq-id: 0a96b011-ac15-451a-bf49-70a565ae0f1d -->

**Pergunta**: Qual é a base legal para o tratamento de dados pessoais descrito no projeto (Art. 7º)?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q8
<!-- pfq-id: 7b367405-b8a8-4036-ba8b-dd43737b4b0b -->

**Pergunta**: Qual(is) a(s) base(s) legal(is) para o tratamento de dados pessoais e dados sensíveis, conforme Art. 7º e Art. 11 da Lei 13.709/2018?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q9
<!-- pfq-id: fcf68ad1-f06a-47bc-9035-22362dfa3e4b -->

**Pergunta**: Quem é o controlador dos dados pessoais tratados pelo AJA (ex.: escritório de advocacia)?

**Resposta**:

No modelo SaaS/multi-tenant, o escritório de advocacia será o Controlador dos dados pessoais dos seus clientes, partes, contrapartes, testemunhas e usuários, pois define as finalidades e meios essenciais do tratamento jurídico. A empresa proprietária/operadora do AJA atuará, em regra, como Operadora, tratando dados em nome do escritório conforme contrato, instruções documentadas, política de segurança, confidencialidade e acordo de tratamento de dados. Poderá haver controladoria independente ou conjunta apenas em finalidades próprias do fornecedor, como faturamento, segurança da plataforma, suporte e melhoria do serviço, desde que documentadas em contrato e política de privacidade.

## Q10
<!-- pfq-id: 39df85f2-ec14-468d-8c1c-9c5f90c25fbe -->

**Pergunta**: Quem será designado como Encarregado (DPO) e qual o canal público de contato (Art. 41)?

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q11
<!-- pfq-id: bab9b396-7f00-4376-817c-8e1a9d46e499 -->

**Pergunta**: Há tratamento de dados sensíveis (origem racial, convicção religiosa, saúde, dados genéticos, dados relativos à condenação penal, etc.)? Em caso positivo, qual o fundamento específico e as salvaguardas adotadas?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q12
<!-- pfq-id: 449aeab5-bd75-440c-bc46-f1681d48e9ba -->

**Pergunta**: Há tratamento de dados sensíveis (Art. 11)?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q13
<!-- pfq-id: 05417d05-2dbf-4941-a8e3-280e8c1dc3d4 -->

**Pergunta**: O procedimento de incidentes definido inclui o prazo para comunicação à ANPD conforme Art. 48?

**Resposta**:

O plano de resposta a incidentes deverá ser formalizado antes do piloto produtivo e incluir: identificação, classificação de severidade, contenção, preservação de evidências, análise de impacto aos titulares, decisão sobre comunicação à ANPD e titulares, plano de remediação, lições aprendidas e registro no inventário de incidentes. O prazo e o formato de comunicação seguirão a regulamentação vigente da ANPD; enquanto não houver avaliação completa, o requisito interno será comunicar incidentes relevantes à direção/DPO imediatamente e preparar comunicação externa sem atraso injustificado.

## Q14
<!-- pfq-id: e69b0521-3afd-42f9-b61d-d824dd1cc6c0 -->

**Pergunta**: São tratados dados sensíveis (origem racial ou étnica, convicção religiosa, opinião política, saúde, vida sexual, dados genéticos ou biométricos) conforme definido no Art. 5º, II? Em caso positivo, qual a base do Art. 11?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q15
<!-- pfq-id: 247196a7-4bad-4762-b9f0-48268421de96 -->

**Pergunta**: Há um Encarregado (DPO) designado e com canal de comunicação público? (Art. 41)

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q16
<!-- pfq-id: 40104580-bfc0-405d-9f91-11831fd95993 -->

**Pergunta**: Há tratamento de dados pessoais sensíveis (Art. 5º, II) como origem racial, saúde, dados genéticos, etc., que exigiria fundamento qualificado do Art. 11?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q17
<!-- pfq-id: 22bc123a-9fa1-41ad-9042-186801726975 -->

**Pergunta**: Há tratamento de dados sensíveis, como informações de saúde, origem racial ou condenações criminais (Art. 5º, II)? Em caso positivo, qual o fundamento (Art. 11)?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q18
<!-- pfq-id: 3441d56b-0ba6-4cb5-867d-46e0abad9ec9 -->

**Pergunta**: Quem é o Encarregado pelo Tratamento de Dados (DPO) e como pode ser contactado? (Art. 41)

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q19
<!-- pfq-id: 59e0db2b-2ae5-445d-9595-616b6cc9b308 -->

**Pergunta**: Qual(is) a(s) base(s) legal(is) para o tratamento de dados pessoais e sensíveis (Art. 7º e Art. 11)?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q20
<!-- pfq-id: f125fbe1-b10d-4aca-a80c-64cc112dcdbc -->

**Pergunta**: Quando será formalizada a política de retenção e eliminação de dados (Art. 15 e 16)?

**Resposta**:

A política de retenção deverá ser formalizada antes do piloto produtivo e parametrizada por categoria: dados cadastrais de clientes enquanto durar a relação e pelos prazos legais/defesa judicial; documentos processuais enquanto houver processo ativo e prazo de guarda definido pelo escritório; logs de auditoria pelo prazo necessário à segurança, compliance e defesa; prompts/respostas de IA por período reduzido e com hash/mascaramento quando possível; backups conforme política 3-2-1 e expurgo programado. A eliminação será segura, auditável e bloqueada quando houver obrigação legal, ordem judicial, processo ativo ou necessidade de exercício regular de direitos.

## Q21
<!-- pfq-id: b65d7107-3933-45bd-99c5-c39c4be64ef9 -->

**Pergunta**: Quem é o Encarregado (DPO) pelo tratamento de dados pessoais (Art. 41)? Qual o canal de contato para titulares e ANPD?

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q22
<!-- pfq-id: e4538544-8fa7-4dbe-8d0f-3e9b80442069 -->

**Pergunta**: Quem é o Encarregado pelo Tratamento (Art. 41)?

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q23
<!-- pfq-id: 37feb460-9066-4ef5-86b3-7233c6aeadfe -->

**Pergunta**: Há previsão de transferência internacional de dados em integrações futuras que exija avaliação com base no Art. 33?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q24
<!-- pfq-id: fc3cbb50-41f5-4c09-b795-9b1a46c2d885 -->

**Pergunta**: Há um Encarregado (DPO) designado pelo controlador e como será o canal de comunicação com titulares e ANPD (Art. 41)?

**Resposta**:

No modelo SaaS/multi-tenant, o escritório de advocacia será o Controlador dos dados pessoais dos seus clientes, partes, contrapartes, testemunhas e usuários, pois define as finalidades e meios essenciais do tratamento jurídico. A empresa proprietária/operadora do AJA atuará, em regra, como Operadora, tratando dados em nome do escritório conforme contrato, instruções documentadas, política de segurança, confidencialidade e acordo de tratamento de dados. Poderá haver controladoria independente ou conjunta apenas em finalidades próprias do fornecedor, como faturamento, segurança da plataforma, suporte e melhoria do serviço, desde que documentadas em contrato e política de privacidade.

## Q25
<!-- pfq-id: 5044271f-adb0-4e80-8c8b-0535fe02f3da -->

**Pergunta**: Quais as bases legais específicas para o tratamento dos dados dos clientes, contrapartes e testemunhas? (Art. 7º, Art. 11)

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q26
<!-- pfq-id: fb2e55c1-936d-4e57-9990-f8428898b291 -->

**Pergunta**: Quem é o Encarregado pelo Tratamento (Art. 41) e quais são seus canais de contato públicos?

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q27
<!-- pfq-id: a0f0eeb2-a44a-468b-a2d1-6a3b4551011b -->

**Pergunta**: Quem é o Controlador dos dados pessoais tratados pelo AJA? O advogado/usuário do escritório, o desenvolvedor do software ou outro agente?

**Resposta**:

No modelo SaaS/multi-tenant, o escritório de advocacia será o Controlador dos dados pessoais dos seus clientes, partes, contrapartes, testemunhas e usuários, pois define as finalidades e meios essenciais do tratamento jurídico. A empresa proprietária/operadora do AJA atuará, em regra, como Operadora, tratando dados em nome do escritório conforme contrato, instruções documentadas, política de segurança, confidencialidade e acordo de tratamento de dados. Poderá haver controladoria independente ou conjunta apenas em finalidades próprias do fornecedor, como faturamento, segurança da plataforma, suporte e melhoria do serviço, desde que documentadas em contrato e política de privacidade.

## Q28
<!-- pfq-id: 4170536e-3455-4029-b92d-b0d1e47346ef -->

**Pergunta**: Como o sistema garante o exercício dos direitos dos titulares: confirmação, acesso, correção, anonimização, portabilidade, eliminação, revogação de consentimento e revisão de decisão automatizada? (Art. 18, Art. 9º, Art. 19, Art. 20)

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q29
<!-- pfq-id: e2e85e66-6001-4fef-bccd-979f06fa8703 -->

**Pergunta**: Quem será o Encarregado pelo Tratamento de Dados Pessoais (DPO) e quais seus canais de contato (Art. 41)?

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q30
<!-- pfq-id: 0f849a04-772e-483f-b49d-33a1ae6b2d52 -->

**Pergunta**: O plano de resposta a incidentes de segurança já foi testado e aprovado (Art. 48)?

**Resposta**:

O plano de resposta a incidentes deverá ser formalizado antes do piloto produtivo e incluir: identificação, classificação de severidade, contenção, preservação de evidências, análise de impacto aos titulares, decisão sobre comunicação à ANPD e titulares, plano de remediação, lições aprendidas e registro no inventário de incidentes. O prazo e o formato de comunicação seguirão a regulamentação vigente da ANPD; enquanto não houver avaliação completa, o requisito interno será comunicar incidentes relevantes à direção/DPO imediatamente e preparar comunicação externa sem atraso injustificado.

## Q31
<!-- pfq-id: a7233038-a400-456e-9873-fcc741e3aee2 -->

**Pergunta**: Como serão atendidos os direitos dos titulares (acesso, correção, exclusão, portabilidade, oposição, revisão de decisões automatizadas) previstos no Art. 18? O sistema permitirá ao titular exercê-los diretamente?

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q32
<!-- pfq-id: 22c7b085-7fed-4d0f-97b3-e8408215338d -->

**Pergunta**: Está previsto Relatório de Impacto à Proteção de Dados (Art. 38)?

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q33
<!-- pfq-id: e138a88f-7892-4da2-a2f2-6381963a392b -->

**Pergunta**: Como o aplicativo permitirá que o controlador atenda os direitos dos titulares (acesso, correção, exclusão, portabilidade, etc.) previstos no Art. 18?

**Resposta**:

No modelo SaaS/multi-tenant, o escritório de advocacia será o Controlador dos dados pessoais dos seus clientes, partes, contrapartes, testemunhas e usuários, pois define as finalidades e meios essenciais do tratamento jurídico. A empresa proprietária/operadora do AJA atuará, em regra, como Operadora, tratando dados em nome do escritório conforme contrato, instruções documentadas, política de segurança, confidencialidade e acordo de tratamento de dados. Poderá haver controladoria independente ou conjunta apenas em finalidades próprias do fornecedor, como faturamento, segurança da plataforma, suporte e melhoria do serviço, desde que documentadas em contrato e política de privacidade.

## Q34
<!-- pfq-id: 1d469fb4-fc5f-4bc6-a306-a34a4e4f9eae -->

**Pergunta**: O tratamento inclui dados sensíveis (origem, saúde, opinião política, etc.)? Em caso positivo, quais as bases do Art. 11?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q35
<!-- pfq-id: c69dfce3-0f52-42d0-98e7-0fdd862c30ac -->

**Pergunta**: Como os titulares podem exercer seus direitos de acesso, correção, eliminação e portabilidade (Art. 18)?

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q36
<!-- pfq-id: 75f5cb2e-12fe-43cf-a829-614a88dffd35 -->

**Pergunta**: Quem é o Operador, quando o tratamento ocorre em nome do Controlador (Art. 5º, VII)? O AJA atua como operador?

**Resposta**:

No modelo SaaS/multi-tenant, o escritório de advocacia será o Controlador dos dados pessoais dos seus clientes, partes, contrapartes, testemunhas e usuários, pois define as finalidades e meios essenciais do tratamento jurídico. A empresa proprietária/operadora do AJA atuará, em regra, como Operadora, tratando dados em nome do escritório conforme contrato, instruções documentadas, política de segurança, confidencialidade e acordo de tratamento de dados. Poderá haver controladoria independente ou conjunta apenas em finalidades próprias do fornecedor, como faturamento, segurança da plataforma, suporte e melhoria do serviço, desde que documentadas em contrato e política de privacidade.

## Q37
<!-- pfq-id: f9e3c8cd-e37c-4f76-8483-4d8d51c0f247 -->

**Pergunta**: O tratamento envolve dados sensíveis (saúde, condenações criminais, etc.)? Se sim, qual o fundamento do Art. 11?

**Resposta**:

As bases legais principais serão: execução de contrato/prestação de serviços jurídicos (Art. 7º, V), cumprimento de obrigação legal/regulatória (Art. 7º, II), exercício regular de direitos em processo judicial, administrativo ou arbitral (Art. 7º, VI), legítimo interesse apenas para finalidades administrativas compatíveis e documentadas (Art. 7º, IX) e consentimento apenas para finalidades acessórias quando necessário. Para dados sensíveis, a base preferencial será o exercício regular de direitos, inclusive em contrato e em processo judicial/administrativo/arbitral (Art. 11, II, d), cumprimento de obrigação legal/regulatória (Art. 11, II, a) e, quando aplicável, proteção da vida/incolumidade ou tutela da saúde. O consentimento para dados sensíveis não será a base principal das atividades jurídicas ordinárias.

## Q38
<!-- pfq-id: a8d8539a-9ac6-44fd-a19f-7630d2adfdde -->

**Pergunta**: Como os titulares exercerão seus direitos (Art. 18) – acesso, correção, exclusão etc. – dentro da ferramenta?

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q39
<!-- pfq-id: f27aba99-7d98-4f5d-aa3d-769cc0531351 -->

**Pergunta**: O inventário das operações de tratamento (Art. 37) será elaborado antes da produção?

**Resposta**:

Sim. O inventário das operações de tratamento deverá ser elaborado antes da produção e mantido no Admin. Para cada operação serão registrados: finalidade, categoria de dado, titular, base legal, necessidade, adequação, origem, compartilhamentos, retenção, controles de segurança, operador/suboperador, transferência internacional, risco e responsável. O sistema deve impedir criação de novos fluxos de tratamento sem finalidade e base legal cadastradas.

## Q40
<!-- pfq-id: 3071f8e8-af92-48c6-94a0-df3b151f0dd6 -->

**Pergunta**: Está previsto Relatório de Impacto à Proteção de Dados Pessoais (RIPD) para os tratamentos de alto risco (Art. 38)?

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q41
<!-- pfq-id: e2a7a035-1ee1-4a13-94cb-31e4a9e13468 -->

**Pergunta**: Há transferência internacional (Art. 33)?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q42
<!-- pfq-id: 983a7034-94b3-48e6-9f2c-9d6bc60d84ae -->

**Pergunta**: O fluxo de provisão de IA externa implicará transferência internacional de dados pessoais? Se sim, quais as salvaguardas legais do Art. 33?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q43
<!-- pfq-id: d05dfd64-3aad-410d-bc08-96c93c2bcb9a -->

**Pergunta**: Como serão atendidos os pedidos de acesso, correção, exclusão e portabilidade dos titulares? (Art. 18 e 19)

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q44
<!-- pfq-id: 6742e1c3-f655-4148-8e94-c51d2131c743 -->

**Pergunta**: Existe transferência internacional de dados (Art. 33)? Se sim, em qual hipótese legal se enquadra?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q45
<!-- pfq-id: 13a78346-4806-45f3-a910-99ff66b0ca11 -->

**Pergunta**: Quem é o Encarregado pelo Tratamento de Dados Pessoais (DPO) e como pode ser contatado pelos titulares e pela ANPD (Art. 41)?

**Resposta**:

O Encarregado/DPO ainda deve ser formalmente designado pelo escritório antes do piloto produtivo. Requisito obrigatório: cadastrar no Admin o nome, e-mail público, canal de atendimento ao titular/ANPD, atribuições, data de designação e substituto. Para agente de tratamento de pequeno porte, poderá haver dispensa formal de indicação de encarregado, mas deverá existir canal de comunicação com titulares; como boa prática, recomenda-se designar ao menos um Responsável de Privacidade.

## Q46
<!-- pfq-id: 3ff600f1-96c6-4be7-b70d-50889c38a5e8 -->

**Pergunta**: Existe previsão de Relatório de Impacto à Proteção de Dados (RIPD) para atividades de alto risco? (Art. 38)

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q47
<!-- pfq-id: e6d04d81-2fed-4a98-a236-a9adceee3e47 -->

**Pergunta**: Há previsão de Relatório de Impacto à Proteção de Dados Pessoais (RIPD) para os fluxos de IA externa (Art. 38)?

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q48
<!-- pfq-id: d5a1480f-4247-4e94-8ef6-ba6985c2e063 -->

**Pergunta**: Os controles de segurança (C01 a C15) foram implementados e testados para dados reais (Art. 46)?

**Resposta**:

As medidas previstas atendem como requisitos ao Art. 46, mas sua eficácia deverá ser testada antes de produção. Controles mínimos: criptografia em trânsito e repouso, cofre de segredos, RBAC por tenant/caso/documento, MFA para perfis sensíveis, segregação multi-tenant, logs de auditoria, backup criptografado, anonimização/pseudonimização, SAST/DAST, pentest, revisão de permissões e trilha de incidentes. O registro de testes de eficácia ainda deve ser produzido na fase de homologação.

## Q49
<!-- pfq-id: e3d50f9c-a033-489c-9e36-ba4b66e368fc -->

**Pergunta**: Qual o plano de resposta para incidentes de segurança envolvendo dados pessoais, incluindo a comunicação à ANPD e aos titulares (Art. 48)?

**Resposta**:

O plano de resposta a incidentes deverá ser formalizado antes do piloto produtivo e incluir: identificação, classificação de severidade, contenção, preservação de evidências, análise de impacto aos titulares, decisão sobre comunicação à ANPD e titulares, plano de remediação, lições aprendidas e registro no inventário de incidentes. O prazo e o formato de comunicação seguirão a regulamentação vigente da ANPD; enquanto não houver avaliação completa, o requisito interno será comunicar incidentes relevantes à direção/DPO imediatamente e preparar comunicação externa sem atraso injustificado.

## Q50
<!-- pfq-id: 380f5f88-89d3-4b47-afb1-21ed0cf86ba7 -->

**Pergunta**: Como os titulares exercerão seus direitos (Art. 18)?

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q51
<!-- pfq-id: 7c16e423-90a7-43c5-80cc-4764d2019069 -->

**Pergunta**: Está prevista a elaboração de Relatório de Impacto à Proteção de Dados Pessoais (Art. 38) para tratamentos de alto risco, como o uso de IA na análise de risco?

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q52
<!-- pfq-id: e89f70cc-1896-47f5-86dc-6b50d653e5e9 -->

**Pergunta**: Existe previsão de transferência internacional de dados? Em caso positivo, sob qual hipótese do Art. 33?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q53
<!-- pfq-id: 27b587b8-9c9b-49c3-a4ef-1169e91eeb95 -->

**Pergunta**: Foi elaborado Relatório de Impacto à Proteção de Dados Pessoais (Art. 38) para o tratamento de dados sensíveis e uso de IA?

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q54
<!-- pfq-id: 2c44dbf6-0bc7-4342-bd5e-9822bc90a4e8 -->

**Pergunta**: Como serão garantidos aos titulares os direitos de confirmação, acesso, correção, portabilidade, eliminação e revisão de decisões automatizadas (Art. 18)?

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q55
<!-- pfq-id: 65fc1a8d-e866-4295-a0d7-a6e7f3578006 -->

**Pergunta**: Há plano de comunicação de incidente de segurança à ANPD e aos titulares? (Art. 48)

**Resposta**:

O plano de resposta a incidentes deverá ser formalizado antes do piloto produtivo e incluir: identificação, classificação de severidade, contenção, preservação de evidências, análise de impacto aos titulares, decisão sobre comunicação à ANPD e titulares, plano de remediação, lições aprendidas e registro no inventário de incidentes. O prazo e o formato de comunicação seguirão a regulamentação vigente da ANPD; enquanto não houver avaliação completa, o requisito interno será comunicar incidentes relevantes à direção/DPO imediatamente e preparar comunicação externa sem atraso injustificado.

## Q56
<!-- pfq-id: bd4ffadf-5194-4f84-aa10-079870e8f6d6 -->

**Pergunta**: Quais são as salvaguardas para transferência internacional quando provedores externos de IA forem utilizados (Art. 33 a 36)?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q57
<!-- pfq-id: 5b938e5f-272b-46ae-8313-630f30ea348b -->

**Pergunta**: Haverá habilitação de IA externa, backup cloud ou suporte remoto que implique transferência internacional, e quais garantias contratuais serão adotadas (Art. 33)?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q58
<!-- pfq-id: 0f360674-8871-4f11-8cd5-0957c534ae04 -->

**Pergunta**: Como será tratada a transferência internacional de dados para provedores de IA ou serviços externos? Há salvaguardas, cláusulas-padrão ou exceções legais (Art. 33 a 36)?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q59
<!-- pfq-id: d72a13be-96b4-4793-9632-4c200851bf2c -->

**Pergunta**: Qual é a política de retenção e eliminação dos dados pessoais após o término do tratamento (Art. 15, I e Art. 16)?

**Resposta**:

A política de retenção deverá ser formalizada antes do piloto produtivo e parametrizada por categoria: dados cadastrais de clientes enquanto durar a relação e pelos prazos legais/defesa judicial; documentos processuais enquanto houver processo ativo e prazo de guarda definido pelo escritório; logs de auditoria pelo prazo necessário à segurança, compliance e defesa; prompts/respostas de IA por período reduzido e com hash/mascaramento quando possível; backups conforme política 3-2-1 e expurgo programado. A eliminação será segura, auditável e bloqueada quando houver obrigação legal, ordem judicial, processo ativo ou necessidade de exercício regular de direitos.

## Q60
<!-- pfq-id: 298eaa69-d632-48c2-bedf-285a4e15f148 -->

**Pergunta**: Haverá compartilhamento de dados com terceiros (ex.: plataformas de automação, DataJud)? Em que base legal?

**Resposta**:

Haverá compartilhamento controlado com terceiros quando necessário: provedores de infraestrutura, LLM, observabilidade, assinatura/armazenamento, DataJud/CNJ, PDPJ/DJE, CNA/OAB, BCB/SGS e suporte técnico. Cada compartilhamento deverá ter finalidade, base legal, contrato ou termo aplicável, classificação de dados, medidas de segurança, retenção, suboperadores e registro no inventário de tratamento. Consulta a DataJud é consumo de dados públicos judiciais; envio de dados do escritório para terceiros dependerá de minimização, necessidade e salvaguardas contratuais.

## Q61
<!-- pfq-id: a067d21f-42ec-4c31-bafb-30d4404156e5 -->

**Pergunta**: Qual o prazo de retenção dos dados pessoais e a política de eliminação após o término da finalidade (Art. 15, Art. 16)?

**Resposta**:

A política de retenção deverá ser formalizada antes do piloto produtivo e parametrizada por categoria: dados cadastrais de clientes enquanto durar a relação e pelos prazos legais/defesa judicial; documentos processuais enquanto houver processo ativo e prazo de guarda definido pelo escritório; logs de auditoria pelo prazo necessário à segurança, compliance e defesa; prompts/respostas de IA por período reduzido e com hash/mascaramento quando possível; backups conforme política 3-2-1 e expurgo programado. A eliminação será segura, auditável e bloqueada quando houver obrigação legal, ordem judicial, processo ativo ou necessidade de exercício regular de direitos.

## Q62
<!-- pfq-id: fb301527-03fe-47b9-be18-a9a350b291c6 -->

**Pergunta**: Por quanto tempo os dados pessoais serão armazenados e qual o procedimento para eliminação após o término do tratamento (Art. 15, Art. 16)?

**Resposta**:

A política de retenção deverá ser formalizada antes do piloto produtivo e parametrizada por categoria: dados cadastrais de clientes enquanto durar a relação e pelos prazos legais/defesa judicial; documentos processuais enquanto houver processo ativo e prazo de guarda definido pelo escritório; logs de auditoria pelo prazo necessário à segurança, compliance e defesa; prompts/respostas de IA por período reduzido e com hash/mascaramento quando possível; backups conforme política 3-2-1 e expurgo programado. A eliminação será segura, auditável e bloqueada quando houver obrigação legal, ordem judicial, processo ativo ou necessidade de exercício regular de direitos.

## Q63
<!-- pfq-id: 1a27d93d-4504-4bb7-9c28-b60602de2a2c -->

**Pergunta**: Qual a política de retenção de dados por categoria e como se dá a eliminação segura após o término da finalidade?

**Resposta**:

A política de retenção deverá ser formalizada antes do piloto produtivo e parametrizada por categoria: dados cadastrais de clientes enquanto durar a relação e pelos prazos legais/defesa judicial; documentos processuais enquanto houver processo ativo e prazo de guarda definido pelo escritório; logs de auditoria pelo prazo necessário à segurança, compliance e defesa; prompts/respostas de IA por período reduzido e com hash/mascaramento quando possível; backups conforme política 3-2-1 e expurgo programado. A eliminação será segura, auditável e bloqueada quando houver obrigação legal, ordem judicial, processo ativo ou necessidade de exercício regular de direitos.

## Q64
<!-- pfq-id: c09047a8-2dfe-4eb1-a488-e9586372d781 -->

**Pergunta**: Existe um plano formal de comunicação de incidentes de segurança à ANPD e aos titulares (Art. 48)?

**Resposta**:

O plano de resposta a incidentes deverá ser formalizado antes do piloto produtivo e incluir: identificação, classificação de severidade, contenção, preservação de evidências, análise de impacto aos titulares, decisão sobre comunicação à ANPD e titulares, plano de remediação, lições aprendidas e registro no inventário de incidentes. O prazo e o formato de comunicação seguirão a regulamentação vigente da ANPD; enquanto não houver avaliação completa, o requisito interno será comunicar incidentes relevantes à direção/DPO imediatamente e preparar comunicação externa sem atraso injustificado.

## Q65
<!-- pfq-id: d07780d9-a38f-45f5-b032-5e88e3544f32 -->

**Pergunta**: A política de consentimento para finalidades acessórias será formalizada e registrada (Art. 8º e 9º)?

**Resposta**:

O consentimento será usado apenas quando a finalidade não puder ser adequadamente sustentada por contrato, obrigação legal, exercício regular de direitos ou legítimo interesse documentado. Quando exigido, será específico, destacado, inequívoco, registrado com versão do termo, finalidade, data/hora, canal, titular, forma de coleta e mecanismo simples de revogação. Para dados sensíveis, se o consentimento for usado excepcionalmente, deverá ser específico e destacado para finalidade determinada.

## Q66
<!-- pfq-id: 22907dca-c068-48ff-8bca-a727f4a6b99f -->

**Pergunta**: O consentimento para o tratamento de dados, quando necessário, será coletado de forma inequívoca e com finalidades específicas? Haverá mecanismo de revogação fácil e inequívoco (Art. 9º)?

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.

## Q67
<!-- pfq-id: 8624e49e-ff68-4d2e-850f-30cb875ec908 -->

**Pergunta**: Como o sistema garantirá a segurança e o sigilo dos dados, incluindo medidas preventivas e reativas contra incidentes (Art. 46 e Art. 48)?

**Resposta**:

O plano de resposta a incidentes deverá ser formalizado antes do piloto produtivo e incluir: identificação, classificação de severidade, contenção, preservação de evidências, análise de impacto aos titulares, decisão sobre comunicação à ANPD e titulares, plano de remediação, lições aprendidas e registro no inventário de incidentes. O prazo e o formato de comunicação seguirão a regulamentação vigente da ANPD; enquanto não houver avaliação completa, o requisito interno será comunicar incidentes relevantes à direção/DPO imediatamente e preparar comunicação externa sem atraso injustificado.

## Q68
<!-- pfq-id: 2681f38b-3e10-40be-bb03-21b7c55ab623 -->

**Pergunta**: Foi elaborado um Relatório de Impacto à Proteção de Dados (RIPD) para esse tratamento de dados? (Art. 38)

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q69
<!-- pfq-id: d49a5969-28e1-4a6d-846b-88f18a85e229 -->

**Pergunta**: Como o sistema documenta a finalidade, adequação e necessidade do tratamento de cada dado pessoal (Art. 6º)?

**Resposta**:

Sim. O inventário das operações de tratamento deverá ser elaborado antes da produção e mantido no Admin. Para cada operação serão registrados: finalidade, categoria de dado, titular, base legal, necessidade, adequação, origem, compartilhamentos, retenção, controles de segurança, operador/suboperador, transferência internacional, risco e responsável. O sistema deve impedir criação de novos fluxos de tratamento sem finalidade e base legal cadastradas.

## Q70
<!-- pfq-id: 280c7416-69eb-48ce-86a2-8c542ce1863a -->

**Pergunta**: Como o sistema trata dados de menores ou outras categorias vulneráveis?

**Resposta**:

Dados de menores ou titulares vulneráveis poderão aparecer em processos de família, infância, saúde, previdenciário, trabalhista ou criminal. O sistema deverá classificar esses casos como alto risco, exigir nível de sigilo elevado, restringir acesso por RBAC, impedir envio a LLM externo sem anonimização/pseudonimização reforçada, registrar base legal e exigir revisão do DPO/advogado responsável quando houver compartilhamento ou exportação.

## Q71
<!-- pfq-id: 5f931a20-9891-4786-98af-04cc78e6747e -->

**Pergunta**: Qual a política de retenção e eliminação de dados pessoais (Art. 15 e 16)?

**Resposta**:

A política de retenção deverá ser formalizada antes do piloto produtivo e parametrizada por categoria: dados cadastrais de clientes enquanto durar a relação e pelos prazos legais/defesa judicial; documentos processuais enquanto houver processo ativo e prazo de guarda definido pelo escritório; logs de auditoria pelo prazo necessário à segurança, compliance e defesa; prompts/respostas de IA por período reduzido e com hash/mascaramento quando possível; backups conforme política 3-2-1 e expurgo programado. A eliminação será segura, auditável e bloqueada quando houver obrigação legal, ordem judicial, processo ativo ou necessidade de exercício regular de direitos.

## Q72
<!-- pfq-id: e7fa0e71-f3e7-42ab-8dd7-abf0aabdf628 -->

**Pergunta**: Para transferências internacionais decorrentes do uso de APIs de IA externas, qual hipótese do Art. 33 será adotada? Existem cláusulas-padrão contratuais ou certificados?

**Resposta**:

Poderá haver transferência internacional se forem utilizados provedores externos de LLM, armazenamento em nuvem, observabilidade, suporte remoto ou backup fora do Brasil. Essa transferência deverá ser bloqueada por padrão até que o Admin registre país/região, provedor, finalidade, categorias de dados, base legal, salvaguarda do Art. 33, contrato com cláusulas de proteção de dados, política de retenção, suboperadores e opção de anonimização/pseudonimização. A preferência do AJA será enviar apenas dados minimizados e pseudonimizados para provedores externos.

## Q73
<!-- pfq-id: 118ba2ad-8c44-4345-a90e-1115abc5e858 -->

**Pergunta**: Há previsão de obtenção de consentimento específico, destacado e por escrito quando exigido para dados sensíveis?

**Resposta**:

Sim, há possibilidade de tratamento de dados pessoais sensíveis no AJA, pois processos e documentos jurídicos podem conter informações de saúde, vida familiar, biometria, dados criminais, origem racial/étnica, convicções e dados de menores. A base preferencial será o exercício regular de direitos em processo judicial/administrativo/arbitral e o cumprimento de obrigação legal/regulatória. Salvaguardas: minimização, classificação de sigilo, RBAC, MFA, criptografia, segregação por tenant, logs, retenção definida, anonimização/pseudonimização antes de IA externa e revisão humana obrigatória.

## Q74
<!-- pfq-id: efd17106-5641-457b-9748-28a50b8ad29c -->

**Pergunta**: O sistema prevê a elaboração de Relatório de Impacto à Proteção de Dados (RIPD) para tratamentos de alto risco, conforme Art. 38?

**Resposta**:

Sim. O RIPD deverá ser elaborado antes do piloto produtivo para fluxos de alto risco: tratamento de dados sensíveis, uso de IA externa, integração com bases judiciais, geração de peças, análise de risco/conflito, transferência internacional e retenção documental. O RIPD deverá conter finalidade, categorias de dados, titulares, bases legais, necessidade/proporcionalidade, riscos aos titulares, salvaguardas, avaliação de fornecedores, retenção, descarte, controles técnicos e aprovação do DPO/responsável de privacidade.

## Q75
<!-- pfq-id: 56af6568-1d4c-4958-849f-435a1ac5214c -->

**Pergunta**: Existem medidas de segurança técnicas e administrativas proporcionais ao risco (Art. 46) e auditoria de conformidade prevista?

**Resposta**:

As medidas previstas atendem como requisitos ao Art. 46, mas sua eficácia deverá ser testada antes de produção. Controles mínimos: criptografia em trânsito e repouso, cofre de segredos, RBAC por tenant/caso/documento, MFA para perfis sensíveis, segregação multi-tenant, logs de auditoria, backup criptografado, anonimização/pseudonimização, SAST/DAST, pentest, revisão de permissões e trilha de incidentes. O registro de testes de eficácia ainda deve ser produzido na fase de homologação.

## Q76
<!-- pfq-id: 23fbf140-e9e4-4756-931c-e38d12d32f2e -->

**Pergunta**: Qual é o plano de resposta a incidentes de segurança com dados pessoais e como será comunicado à ANPD e aos titulares (Art. 48)?

**Resposta**:

O plano de resposta a incidentes deverá ser formalizado antes do piloto produtivo e incluir: identificação, classificação de severidade, contenção, preservação de evidências, análise de impacto aos titulares, decisão sobre comunicação à ANPD e titulares, plano de remediação, lições aprendidas e registro no inventário de incidentes. O prazo e o formato de comunicação seguirão a regulamentação vigente da ANPD; enquanto não houver avaliação completa, o requisito interno será comunicar incidentes relevantes à direção/DPO imediatamente e preparar comunicação externa sem atraso injustificado.

## Q77
<!-- pfq-id: 727e299b-85b4-4f4b-82ee-507f50c3a68a -->

**Pergunta**: As medidas de segurança descritas (criptografia, cofre, RBAC) atendem aos requisitos do Art. 46 de proteção contra acessos não autorizados, destruição ou vazamento? Há registro de testes de eficácia?

**Resposta**:

Os direitos dos titulares serão atendidos por Portal LGPD/canal do titular, com protocolo, identificação do solicitante, tipo de direito exercido, prazo, responsável, evidências e histórico. O sistema permitirá localizar dados por titular, corrigir dados cadastrais quando juridicamente permitido, exportar relatório, anonimizar/bloquear/eliminar quando não houver obrigação legal ou defesa judicial que justifique retenção, registrar oposição/revogação de consentimento e permitir revisão humana de qualquer decisão automatizada ou apoio de IA que produza efeito relevante.


---
