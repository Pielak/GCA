---
gca-followup-marker: v1
project_id: 24bf72c3-2ee8-45fd-b879-d3a00b347c39
persona_id: SEG
persona_name: Segurança
generated_at: 2026-05-05T01:39:22.214090+00:00
question_count: 59
---

# Perguntas em aberto — Segurança — Assistente Judicial para Advogados

Preencha as respostas abaixo de cada pergunta (substitua `<sua resposta aqui>`). Faça upload deste arquivo pela aba **Ingestão de Documentos**. NÃO altere as linhas com `<!-- pfq-id: ... -->`.

## Q1
<!-- pfq-id: 95161971-1a65-4f6d-bc32-9b65b75acf18 -->

**Pergunta**: Qual o nível ASVS exigido (1, 2 ou 3) e quais requisitos V2, V3, V4 devem ser aplicados ao sistema AJA como um todo (não apenas às integrações)?

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q2
<!-- pfq-id: 4c2fd091-29fb-4bcb-ad1d-d2f21c720cbb -->

**Pergunta**: Qual o nível ASVS alvo (1, 2 ou 3) e os casos de uso que exigem MFA para todos os papéis?

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q3
<!-- pfq-id: 4d63b167-5a30-4cd9-9c96-df1824ec1714 -->

**Pergunta**: Qual é o modelo de autenticação (OIDC, OAuth2, mTLS, SAML) e MFA exigido para usuários do módulo? (ASVS V2)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q4
<!-- pfq-id: efe34a27-f83a-45c0-9aa0-5d4f9351e8a1 -->

**Pergunta**: Qual nível ASVS é exigido para este sistema (1, 2 ou 3)?

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q5
<!-- pfq-id: 8e8ae106-84cc-4e7e-9d83-4ccf10eb6cb4 -->

**Pergunta**: Qual nível ASVS é exigido para o AJA (Level 1, 2 ou 3)? O documento não define.

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q6
<!-- pfq-id: 887c201a-c0ed-48ad-bd5a-49f99a813c3c -->

**Pergunta**: Qual nível ASVS é exigido (1, 2 ou 3)? O projeto assume como baseline mínimo o Level 2?

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q7
<!-- pfq-id: 6e2e75a8-a2b8-4e21-82cb-bd246c5160b3 -->

**Pergunta**: Qual versão específica de TLS e quais cipher suites serão suportados? (ASVS V9)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q8
<!-- pfq-id: 2e9d979a-413e-4dd1-b1c9-0403c1f2f522 -->

**Pergunta**: Há autenticação de usuários com login/senha, SSO? MFA é obrigatório para quais papéis (advogados, administradores)?

**Resposta**:

O MFA será obrigatório para perfis sensíveis: SysAdmin AJA, Admin do Escritório, Sócio/Gestor Jurídico, Advogado Sênior, DPO/Privacidade, DevOps/Suporte, usuários que aprovam peças finais, exportam lotes ou administram integrações/chaves. Para demais usuários, MFA será recomendado no MVP e poderá ser tornado obrigatório por política do tenant. Tecnologias aceitas: TOTP, WebAuthn/passkeys e códigos de recuperação; SMS não deve ser mecanismo preferencial.

## Q9
<!-- pfq-id: cac6d07e-9bc9-4680-b4bc-64fed2cffcb1 -->

**Pergunta**: Como é implementada a proteção contra ataques de força bruta (rate limiting, lockout, CAPTCHA)?

**Resposta**:

A proteção contra força bruta será implementada com rate limiting por IP, usuário, tenant e endpoint, bloqueio temporário progressivo após tentativas inválidas, detecção de credential stuffing, MFA para perfis sensíveis, CAPTCHA adaptativo apenas quando houver comportamento suspeito e alertas de segurança. Senhas devem ter hash Argon2id preferencialmente, ou bcrypt com custo adequado, sal único e política de senha compatível com boas práticas.

## Q10
<!-- pfq-id: c44de4c9-542d-494a-88f4-d715ca00921d -->

**Pergunta**: Existem papéis distintos (advogado, gestor, contador) com controle de acesso granular? Como é implementada a autorização? (ASVS V4, OWASP A01)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q11
<!-- pfq-id: 892ce95d-d041-4a8c-9b89-963f30d62b47 -->

**Pergunta**: A autenticação utiliza senha com hash forte (bcrypt/argon2)? Existe proteção contra força bruta (rate limiting, lockout)?

**Resposta**:

A proteção contra força bruta será implementada com rate limiting por IP, usuário, tenant e endpoint, bloqueio temporário progressivo após tentativas inválidas, detecção de credential stuffing, MFA para perfis sensíveis, CAPTCHA adaptativo apenas quando houver comportamento suspeito e alertas de segurança. Senhas devem ter hash Argon2id preferencialmente, ou bcrypt com custo adequado, sal único e política de senha compatível com boas práticas.

## Q12
<!-- pfq-id: 655a1947-f786-4166-995b-bfb3b060ab3b -->

**Pergunta**: MFA é obrigatório para quais papéis? Há suporte técnico para WebAuthn, TOTP ou similar?

**Resposta**:

O MFA será obrigatório para perfis sensíveis: SysAdmin AJA, Admin do Escritório, Sócio/Gestor Jurídico, Advogado Sênior, DPO/Privacidade, DevOps/Suporte, usuários que aprovam peças finais, exportam lotes ou administram integrações/chaves. Para demais usuários, MFA será recomendado no MVP e poderá ser tornado obrigatório por política do tenant. Tecnologias aceitas: TOTP, WebAuthn/passkeys e códigos de recuperação; SMS não deve ser mecanismo preferencial.

## Q13
<!-- pfq-id: 4bb0616a-be14-49af-b4dd-c1e742ebcea8 -->

**Pergunta**: Há MFA obrigatório para algum perfil (administrador, advogado sênior)? Se sim, qual mecanismo?

**Resposta**:

O MFA será obrigatório para perfis sensíveis: SysAdmin AJA, Admin do Escritório, Sócio/Gestor Jurídico, Advogado Sênior, DPO/Privacidade, DevOps/Suporte, usuários que aprovam peças finais, exportam lotes ou administram integrações/chaves. Para demais usuários, MFA será recomendado no MVP e poderá ser tornado obrigatório por política do tenant. Tecnologias aceitas: TOTP, WebAuthn/passkeys e códigos de recuperação; SMS não deve ser mecanismo preferencial.

## Q14
<!-- pfq-id: dd325fed-4a0e-4c13-980b-98838d4d7145 -->

**Pergunta**: Quais ferramentas de SAST, SCA e DAST serão integradas no pipeline CI/CD? (ASVS V14)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q15
<!-- pfq-id: d49bb10c-1126-4e41-8469-23c0d2ec3ef3 -->

**Pergunta**: Onde os segredos (chaves de API do DataJud, client secret SERPRO, certificados) serão armazenados e gerenciados? Existe um vault (HashiCorp, AWS KMS, etc.)?

**Resposta**:

Senhas, quando usadas, deverão ser armazenadas com Argon2id preferencialmente, ou bcrypt com custo configurado, sal único por senha e pepper protegido em cofre. A autenticação deve suportar política de senha forte, MFA, proteção contra força bruta, bloqueio temporário progressivo, rotação de refresh tokens e revogação imediata de sessões em caso de desligamento ou incidente.

## Q16
<!-- pfq-id: 79749c22-687a-4908-b273-032bfad09cd1 -->

**Pergunta**: Quais são os mecanismos de validação e sanitização de entrada para campos de texto, uploads de documentos e parâmetros de API?

**Resposta**:

O AJA deverá aplicar validação centralizada de entrada por schema, tamanho máximo, tipo, formato, allowlist de caracteres quando aplicável e normalização. APIs usarão validação por DTO/schema; banco de dados usará ORM ou prepared statements; campos textuais terão sanitização e output encoding contra XSS; uploads terão validação de MIME real, extensão, tamanho, antivírus, bloqueio de executáveis e armazenamento fora do webroot. Prompts para LLM e documentos ingeridos também passarão por filtros contra prompt injection, PII indevida e conteúdo malicioso.

## Q17
<!-- pfq-id: 945942da-462b-49df-a92f-ea487c9ae247 -->

**Pergunta**: A comunicação entre cliente e servidor utiliza TLS 1.2 ou superior? Quais cifras são aceitas? (ASVS V9)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q18
<!-- pfq-id: 480cf75d-ddbd-43e3-912a-3b79e9034ad6 -->

**Pergunta**: Há implementação de MFA? Qual tecnologia? É obrigatória para todos os perfis?

**Resposta**:

O MFA será obrigatório para perfis sensíveis: SysAdmin AJA, Admin do Escritório, Sócio/Gestor Jurídico, Advogado Sênior, DPO/Privacidade, DevOps/Suporte, usuários que aprovam peças finais, exportam lotes ou administram integrações/chaves. Para demais usuários, MFA será recomendado no MVP e poderá ser tornado obrigatório por política do tenant. Tecnologias aceitas: TOTP, WebAuthn/passkeys e códigos de recuperação; SMS não deve ser mecanismo preferencial.

## Q19
<!-- pfq-id: 46e4b7c6-5107-4937-86d4-57ef42d42d85 -->

**Pergunta**: Qual algoritmo de criptografia em repouso é utilizado (AES-256, XChaCha20)? Como as chaves são geridas (cofre local, derivação de senha)?

**Resposta**:

Senhas, quando usadas, deverão ser armazenadas com Argon2id preferencialmente, ou bcrypt com custo configurado, sal único por senha e pepper protegido em cofre. A autenticação deve suportar política de senha forte, MFA, proteção contra força bruta, bloqueio temporário progressivo, rotação de refresh tokens e revogação imediata de sessões em caso de desligamento ou incidente.

## Q20
<!-- pfq-id: 541a679d-9dae-4c98-9bd3-5485f7483e08 -->

**Pergunta**: Como é feita a gestão de sessão local? Tokens, cookies, timeout, rotação?

**Resposta**:

Segredos, chaves de API, certificados A1, client_secret, tokens de LLM e credenciais de integração devem ser armazenados exclusivamente em cofre de segredos. Para cloud, usar HashiCorp Vault, AWS Secrets Manager/KMS, Azure Key Vault ou GCP Secret Manager conforme plataforma escolhida. Para ambiente local, usar cofre criptográfico com chave protegida pelo sistema operacional e, quando houver banco local, SQLCipher com chaves derivadas por KDF forte. Segredos não podem ficar em frontend, logs, repositório Git, arquivos .env versionados ou banco comum. Deve haver rotação, expiração, auditoria de acesso e revogação imediata.

## Q21
<!-- pfq-id: ed6cf681-ee11-4f62-abe4-f69422af94f0 -->

**Pergunta**: Haverá integração com SIEM? Qual plataforma consumirá os logs de segurança? (ASVS V7)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q22
<!-- pfq-id: 935fa5ad-b8f2-4398-bf1b-cc612017d87e -->

**Pergunta**: Quais mecanismos de criptografia em repouso e algoritmos serão utilizados no banco local e backups? Como as chaves são rotacionadas?

**Resposta**:

Segredos, chaves de API, certificados A1, client_secret, tokens de LLM e credenciais de integração devem ser armazenados exclusivamente em cofre de segredos. Para cloud, usar HashiCorp Vault, AWS Secrets Manager/KMS, Azure Key Vault ou GCP Secret Manager conforme plataforma escolhida. Para ambiente local, usar cofre criptográfico com chave protegida pelo sistema operacional e, quando houver banco local, SQLCipher com chaves derivadas por KDF forte. Segredos não podem ficar em frontend, logs, repositório Git, arquivos .env versionados ou banco comum. Deve haver rotação, expiração, auditoria de acesso e revogação imediata.

## Q23
<!-- pfq-id: c471d3db-9fd5-4046-a78c-e746c4f3ddab -->

**Pergunta**: Como as chaves AES-256 são gerenciadas? Há um vault/KMS dedicado e rotação periódica?

**Resposta**:

Segredos, chaves de API, certificados A1, client_secret, tokens de LLM e credenciais de integração devem ser armazenados exclusivamente em cofre de segredos. Para cloud, usar HashiCorp Vault, AWS Secrets Manager/KMS, Azure Key Vault ou GCP Secret Manager conforme plataforma escolhida. Para ambiente local, usar cofre criptográfico com chave protegida pelo sistema operacional e, quando houver banco local, SQLCipher com chaves derivadas por KDF forte. Segredos não podem ficar em frontend, logs, repositório Git, arquivos .env versionados ou banco comum. Deve haver rotação, expiração, auditoria de acesso e revogação imediata.

## Q24
<!-- pfq-id: 2eab4cc9-9cb2-416d-bfc3-11b08b497e09 -->

**Pergunta**: Qual KMS ou vault é utilizado para gerenciar as chaves de cifragem em repouso (requisito citado em RNF-06)? (ASVS V6)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q25
<!-- pfq-id: 2b877780-de60-44da-aa76-e866a6c26efc -->

**Pergunta**: Como é gerenciada a sessão após o login? Utiliza tokens? Qual o tempo de expiração e mecanismo de revogação?

**Resposta**:

Segredos, chaves de API, certificados A1, client_secret, tokens de LLM e credenciais de integração devem ser armazenados exclusivamente em cofre de segredos. Para cloud, usar HashiCorp Vault, AWS Secrets Manager/KMS, Azure Key Vault ou GCP Secret Manager conforme plataforma escolhida. Para ambiente local, usar cofre criptográfico com chave protegida pelo sistema operacional e, quando houver banco local, SQLCipher com chaves derivadas por KDF forte. Segredos não podem ficar em frontend, logs, repositório Git, arquivos .env versionados ou banco comum. Deve haver rotação, expiração, auditoria de acesso e revogação imediata.

## Q26
<!-- pfq-id: 478b3981-d734-479d-bb09-fe2ad5d8894a -->

**Pergunta**: Há validação centralizada de entrada para todas as integrações (conectores, IA, arquivos)? Realizam-se testes de SAST/DAST?

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q27
<!-- pfq-id: 3a1f2392-ede0-4b0c-b8f5-1b1c91d63035 -->

**Pergunta**: Qual KMS gerencia as chaves do SQLCipher e do cofre de segredos? Proteção de memória para chaves é considerada?

**Resposta**:

A comunicação deverá usar TLS 1.2 no mínimo e TLS 1.3 preferencialmente. Cifras fracas, SSL, TLS 1.0/1.1, RC4, 3DES, MD5 e SHA-1 devem ser bloqueados. Para TLS 1.3, usar conjuntos modernos como TLS_AES_128_GCM_SHA256 e TLS_AES_256_GCM_SHA384. Para TLS 1.2, aceitar apenas ECDHE com AES-GCM ou CHACHA20-POLY1305, com validação completa de certificados. Conectores externos devem usar allowlist de domínios e validação rigorosa de certificado.

## Q28
<!-- pfq-id: 20744943-bafd-488a-b11c-f534070628a3 -->

**Pergunta**: O MFA será aplicado a todos os usuários ou apenas a perfis sensíveis? (ASVS V2.1)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q29
<!-- pfq-id: f9b95b91-ffa7-4fb9-9dab-58f67109548a -->

**Pergunta**: Há análises SCA/SAST/DAST integradas à esteira CI/CD? Com que frequência serão executadas?

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q30
<!-- pfq-id: e9d73e8e-43da-4e34-83d4-66d20e1e6cd1 -->

**Pergunta**: Há varredura SCA/SAST/DAST no pipeline? Os artefatos de deploy são assinados e verificados (ex: cosign)?

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q31
<!-- pfq-id: 0c0f6798-41df-4649-a542-8a12a0f22872 -->

**Pergunta**: O módulo valida e sanitiza entradas contra injeção (ex: parâmetros via API, upload de planilhas)? Há uso de bibliotecas de codificação de saída? (ASVS V5)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q32
<!-- pfq-id: a0a0e972-fc38-4cbd-abac-3029cb4eea80 -->

**Pergunta**: O acesso ao banco SQLite utiliza parâmetros preparados (prepared statements) ou ORM para evitar injeção SQL?

**Resposta**:

O AJA deverá aplicar validação centralizada de entrada por schema, tamanho máximo, tipo, formato, allowlist de caracteres quando aplicável e normalização. APIs usarão validação por DTO/schema; banco de dados usará ORM ou prepared statements; campos textuais terão sanitização e output encoding contra XSS; uploads terão validação de MIME real, extensão, tamanho, antivírus, bloqueio de executáveis e armazenamento fora do webroot. Prompts para LLM e documentos ingeridos também passarão por filtros contra prompt injection, PII indevida e conteúdo malicioso.

## Q33
<!-- pfq-id: 318018d7-ef56-4fe0-aa44-3eeec2cd7b12 -->

**Pergunta**: O pipeline CI/CD inclui verificação de assinatura de dependências e varredura de vulnerabilidades (SCA)?

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q34
<!-- pfq-id: bb815101-9924-4ecb-a65f-da9efafd8d04 -->

**Pergunta**: Quais versões de TLS e suites de cifra são aceitas para conectores externos? Há política de validação de certificados?

**Resposta**:

A comunicação deverá usar TLS 1.2 no mínimo e TLS 1.3 preferencialmente. Cifras fracas, SSL, TLS 1.0/1.1, RC4, 3DES, MD5 e SHA-1 devem ser bloqueados. Para TLS 1.3, usar conjuntos modernos como TLS_AES_128_GCM_SHA256 e TLS_AES_256_GCM_SHA384. Para TLS 1.2, aceitar apenas ECDHE com AES-GCM ou CHACHA20-POLY1305, com validação completa de certificados. Conectores externos devem usar allowlist de domínios e validação rigorosa de certificado.

## Q35
<!-- pfq-id: 8cebe1c6-5b3c-4f34-b403-677b3036b54d -->

**Pergunta**: Como será feita a validação de entrada em todos os endpoints (parametrização, sanitização, output encoding) para prevenir SQLi, XSS e command injection? (ASVS V5)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q36
<!-- pfq-id: 09b32b10-b8e4-47d3-8674-e59c729c29aa -->

**Pergunta**: Para qual SIEM os logs de segurança serão enviados? Como são garantidas a imutabilidade e retenção dos logs?

**Resposta**:

O AJA deverá produzir logs estruturados de segurança e auditoria para integração com SIEM ou stack de observabilidade. A plataforma específica ainda deve ser definida na Sprint 0; opções aceitáveis são Wazuh/ELK/OpenSearch, Grafana Loki, Splunk ou serviço cloud equivalente. Logs críticos devem incluir autenticação, falhas de login, alterações de RBAC, uso de segredos, exportações, chamadas LLM, consultas externas, eventos LGPD e alterações de templates/prazos. Logs devem ter retenção configurável, proteção contra alteração e alertas para comportamento suspeito.

## Q37
<!-- pfq-id: 058a91b0-9f5d-4c9f-ad8f-4e52874940ab -->

**Pergunta**: Os contêineres seguem um baseline CIS/Docker? Como segredos (tokens, senhas) são injetados (ex: Kubernetes Secrets, SealedSecrets, Vault)?

**Resposta**:

Senhas, quando usadas, deverão ser armazenadas com Argon2id preferencialmente, ou bcrypt com custo configurado, sal único por senha e pepper protegido em cofre. A autenticação deve suportar política de senha forte, MFA, proteção contra força bruta, bloqueio temporário progressivo, rotação de refresh tokens e revogação imediata de sessões em caso de desligamento ou incidente.

## Q38
<!-- pfq-id: c2a85183-9488-43b8-9759-49ef74115506 -->

**Pergunta**: Há análise SCA/SAST/DAST no pipeline de CI/CD para detectar vulnerabilidades em dependências? (OWASP A06/A08)

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q39
<!-- pfq-id: 0c2589c5-8327-437f-ad9d-b92ee79a74c0 -->

**Pergunta**: Existe validação de entrada para campos como nomes, CPF, datas e documentos, incluindo tamanho e caracteres perigosos?

**Resposta**:

O AJA deverá aplicar validação centralizada de entrada por schema, tamanho máximo, tipo, formato, allowlist de caracteres quando aplicável e normalização. APIs usarão validação por DTO/schema; banco de dados usará ORM ou prepared statements; campos textuais terão sanitização e output encoding contra XSS; uploads terão validação de MIME real, extensão, tamanho, antivírus, bloqueio de executáveis e armazenamento fora do webroot. Prompts para LLM e documentos ingeridos também passarão por filtros contra prompt injection, PII indevida e conteúdo malicioso.

## Q40
<!-- pfq-id: b0dde188-b38e-4e5e-94f3-9c359c91a036 -->

**Pergunta**: Os logs de auditoria são assinados ou armazenados de forma imutável? Há integração com SIEM ou mecanismo de alerta para incidentes?

**Resposta**:

O AJA deverá aplicar validação centralizada de entrada por schema, tamanho máximo, tipo, formato, allowlist de caracteres quando aplicável e normalização. APIs usarão validação por DTO/schema; banco de dados usará ORM ou prepared statements; campos textuais terão sanitização e output encoding contra XSS; uploads terão validação de MIME real, extensão, tamanho, antivírus, bloqueio de executáveis e armazenamento fora do webroot. Prompts para LLM e documentos ingeridos também passarão por filtros contra prompt injection, PII indevida e conteúdo malicioso.

## Q41
<!-- pfq-id: 71fb95b2-c211-4dcd-8ec8-b2a33cbc2ce1 -->

**Pergunta**: Existe SAST/SCA/secret scan integrado ao pipeline? Qual ferramenta?

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q42
<!-- pfq-id: 267a6bcf-aa28-436a-98b5-512b9da6908b -->

**Pergunta**: Existe autorização em nível de objeto (BOLA) para cada endpoint de API? Como é garantido que um tenant não acessa dados de outro? (ASVS V4, API1)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q43
<!-- pfq-id: 87810229-c52e-457e-ab09-230ba7eb6f1d -->

**Pergunta**: Existe um runbook de resposta a incidentes para tratar acessos não autorizados ou vazamento de dados via mocks/fixtures?

**Resposta**:

Sim, deverá existir runbook formal de resposta a incidentes antes do piloto produtivo. O runbook cobrirá acesso não autorizado, vazamento de documentos, exposição de PII em prompt/LLM, perda de dispositivo, segredo comprometido, falha de conector, corrupção de backup e uso indevido de mocks/fixtures. Deve definir responsáveis, severidade, contenção, comunicação ao controlador/DPO, avaliação de comunicação à ANPD/titulares, evidências, recuperação e lições aprendidas.

## Q44
<!-- pfq-id: 547c050b-6fba-4810-8c9c-9fef09fd2abb -->

**Pergunta**: Qual a estratégia de logging e monitoramento? Existe um SIEM consumindo logs de auditoria? A retenção atende a requisitos legais?

**Resposta**:

O AJA deverá produzir logs estruturados de segurança e auditoria para integração com SIEM ou stack de observabilidade. A plataforma específica ainda deve ser definida na Sprint 0; opções aceitáveis são Wazuh/ELK/OpenSearch, Grafana Loki, Splunk ou serviço cloud equivalente. Logs críticos devem incluir autenticação, falhas de login, alterações de RBAC, uso de segredos, exportações, chamadas LLM, consultas externas, eventos LGPD e alterações de templates/prazos. Logs devem ter retenção configurável, proteção contra alteração e alertas para comportamento suspeito.

## Q45
<!-- pfq-id: e19825c9-4aba-4140-abec-164bf9bb4f61 -->

**Pergunta**: O sistema integra logs de segurança com um SIEM e define alertas para tentativas de acesso indevido? (ASVS V7)

**Resposta**:

O baseline de segurança do AJA deverá ser OWASP ASVS Level 2 para todo o sistema, com aplicação seletiva de controles Level 3 em módulos críticos: cofre de segredos, integrações judiciais, LLM Gateway, exportação documental, Admin, RBAC e tratamento de dados sensíveis. Devem ser cobertos especialmente V2 Autenticação, V3 Sessão, V4 Controle de Acesso, V5 Validação de Entrada, V6 Criptografia, V7 Logs, V8 Dados, V9 Comunicação, V12 Arquivos, V13 APIs e V14 Configuração/Build.

## Q46
<!-- pfq-id: 44be0e0f-5d75-4d93-8b81-30cf9bf2b8fd -->

**Pergunta**: Há algum processo de análise de composição de software (SCA) ou teste estático (SAST) no pipeline de build?

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q47
<!-- pfq-id: 5f428aba-3ac1-4d44-9031-ad74bedc11c4 -->

**Pergunta**: Existe um runbook formal para resposta a incidentes envolvendo dados sensíveis ou violação de sigilo profissional?

**Resposta**:

O AJA deverá aplicar validação centralizada de entrada por schema, tamanho máximo, tipo, formato, allowlist de caracteres quando aplicável e normalização. APIs usarão validação por DTO/schema; banco de dados usará ORM ou prepared statements; campos textuais terão sanitização e output encoding contra XSS; uploads terão validação de MIME real, extensão, tamanho, antivírus, bloqueio de executáveis e armazenamento fora do webroot. Prompts para LLM e documentos ingeridos também passarão por filtros contra prompt injection, PII indevida e conteúdo malicioso.

## Q48
<!-- pfq-id: 4e936921-f4cc-4bf5-8f01-0550b50ad895 -->

**Pergunta**: Qual SIEM ou sistema de monitoramento consome os logs de segurança? Há alertas e runbook de incidente?

**Resposta**:

O AJA deverá produzir logs estruturados de segurança e auditoria para integração com SIEM ou stack de observabilidade. A plataforma específica ainda deve ser definida na Sprint 0; opções aceitáveis são Wazuh/ELK/OpenSearch, Grafana Loki, Splunk ou serviço cloud equivalente. Logs críticos devem incluir autenticação, falhas de login, alterações de RBAC, uso de segredos, exportações, chamadas LLM, consultas externas, eventos LGPD e alterações de templates/prazos. Logs devem ter retenção configurável, proteção contra alteração e alertas para comportamento suspeito.

## Q49
<!-- pfq-id: 3f7e4db9-11f3-4235-b399-3304cdf5fc89 -->

**Pergunta**: A pipeline de CI/CD realiza verificação de integridade (assinatura de artefatos, checksums)? (A08)

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.

## Q50
<!-- pfq-id: cb1567a5-3bcc-46e4-902a-56ab4b265646 -->

**Pergunta**: As chamadas a sistemas externos (DataJud, repositórios de jurisprudência) são restritas por uma allowlist? O SSRF é mitigado?

**Resposta**:

Chamadas externas serão feitas apenas pelo Integration Gateway, com allowlist de domínios, bloqueio de IPs privados/link-local, validação de URL, DNS pinning quando aplicável, timeout, limite de redirecionamentos, validação de certificado e proibição de URL arbitrária enviada pelo usuário. Isso mitiga SSRF e impede que conectores acessem destinos não autorizados.

## Q51
<!-- pfq-id: 59bf58e2-b678-429a-9370-4010c4ac42c8 -->

**Pergunta**: Quais versões de TLS e cipher suites são usadas nas chamadas às APIs externas (DataJud, IA)?

**Resposta**:

A comunicação deverá usar TLS 1.2 no mínimo e TLS 1.3 preferencialmente. Cifras fracas, SSL, TLS 1.0/1.1, RC4, 3DES, MD5 e SHA-1 devem ser bloqueados. Para TLS 1.3, usar conjuntos modernos como TLS_AES_128_GCM_SHA256 e TLS_AES_256_GCM_SHA384. Para TLS 1.2, aceitar apenas ECDHE com AES-GCM ou CHACHA20-POLY1305, com validação completa de certificados. Conectores externos devem usar allowlist de domínios e validação rigorosa de certificado.

## Q52
<!-- pfq-id: 3b27b8bb-f099-4953-829e-0fad3bd9e73f -->

**Pergunta**: Como são tratadas as vulnerabilidades em componentes de terceiros (bibliotecas, IA, conectores)? Há processo de atualização monitorado?

**Resposta**:

Vulnerabilidades de terceiros serão geridas por inventário SBOM, SCA contínuo, Dependabot/Renovate, classificação por severidade, janela de correção por criticidade e validação em regressão. Dependências críticas de IA, conectores, criptografia e autenticação terão monitoramento proativo de changelog/CVE e plano de atualização emergencial.

## Q53
<!-- pfq-id: 67d7078d-0d61-4427-b0b6-e60ec1e26bd6 -->

**Pergunta**: Os templates e dados fornecidos pelo usuário são parametrizados contra SQL injection? Há validação de input contra XSS?

**Resposta**:

O AJA deverá aplicar validação centralizada de entrada por schema, tamanho máximo, tipo, formato, allowlist de caracteres quando aplicável e normalização. APIs usarão validação por DTO/schema; banco de dados usará ORM ou prepared statements; campos textuais terão sanitização e output encoding contra XSS; uploads terão validação de MIME real, extensão, tamanho, antivírus, bloqueio de executáveis e armazenamento fora do webroot. Prompts para LLM e documentos ingeridos também passarão por filtros contra prompt injection, PII indevida e conteúdo malicioso.

## Q54
<!-- pfq-id: faea6526-4606-42bc-9649-1a59ec2eff13 -->

**Pergunta**: O sistema contempla alertas de segurança automatizados ou envio de logs para um SIEM?

**Resposta**:

O AJA deverá produzir logs estruturados de segurança e auditoria para integração com SIEM ou stack de observabilidade. A plataforma específica ainda deve ser definida na Sprint 0; opções aceitáveis são Wazuh/ELK/OpenSearch, Grafana Loki, Splunk ou serviço cloud equivalente. Logs críticos devem incluir autenticação, falhas de login, alterações de RBAC, uso de segredos, exportações, chamadas LLM, consultas externas, eventos LGPD e alterações de templates/prazos. Logs devem ter retenção configurável, proteção contra alteração e alertas para comportamento suspeito.

## Q55
<!-- pfq-id: da273cf0-ebbc-4c97-a37d-f1d2a649be5e -->

**Pergunta**: Os conectores externos validam e restringem as URLs de destino para prevenir SSRF?

**Resposta**:

Chamadas externas serão feitas apenas pelo Integration Gateway, com allowlist de domínios, bloqueio de IPs privados/link-local, validação de URL, DNS pinning quando aplicável, timeout, limite de redirecionamentos, validação de certificado e proibição de URL arbitrária enviada pelo usuário. Isso mitiga SSRF e impede que conectores acessem destinos não autorizados.

## Q56
<!-- pfq-id: ad09aad4-4304-4735-85e2-df46ee04c642 -->

**Pergunta**: Há política de backup imutável e testes de restauração documentados?

**Resposta**:

Backups deverão seguir política 3-2-1: três cópias, duas mídias/locais lógicos distintos e uma cópia isolada/imutável quando possível. Backups devem ser criptografados, assinados ou acompanhados de hash/checksum, testados periodicamente, com RPO/RTO definidos por ambiente. Para o MVP, recomenda-se RPO de até 24h e RTO de até 8h para dados jurídicos, ajustável conforme criticidade do escritório.

## Q57
<!-- pfq-id: 1f9798d7-2f91-473b-acf9-b8304cc0815a -->

**Pergunta**: O backup local é assinado digitalmente para garantir integridade?

**Resposta**:

Dados em repouso deverão ser criptografados com AES-256-GCM ou equivalente aprovado pela plataforma. Bancos gerenciados devem usar criptografia nativa com KMS; documentos e backups devem ser criptografados antes do armazenamento; banco local, se existir, deve usar SQLCipher ou solução equivalente. Chaves serão mantidas em KMS/Vault, com rotação mínima anual ou imediata em incidente, segregação por ambiente/tenant quando aplicável, controle de acesso, auditoria e testes de restauração.

## Q58
<!-- pfq-id: 3ee422f6-e678-450e-9580-efcb5edee31c -->

**Pergunta**: Qual é a política de rotação de segredos e tokens de acesso, e ela está automatizada?

**Resposta**:

Segredos, chaves de API, certificados A1, client_secret, tokens de LLM e credenciais de integração devem ser armazenados exclusivamente em cofre de segredos. Para cloud, usar HashiCorp Vault, AWS Secrets Manager/KMS, Azure Key Vault ou GCP Secret Manager conforme plataforma escolhida. Para ambiente local, usar cofre criptográfico com chave protegida pelo sistema operacional e, quando houver banco local, SQLCipher com chaves derivadas por KDF forte. Segredos não podem ficar em frontend, logs, repositório Git, arquivos .env versionados ou banco comum. Deve haver rotação, expiração, auditoria de acesso e revogação imediata.

## Q59
<!-- pfq-id: b0d2a32b-f0d6-44fd-a03d-03bbe8ef2fae -->

**Pergunta**: Como é tratada a remoção segura de dados em descarte (wipe, criptografia com destruição de chave)?

**Resposta**:

A esteira CI/CD deverá incluir SAST, SCA, DAST e secret scanning. Ferramentas recomendadas: Semgrep ou CodeQL para SAST, Dependabot/Renovate e OWASP Dependency-Check ou Snyk para SCA, Gitleaks para detecção de segredos, Trivy para imagens e IaC, OWASP ZAP para DAST, npm audit/pip-audit conforme stack e assinatura de artefatos com cosign ou mecanismo equivalente. As verificações devem rodar em pull requests, builds de release e varreduras agendadas.
