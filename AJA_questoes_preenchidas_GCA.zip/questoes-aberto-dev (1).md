---
gca-followup-marker: v1
project_id: 24bf72c3-2ee8-45fd-b879-d3a00b347c39
persona_id: DEV
persona_name: Developer Senior
generated_at: 2026-05-05T01:39:08.017076+00:00
question_count: 71
---

# Perguntas em aberto — Developer Senior — Assistente Judicial para Advogados

Preencha as respostas abaixo de cada pergunta (substitua `<sua resposta aqui>`). Faça upload deste arquivo pela aba **Ingestão de Documentos**. NÃO altere as linhas com `<!-- pfq-id: ... -->`.

## Q1
<!-- pfq-id: ac64e14f-dede-4a91-830b-e964dbe3c8cb -->

**Pergunta**: Qual o prazo estimado para cada fase do roadmap? Existe equipe dedicada para desenvolvimento e manutenção?

**Resposta**:

Cronograma técnico sugerido: Sprint 0/ADR e setup CI/CD: 2 semanas; laboratório de mocks e contratos sintéticos: 2 a 3 semanas; MVP 1: 8 a 12 semanas; MVP+1/PDPJ-DJE: 6 a 10 semanas; PJe/MNI piloto: 4 a 8 semanas após credenciamento do tribunal; Fase 3: evolução contínua com dashboards, embeddings, IA local e conectores adicionais.

## Q2
<!-- pfq-id: c2000120-d1fa-4a02-9466-a558749177d3 -->

**Pergunta**: Qual é o cronograma esperado para entrega do laboratório de mocks conforme este caderno?

**Resposta**:

Cronograma técnico sugerido: Sprint 0/ADR e setup CI/CD: 2 semanas; laboratório de mocks e contratos sintéticos: 2 a 3 semanas; MVP 1: 8 a 12 semanas; MVP+1/PDPJ-DJE: 6 a 10 semanas; PJe/MNI piloto: 4 a 8 semanas após credenciamento do tribunal; Fase 3: evolução contínua com dashboards, embeddings, IA local e conectores adicionais.

## Q3
<!-- pfq-id: 8c73c1a1-e1ff-4edd-913e-eed465cf76f4 -->

**Pergunta**: Qual método de autenticação a API utiliza?

**Resposta**:

A API usará OIDC/OAuth2 com JWT de curta duração, refresh token controlado, MFA obrigatório para perfis sensíveis e RBAC/ABAC por tenant, papel, caso, processo, documento e operação. Integrações externas usarão API Key, OAuth2/client credentials, certificado A1/A3 ou autenticação específica por contrato de integração, sempre armazenando segredos em cofre e nunca no frontend.

## Q4
<!-- pfq-id: 26894bb6-864a-4f2a-8810-35a72d0d982e -->

**Pergunta**: Qual o prazo estimado e a composição da equipe para entrega do MVP?

**Resposta**:

Cronograma técnico sugerido: Sprint 0/ADR e setup CI/CD: 2 semanas; laboratório de mocks e contratos sintéticos: 2 a 3 semanas; MVP 1: 8 a 12 semanas; MVP+1/PDPJ-DJE: 6 a 10 semanas; PJe/MNI piloto: 4 a 8 semanas após credenciamento do tribunal; Fase 3: evolução contínua com dashboards, embeddings, IA local e conectores adicionais.

## Q5
<!-- pfq-id: 92c53895-cbe2-4fbf-8b06-845f471fefea -->

**Pergunta**: Qual stack tecnológica será adotada (ex: Python + PyQt, Electron, C# .NET)?

**Resposta**:

Decisão técnica proposta para o MVP: aplicação web responsiva como canal principal, com frontend React/TypeScript e backend Python FastAPI. Não adotar Electron como base obrigatória do MVP. Se houver necessidade de app local/offline, usar Tauri + React como shell leve, com SQLite + SQLCipher para cache local. A decisão final deve ser formalizada na ADR-001 até o fim da Sprint 0.

## Q6
<!-- pfq-id: 30fa6845-0425-432b-b7a8-c033c0d2326e -->

**Pergunta**: Qual a stack tecnológica (linguagem, framework, runtime) para o aplicativo local?

**Resposta**:

Decisão técnica proposta para o MVP: aplicação web responsiva como canal principal, com frontend React/TypeScript e backend Python FastAPI. Não adotar Electron como base obrigatória do MVP. Se houver necessidade de app local/offline, usar Tauri + React como shell leve, com SQLite + SQLCipher para cache local. A decisão final deve ser formalizada na ADR-001 até o fim da Sprint 0.

## Q7
<!-- pfq-id: ddcd2c3a-8edc-4eee-9a84-dd6f6adbd2cf -->

**Pergunta**: Qual o time efetivamente alocado (nomes, papéis, dedicação) para o início da Sprint 0?

**Resposta**:

A equipe nominal ainda deve ser definida antes da Sprint 0. Perfil mínimo: tech lead/arquiteto, backend, frontend, QA, DevOps/SecOps parcial, PO/BA, advogado sênior e DPO/responsável de privacidade. Cada sprint deverá ter RACI por módulo e responsável por aceite técnico/jurídico.

## Q8
<!-- pfq-id: 66ca17af-3952-46c2-abcf-3e8a2d8c93c3 -->

**Pergunta**: Qual o cronograma planejado para entrega dos itens DJ-01 a DJ-10?

**Resposta**:

Cronograma técnico sugerido: Sprint 0/ADR e setup CI/CD: 2 semanas; laboratório de mocks e contratos sintéticos: 2 a 3 semanas; MVP 1: 8 a 12 semanas; MVP+1/PDPJ-DJE: 6 a 10 semanas; PJe/MNI piloto: 4 a 8 semanas após credenciamento do tribunal; Fase 3: evolução contínua com dashboards, embeddings, IA local e conectores adicionais.

## Q9
<!-- pfq-id: 6e4ba559-76c1-4827-b637-04b92b335019 -->

**Pergunta**: Qual a decisão oficial de stack (Tauri/Electron, Spring Boot/Quarkus) e prazo para ADR-001?

**Resposta**:

Cronograma técnico sugerido: Sprint 0/ADR e setup CI/CD: 2 semanas; laboratório de mocks e contratos sintéticos: 2 a 3 semanas; MVP 1: 8 a 12 semanas; MVP+1/PDPJ-DJE: 6 a 10 semanas; PJe/MNI piloto: 4 a 8 semanas após credenciamento do tribunal; Fase 3: evolução contínua com dashboards, embeddings, IA local e conectores adicionais.

## Q10
<!-- pfq-id: a2226fa8-4bf5-4f33-aecc-020ac0d41558 -->

**Pergunta**: Qual plataforma cloud (AWS, Azure, GCP) ou infraestrutura própria será usada para deploy?

**Resposta**:

Deploy inicial recomendado: Docker Compose ou Kubernetes gerenciado em ambiente cloud ou infraestrutura própria, conforme restrição do escritório. Para MVP, aceitar ambiente conteinerizado simples com PostgreSQL, Redis, storage S3/MinIO, backend, frontend e workers. Para escala multi-tenant, evoluir para Kubernetes, balanceador, autoscaling, secrets manager e observabilidade centralizada.

## Q11
<!-- pfq-id: f7edd30b-cf39-4e2c-bdc9-6beb26e6059a -->

**Pergunta**: Quem serão os membros da equipe com papéis e dedicação confirmados para a Sprint 0?

**Resposta**:

A composição recomendada para o MVP é: 1 Product Owner/Analista de Negócio, 1 Gerente de Projetos/Scrum Master, 1 Arquiteto de Solução, 2 desenvolvedores backend, 1 desenvolvedor frontend, 1 especialista em integrações/API, 1 QA/Testing Lead, 1 DevOps/SRE parcial, 1 advogado sênior validador, 1 responsável LGPD/DPO e apoio de segurança. Nomes e dedicação real ainda devem ser definidos formalmente antes da Sprint 0 e registrados na matriz RACI.

## Q12
<!-- pfq-id: 07c9733c-2b95-416f-aea1-4b1d13999884 -->

**Pergunta**: Quais ferramentas de CI/CD serão adotadas? Haverá build pipeline automática, testes automatizados e deploy contínuo?

**Resposta**:

Deploy inicial recomendado: Docker Compose ou Kubernetes gerenciado em ambiente cloud ou infraestrutura própria, conforme restrição do escritório. Para MVP, aceitar ambiente conteinerizado simples com PostgreSQL, Redis, storage S3/MinIO, backend, frontend e workers. Para escala multi-tenant, evoluir para Kubernetes, balanceador, autoscaling, secrets manager e observabilidade centralizada.

## Q13
<!-- pfq-id: ab091a06-41f6-4417-b49a-b0fbfd16efd0 -->

**Pergunta**: Quais recursos humanos e de infraestrutura estão disponíveis para implementar os itens do backlog técnico?

**Resposta**:

A equipe nominal ainda deve ser definida antes da Sprint 0. Perfil mínimo: tech lead/arquiteto, backend, frontend, QA, DevOps/SecOps parcial, PO/BA, advogado sênior e DPO/responsável de privacidade. Cada sprint deverá ter RACI por módulo e responsável por aceite técnico/jurídico.

## Q14
<!-- pfq-id: a01ad810-48c4-491c-ae9d-e946c9da97e8 -->

**Pergunta**: Existem rate limits? Quais os limites?

**Resposta**:

Sim. O AJA terá rate limits internos por tenant, usuário, integração e endpoint. DataJud, CNA/OAB, BCB/SGS, PDPJ/DJE e LLM terão limites configuráveis no Admin, com fila, cache, backoff exponencial e circuit breaker. Para DataJud, usar limite interno conservador e nunca exceder limites oficiais vigentes; quando não houver SLA publicado, prevalece política de consumo responsável.

## Q15
<!-- pfq-id: 414cd61e-66c2-4798-a284-2b01b6f00933 -->

**Pergunta**: Qual a estratégia e cobertura de testes automatizados prevista?

**Resposta**:

Ferramentas sugeridas: pytest para backend, Jest/Vitest para frontend, Playwright para e2e, Pact ou Schemathesis para testes de contrato, Ruff/Black/mypy para qualidade Python, ESLint/TypeScript strict no frontend, Semgrep/Bandit para SAST, OWASP ZAP para DAST, Trivy/Dependabot para dependências/containers. Cobertura mínima alvo: 80% nos módulos críticos e 100% de cenários para RBAC, anonimização, prazos, cálculos, templates oficiais e fallback de integrações.

## Q16
<!-- pfq-id: 9085a501-4cd2-4f47-84b5-4a6266c9128a -->

**Pergunta**: Há definição de plataformas alvo (Windows, macOS, Linux) e de distribuição (instalador, portable)?

**Resposta**:

No MVP, priorizar aplicação web responsiva compatível com navegadores modernos em Windows, Linux e macOS. Se houver componente local, empacotar com Tauri em instaladores assinados para Windows primeiro; macOS/Linux ficam como fase posterior. Auto-update deverá usar canal stable/beta, assinatura de código, rollback e validação de integridade. Certificado OV/EV ainda deve ser definido e orçado.

## Q17
<!-- pfq-id: ed811d1d-9e22-4490-90d0-a12b1fbe6230 -->

**Pergunta**: Como será o gerenciamento de dependências, criptografia e cofre de segredos local?

**Resposta**:

Dependências serão versionadas por lockfile e revisadas por scanner de vulnerabilidades. Segredos serão armazenados em cofre central (HashiCorp Vault, cloud secret manager ou equivalente) e, para cache/local offline, em cofre local protegido pelo sistema operacional ou SQLCipher. Rotação de segredos por política: imediata em incidente, periódica para chaves críticas e controlada por versão para contratos de integração. Backup de segredos deve ser criptografado e restrito a administradores autorizados.

## Q18
<!-- pfq-id: de0d79af-62f2-4e7c-bd2c-faa0f86fa5aa -->

**Pergunta**: Quais credenciais e autorizações para conectores estarão disponíveis antes das Sprints 4 e 5?

**Resposta**:

Antes das Sprints 4/5 devem estar disponíveis: APIKey pública vigente do DataJud, configuração CNA/OAB, acesso BCB/SGS, chaves LLM de homologação e credenciais de ambiente próprio. DJE/PDPJ exige cadastro do CNPJ e geração de credenciais no ecossistema PDPJ. PJe/MNI depende de tribunal piloto e eventual solicitação formal/ofício/SEI. DataJud público não possui sandbox típico; testes devem usar mocks e consultas controladas.

## Q19
<!-- pfq-id: 2c18721b-ad34-4e58-b91b-9026c4888a26 -->

**Pergunta**: Qual plataforma de deploy será utilizada (ex: Kubernetes on‑premises, VMs), e como isso influencia a estratégia de CI/CD?

**Resposta**:

Deploy inicial recomendado: Docker Compose ou Kubernetes gerenciado em ambiente cloud ou infraestrutura própria, conforme restrição do escritório. Para MVP, aceitar ambiente conteinerizado simples com PostgreSQL, Redis, storage S3/MinIO, backend, frontend e workers. Para escala multi-tenant, evoluir para Kubernetes, balanceador, autoscaling, secrets manager e observabilidade centralizada.

## Q20
<!-- pfq-id: 900d983a-1b4d-4b0c-9f6b-02c45537cf84 -->

**Pergunta**: Quais tribunais/órgãos terão credenciais reais e sandboxes de homologação?

**Resposta**:

Acesso a homologação/sandbox dependerá do órgão. DataJud público não possui sandbox típico; serão usados mocks e consultas controladas. DJE/PDPJ exige cadastro do CNPJ e geração de credenciais no ecossistema PDPJ. PJe/MNI depende de tribunal piloto e eventual solicitação formal/ofício/SEI. Sem credencial real, o conector pode ser desenvolvido com contrato sintético, mas não deve ser aceito para produção.

## Q21
<!-- pfq-id: 9a9de631-e3f9-403e-a64c-25bab0045a0b -->

**Pergunta**: Quais ferramentas de CI/CD (ex.: GitHub Actions, GitLab CI, Jenkins) e práticas de deploy (blue-green, canary) serão adotadas?

**Resposta**:

Deploy inicial recomendado: Docker Compose ou Kubernetes gerenciado em ambiente cloud ou infraestrutura própria, conforme restrição do escritório. Para MVP, aceitar ambiente conteinerizado simples com PostgreSQL, Redis, storage S3/MinIO, backend, frontend e workers. Para escala multi-tenant, evoluir para Kubernetes, balanceador, autoscaling, secrets manager e observabilidade centralizada.

## Q22
<!-- pfq-id: 76826e53-2c9c-4c60-976f-1923b2801783 -->

**Pergunta**: Qual a estimativa realista de prazo para aprovação do orçamento e aquisição de licenças/certificados?

**Resposta**:

O cronograma recomendado é: Fase 0 — Fundação, governança, arquitetura, RBAC, cofre, Admin e contratos técnicos: 2 a 4 semanas; MVP 1 — núcleo operacional com casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora: 8 a 12 semanas; MVP 2 — PDPJ/DJE, comunicações, eventos, workflows de ciência e fallback: 6 a 10 semanas; MVP técnico PJe/MNI — homologação por tribunal piloto, certificado e protocolo: 4 a 8 semanas por tribunal. Datas absolutas devem ser confirmadas no início da Sprint 0 conforme equipe, orçamento e disponibilidade de credenciais.

## Q23
<!-- pfq-id: 79db74da-d06a-459a-9553-155548a3c8ee -->

**Pergunta**: Como será a gestão de versões dos conectores externos? Há equipe para monitoramento proativo de mudanças de API?

**Resposta**:

Conectores, mocks, contratos de API e templates serão versionados semanticamente. Cada conector terá adapter, contrato OpenAPI/JSON Schema, fixtures, testes de contrato, changelog, data da última validação e dono técnico. Mudanças incompatíveis exigem nova versão, migração, janela de depreciação, rollback e aprovação técnica/jurídica quando afetar documento, prazo, cálculo ou integração judicial.

## Q24
<!-- pfq-id: 8244e73a-a4e2-488c-a0b0-fb7f3fcb78c2 -->

**Pergunta**: Haverá acesso a ambientes de homologação/sandbox dos órgãos oficiais para validação dos contratos sintéticos?

**Resposta**:

Acesso a homologação/sandbox dependerá do órgão. DataJud público não possui sandbox típico; serão usados mocks e consultas controladas. DJE/PDPJ exige cadastro do CNPJ e geração de credenciais no ecossistema PDPJ. PJe/MNI depende de tribunal piloto e eventual solicitação formal/ofício/SEI. Sem credencial real, o conector pode ser desenvolvido com contrato sintético, mas não deve ser aceito para produção.

## Q25
<!-- pfq-id: adefb0e1-cc91-4b23-9955-b5e3ef4f0126 -->

**Pergunta**: Qual o formato exato da resposta JSON e como tratar erros?

**Resposta**:

O padrão de resposta JSON interno será: `{ "success": true|false, "data": {}, "error": { "code": "", "message": "", "details": {} }, "meta": { "requestId": "", "tenantId": "", "source": "", "cached": true|false, "timestamp": "", "version": "" } }`. Erros serão normalizados por categoria: validação, autenticação, autorização, integração externa, timeout, rate limit, indisponibilidade, conflito de versão e erro interno. Nunca expor segredo, token, CPF completo ou stack trace ao usuário final.

## Q26
<!-- pfq-id: a0f3aca4-4e5a-45f4-bd01-b75f07ba7817 -->

**Pergunta**: Como será a integração contínua e empacotamento para diferentes sistemas operacionais?

**Resposta**:

Resposta técnica consolidada: o item será tratado por ADR, contrato de API, teste automatizado e critério de aceite no backlog. Decisões ainda não formalizadas devem ser fechadas na Sprint 0 antes de desenvolvimento produtivo ou antes da integração com dados reais.

## Q27
<!-- pfq-id: 839339dc-efaa-45a5-8c48-1af5c5c4072c -->

**Pergunta**: A aplicação é exclusivamente desktop ou haverá uma camada web/servidor para sincronização futura?

**Resposta**:

Resposta técnica consolidada: o item será tratado por ADR, contrato de API, teste automatizado e critério de aceite no backlog. Decisões ainda não formalizadas devem ser fechadas na Sprint 0 antes de desenvolvimento produtivo ou antes da integração com dados reais.

## Q28
<!-- pfq-id: adcdc02c-dd52-465c-ba9e-3b0aa73f80d4 -->

**Pergunta**: Quais provedores de IA serão suportados inicialmente e como gerenciar a rotação de chaves/versões?

**Resposta**:

Provedores iniciais: OpenAI e provedor compatível configurável via LLM Gateway; modelos locais ficam como fase posterior. Chaves por tenant/ambiente no cofre, com rotação, limite de consumo, budget, logs e política de retenção. IA local offline não será obrigatória no MVP; se adotada, deverá informar requisitos mínimos de hardware e limitar uso a tarefas de baixa criticidade ou documentos anonimizados.

## Q29
<!-- pfq-id: 8ae74152-4552-4d19-9f4c-eb38f432efaf -->

**Pergunta**: Qual framework desktop será utilizado (Electron, Tauri, etc.) e qual formato de empacotamento assinado?

**Resposta**:

Decisão técnica proposta para o MVP: aplicação web responsiva como canal principal, com frontend React/TypeScript e backend Python FastAPI. Não adotar Electron como base obrigatória do MVP. Se houver necessidade de app local/offline, usar Tauri + React como shell leve, com SQLite + SQLCipher para cache local. A decisão final deve ser formalizada na ADR-001 até o fim da Sprint 0.

## Q30
<!-- pfq-id: 946a2f0d-b477-4eaf-a4e9-121cb08d82b8 -->

**Pergunta**: Qual SLA de uptime e latência se espera do conector, considerando que a API DataJud não oferece garantias?

**Resposta**:

Requisitos de latência: telas internas comuns em até 2 segundos quando não dependerem de serviços externos; retorno de protocolo para tarefa assíncrona em até 5 segundos; consulta externa com timeout configurável; geração de minuta por IA em fila com status e notificação. O frontend deve exibir progresso e nunca travar aguardando conector lento.

## Q31
<!-- pfq-id: bb0252e1-5e5b-4b82-9eaa-b3968e465000 -->

**Pergunta**: Quem são os membros da equipe, qual sua disponibilidade e responsabilidades por sprint?

**Resposta**:

SLA interno alvo: disponibilidade da API AJA de 99,5% no MVP; telas comuns até 2 segundos sem dependência externa; chamadas assíncronas com retorno de protocolo em até 5 segundos; consultas DataJud/externas com timeout configurável e execução em fila; geração de peça por IA como tarefa assíncrona com notificação. Não assumir SLA de DataJud/tribunais/provedores externos além do que estiver publicado/contratado.

## Q32
<!-- pfq-id: 8af849df-e256-4476-a30e-0cef4de0b13b -->

**Pergunta**: Quais frameworks de teste unitário, de integração e de contrato serão empregados (ex.: Jest, pytest, Pact)?

**Resposta**:

Ferramentas sugeridas: pytest para backend, Jest/Vitest para frontend, Playwright para e2e, Pact ou Schemathesis para testes de contrato, Ruff/Black/mypy para qualidade Python, ESLint/TypeScript strict no frontend, Semgrep/Bandit para SAST, OWASP ZAP para DAST, Trivy/Dependabot para dependências/containers. Cobertura mínima alvo: 80% nos módulos críticos e 100% de cenários para RBAC, anonimização, prazos, cálculos, templates oficiais e fallback de integrações.

## Q33
<!-- pfq-id: c19fca3c-ff01-4cc1-9379-f8f7c6e6a277 -->

**Pergunta**: Qual tribunal será o piloto para PJe/MNI e qual o cronograma esperado para credenciamento?

**Resposta**:

O cronograma recomendado é: Fase 0 — Fundação, governança, arquitetura, RBAC, cofre, Admin e contratos técnicos: 2 a 4 semanas; MVP 1 — núcleo operacional com casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora: 8 a 12 semanas; MVP 2 — PDPJ/DJE, comunicações, eventos, workflows de ciência e fallback: 6 a 10 semanas; MVP técnico PJe/MNI — homologação por tribunal piloto, certificado e protocolo: 4 a 8 semanas por tribunal. Datas absolutas devem ser confirmadas no início da Sprint 0 conforme equipe, orçamento e disponibilidade de credenciais.

## Q34
<!-- pfq-id: b0e507b5-efe9-42e1-a0fd-8d23290649ec -->

**Pergunta**: Qual a estratégia de teste de regressão para módulos interligados (ex.: alteração em cálculo afeta peças)?

**Resposta**:

Ferramentas sugeridas: pytest para backend, Jest/Vitest para frontend, Playwright para e2e, Pact ou Schemathesis para testes de contrato, Ruff/Black/mypy para qualidade Python, ESLint/TypeScript strict no frontend, Semgrep/Bandit para SAST, OWASP ZAP para DAST, Trivy/Dependabot para dependências/containers. Cobertura mínima alvo: 80% nos módulos críticos e 100% de cenários para RBAC, anonimização, prazos, cálculos, templates oficiais e fallback de integrações.

## Q35
<!-- pfq-id: ec01176c-1567-4ce4-ac89-3783366303d3 -->

**Pergunta**: Como serão mantidos os mocks atualizados frente a mudanças nas APIs reais (processo, periodicidade, responsável)?

**Resposta**:

Conectores, mocks, contratos de API e templates serão versionados semanticamente. Cada conector terá adapter, contrato OpenAPI/JSON Schema, fixtures, testes de contrato, changelog, data da última validação e dono técnico. Mudanças incompatíveis exigem nova versão, migração, janela de depreciação, rollback e aprovação técnica/jurídica quando afetar documento, prazo, cálculo ou integração judicial.

## Q36
<!-- pfq-id: 09a19879-4014-4d83-8523-eebc79624935 -->

**Pergunta**: Há documentação de versionamento da API e plano de depreciação?

**Resposta**:

Contratos de API e templates serão versionados semanticamente, com changelog, data de vigência, dono técnico/jurídico, testes de contrato e rollback. Mudança incompatível cria nova versão e janela de depreciação. Templates aprovados não são editados diretamente; alterações geram nova versão. Conectores externos terão fixtures e mocks vinculados à versão do contrato.

## Q37
<!-- pfq-id: 1ca12cc5-f072-4a83-b5d5-be8ca1d9a24b -->

**Pergunta**: Há plano de atualização automática do aplicativo (auto-update) e assinatura de código?

**Resposta**:

No MVP, priorizar aplicação web responsiva compatível com navegadores modernos em Windows, Linux e macOS. Se houver componente local, empacotar com Tauri em instaladores assinados para Windows primeiro; macOS/Linux ficam como fase posterior. Auto-update deverá usar canal stable/beta, assinatura de código, rollback e validação de integridade. Certificado OV/EV ainda deve ser definido e orçado.

## Q38
<!-- pfq-id: d59fceff-5441-45ca-ae28-a00fcb780196 -->

**Pergunta**: Como será gerenciada a atualização de versões e correções nos escritórios (offline/online)?

**Resposta**:

Provedores iniciais: OpenAI e provedor compatível configurável via LLM Gateway; modelos locais ficam como fase posterior. Chaves por tenant/ambiente no cofre, com rotação, limite de consumo, budget, logs e política de retenção. IA local offline não será obrigatória no MVP; se adotada, deverá informar requisitos mínimos de hardware e limitar uso a tarefas de baixa criticidade ou documentos anonimizados.

## Q39
<!-- pfq-id: 5be025d8-a491-46f9-9af9-a3ccda4c2c81 -->

**Pergunta**: Qual o cronograma estimado para MVP, MVP+1 e Fase 3?

**Resposta**:

Cronograma técnico sugerido: Sprint 0/ADR e setup CI/CD: 2 semanas; laboratório de mocks e contratos sintéticos: 2 a 3 semanas; MVP 1: 8 a 12 semanas; MVP+1/PDPJ-DJE: 6 a 10 semanas; PJe/MNI piloto: 4 a 8 semanas após credenciamento do tribunal; Fase 3: evolução contínua com dashboards, embeddings, IA local e conectores adicionais.

## Q40
<!-- pfq-id: 15f17bf3-0c07-44ab-9afb-8b1c243bdb0d -->

**Pergunta**: Quais ferramentas concretas de CI/CD (GitHub Actions ou GitLab CI) e build desktop serão adotadas?

**Resposta**:

Padronizar GitHub Actions como CI/CD inicial, com etapas de lint, testes unitários, testes de integração, testes de contrato, SAST, dependency scan, build Docker, geração de OpenAPI e deploy controlado em homologação. Produção deve exigir aprovação manual, changelog, tag semântica e plano de rollback. Blue-green/canary ficam para v1.0 quando houver tráfego multi-tenant real.

## Q41
<!-- pfq-id: b18cd68b-2850-4079-8a77-0c94d232aa89 -->

**Pergunta**: Quais ferramentas de CI/CD e orquestração de segredos serão padronizadas (ex: GitHub Actions, HashiCorp Vault)?

**Resposta**:

Padronizar GitHub Actions como CI/CD inicial, com etapas de lint, testes unitários, testes de integração, testes de contrato, SAST, dependency scan, build Docker, geração de OpenAPI e deploy controlado em homologação. Produção deve exigir aprovação manual, changelog, tag semântica e plano de rollback. Blue-green/canary ficam para v1.0 quando houver tráfego multi-tenant real.

## Q42
<!-- pfq-id: d032ba86-23d8-4910-a9de-4c10d9a02b75 -->

**Pergunta**: Qual o cronograma detalhado com marcos e datas de entrega?

**Resposta**:

Cronograma técnico sugerido: Sprint 0/ADR e setup CI/CD: 2 semanas; laboratório de mocks e contratos sintéticos: 2 a 3 semanas; MVP 1: 8 a 12 semanas; MVP+1/PDPJ-DJE: 6 a 10 semanas; PJe/MNI piloto: 4 a 8 semanas após credenciamento do tribunal; Fase 3: evolução contínua com dashboards, embeddings, IA local e conectores adicionais.

## Q43
<!-- pfq-id: c06d1fe1-5433-489d-8a1a-a72e710be337 -->

**Pergunta**: Como será gerenciado o processo de homologação por tribunal para PJe/MNI? Há equipe dedicada para tratar ofícios e SEI?

**Resposta**:

Acesso a homologação/sandbox dependerá do órgão. DataJud público não possui sandbox típico; serão usados mocks e consultas controladas. DJE/PDPJ exige cadastro do CNPJ e geração de credenciais no ecossistema PDPJ. PJe/MNI depende de tribunal piloto e eventual solicitação formal/ofício/SEI. Sem credencial real, o conector pode ser desenvolvido com contrato sintético, mas não deve ser aceito para produção.

## Q44
<!-- pfq-id: e9785be1-6f94-4daf-a737-1038eb605d33 -->

**Pergunta**: Já foi designado o DPO/responsável de privacidade e agendada a validação formal do RIPD e dos contratos de tratamento de dados?

**Resposta**:

Este item deve ser detalhado em ADR ou tarefa técnica do backlog do AJA, com decisão formal na Sprint 0, responsável técnico, critério de aceite, testes automatizados, observabilidade e registro no GCA.

## Q45
<!-- pfq-id: d2c65ee9-8123-44d4-8165-d5e770e9ea79 -->

**Pergunta**: Há orçamento para contratar bases privadas ou convênios com órgãos públicos? Como serão gerenciados os custos recorrentes?

**Resposta**:

Antes das Sprints 4/5 devem estar disponíveis: APIKey pública vigente do DataJud, configuração CNA/OAB, acesso BCB/SGS, chaves LLM de homologação e credenciais de ambiente próprio. DJE/PDPJ exige cadastro do CNPJ e geração de credenciais no ecossistema PDPJ. PJe/MNI depende de tribunal piloto e eventual solicitação formal/ofício/SEI. DataJud público não possui sandbox típico; testes devem usar mocks e consultas controladas.

## Q46
<!-- pfq-id: 0bf403ec-552d-4194-837e-95da7ae34b11 -->

**Pergunta**: Qual o SLA de implantação e rollback dos componentes de mock no ambiente local/CI?

**Resposta**:

SLA interno alvo: disponibilidade da API AJA de 99,5% no MVP; telas comuns até 2 segundos sem dependência externa; chamadas assíncronas com retorno de protocolo em até 5 segundos; consultas DataJud/externas com timeout configurável e execução em fila; geração de peça por IA como tarefa assíncrona com notificação. Não assumir SLA de DataJud/tribunais/provedores externos além do que estiver publicado/contratado.

## Q47
<!-- pfq-id: e189a630-7ef5-42d6-8169-6d800cb60e75 -->

**Pergunta**: Qual o SLA de disponibilidade da API?

**Resposta**:

SLA interno alvo: disponibilidade da API AJA de 99,5% no MVP; telas comuns até 2 segundos sem dependência externa; chamadas assíncronas com retorno de protocolo em até 5 segundos; consultas DataJud/externas com timeout configurável e execução em fila; geração de peça por IA como tarefa assíncrona com notificação. Não assumir SLA de DataJud/tribunais/provedores externos além do que estiver publicado/contratado.

## Q48
<!-- pfq-id: 17525ada-cef8-4d94-96d9-0bacfe312fe4 -->

**Pergunta**: Quais fontes oficiais serão utilizadas para download de índices? Há API confiável ou será necessário scraping?

**Resposta**:

As fontes oficiais para índices serão preferencialmente BCB/SGS para séries temporais financeiras e, quando necessário, fontes oficiais do IBGE/FGV/tribunais conforme o índice jurídico utilizado. Scraping não será estratégia principal. Quando uma fonte mudar de formato ou ficar indisponível, o sistema usará cache válido, fallback manual, registro de fonte e bloqueio de cálculo automático sem validação.

## Q49
<!-- pfq-id: 5dbc77ac-21c0-438d-8e21-8e382dcd580c -->

**Pergunta**: Quais ferramentas de teste (unitário, integração, e2e) serão utilizadas? Há cobertura esperada?

**Resposta**:

Ferramentas sugeridas: pytest para backend, Jest/Vitest para frontend, Playwright para e2e, Pact ou Schemathesis para testes de contrato, Ruff/Black/mypy para qualidade Python, ESLint/TypeScript strict no frontend, Semgrep/Bandit para SAST, OWASP ZAP para DAST, Trivy/Dependabot para dependências/containers. Cobertura mínima alvo: 80% nos módulos críticos e 100% de cenários para RBAC, anonimização, prazos, cálculos, templates oficiais e fallback de integrações.

## Q50
<!-- pfq-id: a0043f27-d39e-47da-91ad-ee07d509f5d8 -->

**Pergunta**: Há plano de CI/CD, testes automatizados de regressão e segurança?

**Resposta**:

Padronizar GitHub Actions como CI/CD inicial, com etapas de lint, testes unitários, testes de integração, testes de contrato, SAST, dependency scan, build Docker, geração de OpenAPI e deploy controlado em homologação. Produção deve exigir aprovação manual, changelog, tag semântica e plano de rollback. Blue-green/canary ficam para v1.0 quando houver tráfego multi-tenant real.

## Q51
<!-- pfq-id: 391155de-a120-44ff-80d7-2a897ab2aceb -->

**Pergunta**: Qual modelo de IA local será embarcado e quais requisitos mínimos de hardware para inferência offline?

**Resposta**:

Provedores iniciais: OpenAI e provedor compatível configurável via LLM Gateway; modelos locais ficam como fase posterior. Chaves por tenant/ambiente no cofre, com rotação, limite de consumo, budget, logs e política de retenção. IA local offline não será obrigatória no MVP; se adotada, deverá informar requisitos mínimos de hardware e limitar uso a tarefas de baixa criticidade ou documentos anonimizados.

## Q52
<!-- pfq-id: 6c7bd722-0a8a-4b0c-b9c0-adfca18ba12e -->

**Pergunta**: Existe plano de contingência caso a API DataJud fique indisponível ou a chave pública seja alterada sem aviso prévio?

**Resposta**:

Plano de contingência: cache com TTL e data da última atualização, backoff exponencial, circuit breaker, alerta ao usuário, fallback manual e troca controlada de chave/configuração pelo Admin. Se DataJud ou outro provedor ficar indisponível, o sistema não deve inventar dados; deve registrar a falha, permitir evidência manual e bloquear uso automático de dados vencidos em prazos, peças ou decisões críticas.

## Q53
<!-- pfq-id: 1505f9e3-8dde-4b02-9c0a-97392189cd6d -->

**Pergunta**: Qual certificado de assinatura de código será adquirido (OV/EV) e para quais plataformas?

**Resposta**:

No MVP, priorizar aplicação web responsiva compatível com navegadores modernos em Windows, Linux e macOS. Se houver componente local, empacotar com Tauri em instaladores assinados para Windows primeiro; macOS/Linux ficam como fase posterior. Auto-update deverá usar canal stable/beta, assinatura de código, rollback e validação de integridade. Certificado OV/EV ainda deve ser definido e orçado.

## Q54
<!-- pfq-id: c4e85838-de66-4bff-987b-9a27b40a27ca -->

**Pergunta**: Qual a estratégia de versionamento e rollback para contratos de API e templates que sofrem alterações frequentes?

**Resposta**:

Contratos de API e templates serão versionados semanticamente, com changelog, data de vigência, dono técnico/jurídico, testes de contrato e rollback. Mudança incompatível cria nova versão e janela de depreciação. Templates aprovados não são editados diretamente; alterações geram nova versão. Conectores externos terão fixtures e mocks vinculados à versão do contrato.

## Q55
<!-- pfq-id: 422c29c4-024f-4905-b143-fda73a10ee7e -->

**Pergunta**: Quando será executado o pentest independente e qual será a empresa contratada?

**Resposta**:

O pentest independente deverá ser executado antes do piloto produtivo ou antes da primeira produção com dados reais. A empresa ainda deve ser contratada. Escopo mínimo: autenticação, RBAC, multi-tenancy, uploads, exportação, LLM Gateway, conectores externos, cofre de segredos, portal LGPD, APIs e configuração de infraestrutura.

## Q56
<!-- pfq-id: eb3e2977-33d2-4a17-bd59-bbc78e06f8e1 -->

**Pergunta**: Quem será responsável pela conformidade contínua com LGPD e sigilo profissional? Existe DPO ou consultoria jurídica dedicada?

**Resposta**:

A conformidade contínua será responsabilidade compartilhada: DPO/responsável de privacidade para LGPD, advogado sênior/sócio para sigilo profissional e qualidade jurídica, tech lead/SecOps para controles técnicos e gerente do projeto para evidências. A designação nominal ainda deve ser feita antes do piloto produtivo.

## Q57
<!-- pfq-id: a97d7b06-e2ce-416f-aa2b-3b1bef6b0193 -->

**Pergunta**: Existe ambiente de homologação/sandbox para testes?

**Resposta**:

Acesso a homologação/sandbox dependerá do órgão. DataJud público não possui sandbox típico; serão usados mocks e consultas controladas. DJE/PDPJ exige cadastro do CNPJ e geração de credenciais no ecossistema PDPJ. PJe/MNI depende de tribunal piloto e eventual solicitação formal/ofício/SEI. Sem credencial real, o conector pode ser desenvolvido com contrato sintético, mas não deve ser aceito para produção.

## Q58
<!-- pfq-id: 0daeedb1-37ef-44d6-9ebd-b19019792382 -->

**Pergunta**: Existem requisitos de testes de segurança e auditoria de código (SAST, DAST)?

**Resposta**:

Ferramentas sugeridas: pytest para backend, Jest/Vitest para frontend, Playwright para e2e, Pact ou Schemathesis para testes de contrato, Ruff/Black/mypy para qualidade Python, ESLint/TypeScript strict no frontend, Semgrep/Bandit para SAST, OWASP ZAP para DAST, Trivy/Dependabot para dependências/containers. Cobertura mínima alvo: 80% nos módulos críticos e 100% de cenários para RBAC, anonimização, prazos, cálculos, templates oficiais e fallback de integrações.

## Q59
<!-- pfq-id: b9bdf7d6-1baa-49e6-ae54-e61bcfe620af -->

**Pergunta**: O cofre local usa qual tecnologia (ex: SQLCipher, KeePassXC)? Como é feita a rotação de segredos e backup seguro?

**Resposta**:

Dependências serão versionadas por lockfile e revisadas por scanner de vulnerabilidades. Segredos serão armazenados em cofre central (HashiCorp Vault, cloud secret manager ou equivalente) e, para cache/local offline, em cofre local protegido pelo sistema operacional ou SQLCipher. Rotação de segredos por política: imediata em incidente, periódica para chaves críticas e controlada por versão para contratos de integração. Backup de segredos deve ser criptografado e restrito a administradores autorizados.

## Q60
<!-- pfq-id: d44f0f44-4b13-4692-b539-1b0435e11a8e -->

**Pergunta**: Como será feita a distribuição e atualização do software local (installer, auto-update)?

**Resposta**:

No MVP, priorizar aplicação web responsiva compatível com navegadores modernos em Windows, Linux e macOS. Se houver componente local, empacotar com Tauri em instaladores assinados para Windows primeiro; macOS/Linux ficam como fase posterior. Auto-update deverá usar canal stable/beta, assinatura de código, rollback e validação de integridade. Certificado OV/EV ainda deve ser definido e orçado.

## Q61
<!-- pfq-id: 941b271e-4bb2-4940-b8af-533ff9184e70 -->

**Pergunta**: Quando e por quem será executado o pentest independente, e qual será o escopo aceitável para o MVP?

**Resposta**:

O pentest independente deve ser executado após o code freeze do MVP e antes do piloto produtivo com dados reais. Escopo mínimo: autenticação, autorização/RBAC, isolamento multi-tenant, upload/download de documentos, LLM Gateway, cofre de segredos, APIs externas simuladas, logs e exposição de dados pessoais. Responsável e fornecedor ainda devem ser contratados/definidos.

## Q62
<!-- pfq-id: 1c9f47e9-45f6-4988-8f0c-9161f892db0b -->

**Pergunta**: Qual SLA será assumido para provedores de IA externos, se utilizados?

**Resposta**:

Nenhum SLA superior ao contratado/publicado será assumido para provedores externos de IA. O AJA terá SLA interno de orquestração: timeout, retry limitado, fallback para outro modelo/provedor quando configurado, fila, alerta de custo e registro de indisponibilidade. O usuário deve ver quando a falha é do provedor externo.

## Q63
<!-- pfq-id: b5a2c561-7c4c-41a4-9327-23a4f9a35503 -->

**Pergunta**: Existe plano para testes de carga e de isolamento multi-tenant com volumes realistas de dados processuais?

**Resposta**:

Ferramentas sugeridas: pytest para backend, Jest/Vitest para frontend, Playwright para e2e, Pact ou Schemathesis para testes de contrato, Ruff/Black/mypy para qualidade Python, ESLint/TypeScript strict no frontend, Semgrep/Bandit para SAST, OWASP ZAP para DAST, Trivy/Dependabot para dependências/containers. Cobertura mínima alvo: 80% nos módulos críticos e 100% de cenários para RBAC, anonimização, prazos, cálculos, templates oficiais e fallback de integrações.

## Q64
<!-- pfq-id: 003c161f-099c-4669-ac71-0bc12f84f0d9 -->

**Pergunta**: Qual o canal/processo formal para obtenção de credenciais de homologação do DJE/PDPJ e PJe/MNI, e há previsão de suporte jurídico para ofícios?

**Resposta**:

Antes das Sprints 4 e 5, espera-se ter DataJud com uso público/APIKey, CNA/OAB e BCB/SGS com contratos/mocks validados. PDPJ/DJE e PJe/MNI dependem de credenciamento formal, certificado e homologação por órgão/tribunal, portanto devem ter mocks e fallback manual até credenciais reais. O tribunal piloto para PJe/MNI ainda deve ser definido, preferencialmente alinhado ao escritório piloto e sua jurisdição principal.

## Q65
<!-- pfq-id: bbedffee-a430-4991-93e0-88d50d12377a -->

**Pergunta**: Que mecanismo de backup local e restauração será implementado (formato, criptografia)?

**Resposta**:

Backup local, quando houver componente offline, será criptografado, assinado ou verificado por hash, protegido por senha/chave em cofre e com rotina de restore testável. O backup não deve conter segredos em texto puro. Para ambiente central, usar backup PostgreSQL/storage criptografado com política 3-2-1 e teste periódico de restauração.

## Q66
<!-- pfq-id: d2519fcb-8cfa-43b0-8675-d7bf07db1c3c -->

**Pergunta**: Qual ferramenta de migração de banco local (Flyway, Liquibase, etc.) será usada e como será testado o rollback?

**Resposta**:

Backups serão criptografados, versionados e testados. Para backend Python/FastAPI com PostgreSQL, usar Alembic para migrações; se a organização preferir governança independente de linguagem, Liquibase é alternativa aceitável. Toda migração terá script de upgrade, estratégia de rollback, backup pré-migração, teste em homologação e validação de integridade pós-migração.

## Q67
<!-- pfq-id: c90d0f1a-4d3d-4b2a-8162-774a7045521f -->

**Pergunta**: Existe ambiente de CI/CD já operacional ou será construído do zero?

**Resposta**:

Padronizar GitHub Actions como CI/CD inicial, com etapas de lint, testes unitários, testes de integração, testes de contrato, SAST, dependency scan, build Docker, geração de OpenAPI e deploy controlado em homologação. Produção deve exigir aprovação manual, changelog, tag semântica e plano de rollback. Blue-green/canary ficam para v1.0 quando houver tráfego multi-tenant real.

## Q68
<!-- pfq-id: 36fb6c9d-9713-4ae8-953d-9dd69ae4ce7e -->

**Pergunta**: Como será feito o gerenciamento de filas assíncronas e o monitoramento de health das integrações (mecanismos de circuit breaker, alertas)?

**Resposta**:

Filas assíncronas serão usadas para consultas externas, geração de peças, cálculo pesado, sincronizações e webhooks. Implementar retry com backoff, dead-letter queue, circuit breaker por provedor, health check por integração, métricas de latência/erro/cache, alertas por indisponibilidade e painel Admin de status.

## Q69
<!-- pfq-id: 6210ca1c-e7ac-42dc-b12f-a2ecad2d9f1f -->

**Pergunta**: Como será gerido o acesso antecipado a ambientes de sandbox dos órgãos para validar contratos sintéticos antes do MVP1?

**Resposta**:

O cronograma recomendado é: Fase 0 — Fundação, governança, arquitetura, RBAC, cofre, Admin e contratos técnicos: 2 a 4 semanas; MVP 1 — núcleo operacional com casos, documentos, templates, LLM Gateway, DataJud, CNA/OAB, BCB/SGS, prazos e calculadora: 8 a 12 semanas; MVP 2 — PDPJ/DJE, comunicações, eventos, workflows de ciência e fallback: 6 a 10 semanas; MVP técnico PJe/MNI — homologação por tribunal piloto, certificado e protocolo: 4 a 8 semanas por tribunal. Datas absolutas devem ser confirmadas no início da Sprint 0 conforme equipe, orçamento e disponibilidade de credenciais.

## Q70
<!-- pfq-id: 0b357581-0100-4032-92d3-b8b54a0228ff -->

**Pergunta**: Quais são os requisitos de latência máximos para interações no frontend e qual o orçamento de tempo para respostas assíncronas?

**Resposta**:

Requisitos de latência: telas internas comuns em até 2 segundos quando não dependerem de serviços externos; retorno de protocolo para tarefa assíncrona em até 5 segundos; consulta externa com timeout configurável; geração de minuta por IA em fila com status e notificação. O frontend deve exibir progresso e nunca travar aguardando conector lento.

## Q71
<!-- pfq-id: 9e277370-b6cd-492f-bec6-a084f07620f4 -->

**Pergunta**: A equipe de desenvolvimento já tem acesso antecipado a ambientes de homologação de DataJud e DJE para validar contratos antes do MVP1?

**Resposta**:

Acesso a homologação/sandbox dependerá do órgão. DataJud público não possui sandbox típico; serão usados mocks e consultas controladas. DJE/PDPJ exige cadastro do CNPJ e geração de credenciais no ecossistema PDPJ. PJe/MNI depende de tribunal piloto e eventual solicitação formal/ofício/SEI. Sem credencial real, o conector pode ser desenvolvido com contrato sintético, mas não deve ser aceito para produção.


---
