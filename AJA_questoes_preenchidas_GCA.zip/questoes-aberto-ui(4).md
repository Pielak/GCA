---
gca-followup-marker: v1
project_id: 24bf72c3-2ee8-45fd-b879-d3a00b347c39
persona_id: UI
persona_name: UI Designer
generated_at: 2026-05-05T01:39:24.256668+00:00
question_count: 9
---

# Perguntas em aberto — UI Designer — Assistente Judicial para Advogados

Preencha as respostas abaixo de cada pergunta (substitua `<sua resposta aqui>`). Faça upload deste arquivo pela aba **Ingestão de Documentos**. NÃO altere as linhas com `<!-- pfq-id: ... -->`.

## Q1
<!-- pfq-id: 3f86a4e6-44ab-494c-ae51-ccf353d50619 -->

**Pergunta**: Quais são as paletas de cores primárias e secundárias?

**Resposta**:

A paleta inicial recomendada para o AJA deve transmitir seriedade jurídica, leitura confortável e boa acessibilidade. Primária: azul institucional #1E3A5F, azul de ação #2563EB e azul claro de apoio #DBEAFE. Secundária: cinza grafite #1F2937, cinza texto #374151, cinza borda #D1D5DB e superfície #F9FAFB. Estados: sucesso #15803D, alerta #B45309, erro #B91C1C e informação #0369A1. A paleta deve ser parametrizada por tokens de design, permitindo ajuste por tenant sem comprometer contraste WCAG AA.

## Q2
<!-- pfq-id: 29ffb456-3d0b-44a6-8cde-e6a513f67d7f -->

**Pergunta**: Qual a tipografia principal e as regras de hierarquia?

**Resposta**:

A tipografia principal recomendada é Inter ou Roboto, por legibilidade em interfaces densas. Hierarquia: H1 28–32px/700, H2 24px/700, H3 20px/600, corpo 16px/400, corpo secundário 14px/400, labels 14px/500 e metadados 12px/400. O sistema deverá usar unidades relativas rem/em, line-height mínimo de 1,4 para textos longos e evitar texto abaixo de 12px. Títulos jurídicos, mensagens de erro e alertas devem ter contraste e espaçamento suficientes para leitura prolongada.

## Q3
<!-- pfq-id: a31f89a9-d587-4fc9-a279-fff89f2b4e4c -->

**Pergunta**: Existe algum design system adotado (Material, Fluent, etc.)?

**Resposta**:

Sim. O AJA deverá adotar um design system próprio baseado em tokens, componentes reutilizáveis e padrões de acessibilidade WCAG 2.2 AA. Como referência técnica, pode usar Material Design ou shadcn/ui/Radix UI para componentes acessíveis, mas a identidade visual deverá ser própria do AJA. O design system deverá conter tokens de cor, tipografia, espaçamento, sombras, bordas, estados, componentes, padrões de formulário, tabela, modais, navegação, feedbacks e mensagens.

## Q4
<!-- pfq-id: 42f794ab-9f31-4445-bd3b-2875959d030a -->

**Pergunta**: Quais componentes UI são previstos e como serão parametrizados?

**Resposta**:

Componentes previstos: botões, inputs, selects, combobox, datepicker, upload de documentos, tabela com filtros, cards de caso/processo, timeline processual, modal, drawer lateral, tabs, breadcrumbs, badges de status, alertas, toast, skeleton loading, barra de progresso, editor de minuta, visualizador de PDF, painel de auditoria, painel Admin, paginação, chips de filtros, componentes de aprovação/revisão humana e indicadores de fonte/cache/IA. Todos devem ser parametrizados por tokens de tema, permissões RBAC, estado da operação, tenant e nível de sigilo.

## Q5
<!-- pfq-id: 2da66cba-7b32-4a07-af13-d3ea2c634c0c -->

**Pergunta**: Como serão representados estados de interação (foco, erro, carregamento, desabilitado)?

**Resposta**:

Estados de interação serão representados de forma visual e textual: foco com outline visível e navegável por teclado; erro com mensagem descritiva, ícone, borda e texto explicativo; carregamento com spinner, skeleton, barra de progresso ou status por etapa; desabilitado com contraste suficiente e tooltip/motivo quando aplicável; sucesso com confirmação clara e log de auditoria para ações críticas. Nenhum estado dependerá exclusivamente de cor.

## Q6
<!-- pfq-id: a3a69ab9-7073-42d3-aa3b-774abcc5c4c7 -->

**Pergunta**: Há protótipos ou wireframes que demonstrem o fluxo visual das telas listadas?

**Resposta**:

Ainda não há protótipos finais aprovados. Como requisito, deverão ser criados wireframes de baixa fidelidade na Sprint 0 e protótipos navegáveis antes do início do desenvolvimento das telas críticas. Fluxos mínimos: login/MFA, dashboard, cadastro de tenant, casos/processos, ingestão documental, pesquisa DataJud, geração de minuta com revisão humana, cálculo judicial, gestão de prazos, repositório de templates, Admin de integrações, LGPD/solicitações e auditoria.

## Q7
<!-- pfq-id: eec386b3-b96d-4bea-bf83-e5a5526e6f33 -->

**Pergunta**: Que parâmetros de contraste WCAG foram considerados para cores e tipografia?

**Resposta**:

A paleta inicial recomendada para o AJA deve transmitir seriedade jurídica, leitura confortável e boa acessibilidade. Primária: azul institucional #1E3A5F, azul de ação #2563EB e azul claro de apoio #DBEAFE. Secundária: cinza grafite #1F2937, cinza texto #374151, cinza borda #D1D5DB e superfície #F9FAFB. Estados: sucesso #15803D, alerta #B45309, erro #B91C1C e informação #0369A1. A paleta deve ser parametrizada por tokens de design, permitindo ajuste por tenant sem comprometer contraste WCAG AA.

## Q8
<!-- pfq-id: f8432139-4f6c-408b-9fc6-f162702e6ed3 -->

**Pergunta**: Como serão as animações e transições?

**Resposta**:

As animações deverão ser discretas, funcionais e não decorativas. Serão usadas para feedback de estado, expansão de painéis, abertura de modais, progresso de processamento, confirmação e erro. Duração recomendada: 150–250 ms para microinterações e até 400 ms para transições maiores. Deve existir respeito a prefers-reduced-motion, evitando animações obrigatórias, piscantes ou que prejudiquem usuários com sensibilidade visual. Operações longas devem priorizar clareza do status, não animação estética.

## Q9
<!-- pfq-id: 7c448364-1c36-47df-bc71-10f5080b7b72 -->

**Pergunta**: Qual a estratégia de layout responsivo ou adaptável?

**Resposta**:

A estratégia será web responsiva, desktop-first para uso profissional em escritório, mas funcional em notebooks, tablets e telas menores. Breakpoints sugeridos: mobile até 640px, tablet até 1024px, desktop acima de 1024px e wide acima de 1440px. Layouts devem usar grid/flex, painéis recolhíveis, tabelas responsivas com colunas configuráveis, navegação lateral colapsável e suporte a zoom 200%. Operações complexas, como editor de minuta e visualizador de documentos, terão experiência otimizada para desktop.
