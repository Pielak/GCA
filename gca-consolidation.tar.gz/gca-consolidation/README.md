# Consolidação documental do GCA — opção C (contrato + skills)

Pacote auto-aplicável para reorganizar a documentação do GCA seguindo o padrão **CLAUDE.md operacional + skills lazy-loaded** do Claude Code.

## O que este pacote faz

1. **Substitui `CLAUDE.md`** com versão operacional reescrita: protocolo de honestidade técnica, invariantes do contrato canônico inline, apontamento para skills, proibições explícitas com âncoras a símbolos reais (`AIKeyResolver`, `project_settings`, `VaultService`, etc.).
2. **Cria 3 skills em `.claude/skills/`** que o Claude Code carrega sob demanda:
   - `gca-llm-resolver` — porta única para invocação de LLM, proibições de hardcode.
   - `gca-ocg-engine` — máquina de estado do OCG com a regra atualizada (**só expande, nunca contrai**).
   - `gca-personas-engine` — sistema de Personas v2 (Auditor + 7 especialistas + HITL + ConflictDetector).
3. **Patcheia `GCA_CANONICAL_CONTRACT.md` §5** para refletir a nova regra do OCG.
4. **Move documentos deprecados para `docs/_deprecated/`** com banner de aviso no topo de cada um:
   - `OCG_DEFINICAO.md`, `ARQUITETURA.md`, `ANALISE_COMPLETA_GCA.md` (já marcados como históricos).
   - 3 versões antigas de `TASK_PERSONAS_V2` (v1.1, _1_, _2_).
   - Versão vigente (`__3_`, v1.3) renomeada para `TASK_PERSONAS_V2_v1_3.md` e arquivada como referência histórica de execução (o conteúdo duradouro virou skill).
5. **Faz backup completo** em `~/.gca-backups/consolidation-<timestamp>/` antes de qualquer alteração.

## Pré-requisitos

- `/home/luiz/GCA` é um repositório git.
- Working tree limpo (ou consciência das mudanças não commitadas — o script avisa e pede confirmação).
- Python 3 disponível no PATH (usado para o patch do contrato).

## Uso

### 1. Dry-run (recomendado primeiro)

```bash
cd /caminho/onde/voce/extraiu/o/pacote
./apply.sh --dry-run
```

Mostra exatamente o que seria feito, sem tocar em nada.

### 2. Aplicação real

```bash
./apply.sh
```

Aplica em `/home/luiz/GCA` por padrão.

### 3. Aplicação em path alternativo

```bash
./apply.sh /home/luiz/GCA-fork
```

## Após aplicar

```bash
cd /home/luiz/GCA
git status
git diff CLAUDE.md
git diff GCA_CANONICAL_CONTRACT.md
git add -A
git commit -m "docs: consolidação documental (opção C: contrato + skills)"
```

### Para o Claude Code reconhecer as mudanças

CLAUDE.md, settings.json e skills são carregados no `SessionStart`. Em sessão ativa do Claude Code:

- Feche a sessão e abra de novo (`claude` no diretório do projeto).
- Ou rode `/clear` para forçar reload de contexto.

Skills são `lazy-loaded`: o Claude Code lê apenas o frontmatter YAML (name + description) no SessionStart. O corpo da skill só é injetado no contexto quando você pergunta algo cuja descrição da skill bate. Custo em tokens fixos por sessão: ~3.500 (CLAUDE.md + 3 skills metadata).

## Rollback

O script faz backup automático em `~/.gca-backups/consolidation-<timestamp>/`. Para reverter:

```bash
TS=<timestamp do backup>
cp -rp ~/.gca-backups/consolidation-$TS/* /home/luiz/GCA/
cd /home/luiz/GCA
git status
```

Alternativamente, se ainda não commitou:

```bash
cd /home/luiz/GCA
git checkout .
git clean -fd
```

## Estrutura do pacote

```
gca-consolidation/
├── README.md                   # Este arquivo
├── TASK_GCA_CONSOLIDATION.md   # TASK file (executável manualmente também)
├── apply.sh                    # Script de aplicação (idempotente)
└── payload/
    ├── CLAUDE.md
    ├── _DEPRECATED_BANNER.md
    └── .claude/
        └── skills/
            ├── gca-llm-resolver/SKILL.md
            ├── gca-ocg-engine/SKILL.md
            └── gca-personas-engine/SKILL.md
```

## Decisões registradas

- **Opção C escolhida** (não A=monólito, não B=3 contratos paralelos): contrato canônico permanece + skills carregadas sob demanda. Custo de contexto fixo: ~3.500 tokens/sessão (vs. ~35k no monólito).
- **OCG só expande**: regra atualizada aplicada tanto na skill `gca-ocg-engine` quanto no patch do `GCA_CANONICAL_CONTRACT.md` §5.
- **TASK_PERSONAS v1.3 + Pré-Fase A vira skill `gca-personas-engine`**, removendo instruções one-shot de execução. O TASK original é arquivado para auditoria.
- **`docs/_deprecated/` preserva tudo** que era ambíguo ou contraditório, com banner explícito.

## Status idempotente

O script pode ser rodado múltiplas vezes sem dano:

- Arquivos já movidos não são movidos de novo.
- Banner já presente não é duplicado.
- Patch do contrato detecta marca textual da nova regra para não aplicar duas vezes.
- Skills já instaladas são sobrescritas (versão do payload é sempre canônica).
