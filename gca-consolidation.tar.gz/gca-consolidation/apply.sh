#!/usr/bin/env bash
# =============================================================================
# apply.sh — Consolidação documental do GCA (opção C: contrato + skills)
# =============================================================================
# Uso:
#   ./apply.sh             # aplica em /home/luiz/GCA
#   ./apply.sh --dry-run   # mostra o que faria, sem tocar em nada
#   ./apply.sh /caminho/alternativo   # aplica em outro path
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Configuração
# ---------------------------------------------------------------------------
GCA_ROOT="${1:-/home/luiz/GCA}"
DRY_RUN=false

if [[ "${1:-}" == "--dry-run" ]]; then
  DRY_RUN=true
  GCA_ROOT="${2:-/home/luiz/GCA}"
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD_DIR="$SCRIPT_DIR/payload"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$HOME/.gca-backups/consolidation-$TIMESTAMP"

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log()  { echo -e "${BLUE}[INFO]${NC} $*"; }
ok()   { echo -e "${GREEN}[ OK ]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()  { echo -e "${RED}[ERR ]${NC} $*" >&2; }

# Wrapper para comandos que respeitam --dry-run
run() {
  if $DRY_RUN; then
    echo "  [dry-run] $*"
  else
    eval "$@"
  fi
}

# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------
log "Pre-flight checks"

if [[ ! -d "$GCA_ROOT" ]]; then
  err "Diretório $GCA_ROOT não existe."
  exit 1
fi
ok "Diretório $GCA_ROOT existe"

if [[ ! -d "$GCA_ROOT/.git" ]]; then
  err "$GCA_ROOT não é um repositório git. Abortando para preservar histórico."
  exit 1
fi
ok "Repositório git detectado"

cd "$GCA_ROOT"

if [[ -n "$(git status --porcelain)" ]]; then
  warn "Working tree do repo não está limpo:"
  git status --short
  echo
  read -rp "Prosseguir mesmo assim? [s/N] " resp
  if [[ ! "$resp" =~ ^[sSyY]$ ]]; then
    err "Abortado pelo usuário."
    exit 1
  fi
fi
ok "Working tree verificado"

if [[ ! -d "$PAYLOAD_DIR" ]]; then
  err "Payload não encontrado em $PAYLOAD_DIR"
  exit 1
fi
ok "Payload localizado em $PAYLOAD_DIR"

# ---------------------------------------------------------------------------
# Backup
# ---------------------------------------------------------------------------
log "Criando backup em $BACKUP_DIR"
if ! $DRY_RUN; then
  mkdir -p "$BACKUP_DIR"
  for f in CLAUDE.md GCA_CANONICAL_CONTRACT.md OCG_DEFINICAO.md ARQUITETURA.md \
           ANALISE_COMPLETA_GCA.md DESIGN.md GCA_MVP_PROGRESS.md \
           TASK_PERSONAS_V2.md TASK_PERSONAS_V2_v1_1.md \
           TASK_PERSONAS_V2__1_.md TASK_PERSONAS_V2__2_.md TASK_PERSONAS_V2__3_.md; do
    if [[ -f "$GCA_ROOT/$f" ]]; then
      cp -p "$GCA_ROOT/$f" "$BACKUP_DIR/"
    fi
  done
  if [[ -d "$GCA_ROOT/.claude" ]]; then
    cp -rp "$GCA_ROOT/.claude" "$BACKUP_DIR/"
  fi
  echo "$TIMESTAMP" > "$BACKUP_DIR/.timestamp"
fi
ok "Backup salvo (rollback: cp -rp $BACKUP_DIR/* $GCA_ROOT/)"

# ---------------------------------------------------------------------------
# 1. Criar diretório de deprecados
# ---------------------------------------------------------------------------
log "Criando docs/_deprecated/"
run "mkdir -p '$GCA_ROOT/docs/_deprecated'"

# ---------------------------------------------------------------------------
# 2. Mover documentos deprecados
# ---------------------------------------------------------------------------
log "Movendo documentos deprecados"

DEPRECATED_FILES=(
  "OCG_DEFINICAO.md"
  "ARQUITETURA.md"
  "ANALISE_COMPLETA_GCA.md"
  "TASK_PERSONAS_V2_v1_1.md"
  "TASK_PERSONAS_V2__1_.md"
  "TASK_PERSONAS_V2__2_.md"
)

for f in "${DEPRECATED_FILES[@]}"; do
  if [[ -f "$GCA_ROOT/$f" ]]; then
    run "git mv '$GCA_ROOT/$f' '$GCA_ROOT/docs/_deprecated/$f' 2>/dev/null || mv '$GCA_ROOT/$f' '$GCA_ROOT/docs/_deprecated/$f'"
    ok "Movido: $f"
  else
    warn "Não encontrado (ignorando): $f"
  fi
done

# A versão vigente do TASK_PERSONAS é a __3_, vai com nome claro
if [[ -f "$GCA_ROOT/TASK_PERSONAS_V2__3_.md" ]]; then
  run "git mv '$GCA_ROOT/TASK_PERSONAS_V2__3_.md' '$GCA_ROOT/docs/_deprecated/TASK_PERSONAS_V2_v1_3.md' 2>/dev/null || mv '$GCA_ROOT/TASK_PERSONAS_V2__3_.md' '$GCA_ROOT/docs/_deprecated/TASK_PERSONAS_V2_v1_3.md'"
  ok "Movido (vigente, renomeado): TASK_PERSONAS_V2__3_.md → docs/_deprecated/TASK_PERSONAS_V2_v1_3.md"
fi

# ---------------------------------------------------------------------------
# 3. Adicionar banner de deprecated nos arquivos movidos
# ---------------------------------------------------------------------------
log "Adicionando banner de deprecated"

BANNER_FILE="$PAYLOAD_DIR/_DEPRECATED_BANNER.md"

prepend_banner() {
  local target="$1"
  if [[ ! -f "$target" ]]; then
    return
  fi
  if head -3 "$target" | grep -q "DOCUMENTO HISTÓRICO / DEPRECADO"; then
    warn "Banner já presente em $(basename "$target") — pulando"
    return
  fi
  if $DRY_RUN; then
    echo "  [dry-run] prepend banner em $target"
    return
  fi
  local tmp
  tmp="$(mktemp)"
  cat "$BANNER_FILE" "$target" > "$tmp"
  mv "$tmp" "$target"
  ok "Banner adicionado: $(basename "$target")"
}

if [[ -d "$GCA_ROOT/docs/_deprecated" ]]; then
  for f in "$GCA_ROOT/docs/_deprecated/"*.md; do
    [[ -f "$f" ]] && prepend_banner "$f"
  done
fi

# ---------------------------------------------------------------------------
# 4. Substituir CLAUDE.md
# ---------------------------------------------------------------------------
log "Atualizando CLAUDE.md"
run "cp '$PAYLOAD_DIR/CLAUDE.md' '$GCA_ROOT/CLAUDE.md'"
ok "CLAUDE.md atualizado (operacional + invariantes inline + apontamento para skills)"

# ---------------------------------------------------------------------------
# 5. Instalar skills em .claude/skills/
# ---------------------------------------------------------------------------
log "Instalando skills em .claude/skills/"

for skill in gca-ocg-engine gca-personas-engine gca-llm-resolver; do
  run "mkdir -p '$GCA_ROOT/.claude/skills/$skill'"
  run "cp '$PAYLOAD_DIR/.claude/skills/$skill/SKILL.md' '$GCA_ROOT/.claude/skills/$skill/SKILL.md'"
  ok "Skill instalada: $skill"
done

# ---------------------------------------------------------------------------
# 6. Patch no GCA_CANONICAL_CONTRACT.md §5 (regra atualizada do OCG)
# ---------------------------------------------------------------------------
log "Patcheando GCA_CANONICAL_CONTRACT.md §5 (regra atualizada do OCG)"

CONTRACT="$GCA_ROOT/GCA_CANONICAL_CONTRACT.md"

if [[ -f "$CONTRACT" ]]; then
  # Verificar se já patcheado (idempotência)
  if grep -q "OCG só expande quando recebe informação de valor" "$CONTRACT"; then
    warn "Patch §5 já aplicado anteriormente — pulando"
  else
    if $DRY_RUN; then
      echo "  [dry-run] aplicaria patch em §5 do CONTRACT"
    else
      python3 - <<PYEOF
import re, sys
path = "$CONTRACT"
with open(path, "r", encoding="utf-8") as f:
    src = f.read()

old = """## 5. OCG é obrigatório

O **OCG** é a fonte única de verdade do projeto.

Regras obrigatórias:
- o OCG nasce do questionário aprovado;
- o OCG é evolutivo e auditável;
- boa ingestão expande contexto;
- ingestão ruim ou conflitante contrai confiança;
- módulos não podem assumir defaults invisíveis quando o OCG estiver incompleto;
- toda mudança relevante deve gerar versionamento e trilha de auditoria."""

new = """## 5. OCG é obrigatório

O **OCG** é a fonte única de verdade do projeto.

Regras obrigatórias (atualizadas em 2026-04-30 — substituem versão anterior):
- o OCG nasce do questionário aprovado;
- o OCG é evolutivo e auditável;
- **o OCG só expande quando recebe informação de valor; nunca contrai**;
- ingestão ruim ou conflitante: documento vai para **quarentena** e **não afeta o OCG** (não há mais "contração de confiança" como behavior do motor);
- módulos não podem assumir defaults invisíveis quando o OCG estiver incompleto;
- toda mudança relevante deve gerar versionamento e trilha de auditoria.

Detalhe da máquina de estado, schema e propagação: skill \`gca-ocg-engine\` em \`.claude/skills/gca-ocg-engine/SKILL.md\`."""

if old not in src:
    print("ERRO: bloco esperado de §5 não encontrado. Patch manual necessário.", file=sys.stderr)
    sys.exit(2)

src = src.replace(old, new)
with open(path, "w", encoding="utf-8") as f:
    f.write(src)
print("Patch §5 aplicado.")
PYEOF
      ok "GCA_CANONICAL_CONTRACT.md §5 atualizado"
    fi
  fi
else
  warn "GCA_CANONICAL_CONTRACT.md não encontrado — pulando patch"
fi

# ---------------------------------------------------------------------------
# 7. Verificações pós-aplicação
# ---------------------------------------------------------------------------
echo
log "Verificações pós-aplicação"

POST_OK=true
check() {
  if [[ -e "$1" ]]; then
    ok "$1"
  else
    err "Faltando: $1"
    POST_OK=false
  fi
}

if ! $DRY_RUN; then
  check "$GCA_ROOT/CLAUDE.md"
  check "$GCA_ROOT/.claude/skills/gca-ocg-engine/SKILL.md"
  check "$GCA_ROOT/.claude/skills/gca-personas-engine/SKILL.md"
  check "$GCA_ROOT/.claude/skills/gca-llm-resolver/SKILL.md"
  check "$GCA_ROOT/docs/_deprecated"

  # Confirmar que documentos deprecados saíram do root
  for f in OCG_DEFINICAO.md ARQUITETURA.md ANALISE_COMPLETA_GCA.md \
           TASK_PERSONAS_V2_v1_1.md TASK_PERSONAS_V2__1_.md \
           TASK_PERSONAS_V2__2_.md TASK_PERSONAS_V2__3_.md; do
    if [[ -f "$GCA_ROOT/$f" ]]; then
      err "Ainda no root (deveria estar em docs/_deprecated/): $f"
      POST_OK=false
    fi
  done
fi

# ---------------------------------------------------------------------------
# 8. Resumo
# ---------------------------------------------------------------------------
echo
echo "==============================================================="
if $DRY_RUN; then
  echo " DRY-RUN concluído. Nenhuma alteração foi aplicada."
elif $POST_OK; then
  ok "Consolidação aplicada com sucesso em $GCA_ROOT"
  echo
  echo "Próximos passos:"
  echo "  1. cd $GCA_ROOT"
  echo "  2. git status                 # revisar mudanças"
  echo "  3. git diff CLAUDE.md         # comparar com versão anterior"
  echo "  4. git diff GCA_CANONICAL_CONTRACT.md   # confirmar patch §5"
  echo "  5. git add -A && git commit -m 'docs: consolidação documental (opção C: contrato + skills)'"
  echo
  echo "Para o Claude Code reconhecer as mudanças:"
  echo "  - Se há sessão claude aberta: feche e abra de novo (claude)"
  echo "  - Ou rode '/clear' dentro da sessão atual"
  echo
  echo "Backup do estado anterior: $BACKUP_DIR"
  echo "Para rollback: cp -rp \"$BACKUP_DIR\"/* \"$GCA_ROOT\"/"
else
  err "Consolidação aplicada com erros. Revise as mensagens acima."
  echo "Backup disponível em: $BACKUP_DIR"
fi
echo "==============================================================="
