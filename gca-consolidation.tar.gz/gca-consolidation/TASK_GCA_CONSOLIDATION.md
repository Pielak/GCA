# TASK_GCA_CONSOLIDATION.md — Consolidação documental do GCA (opção C)

**Tarefa Claude Code** — pode ser executada com `claude` em `~/GCA` se o `apply.sh` não for usado.

**Versão**: 1.0 (2026-04-30)

**Pré-requisitos verificáveis**:
- `/home/luiz/GCA` é um repositório git.
- Working tree limpo.
- Pacote `gca-consolidation/` extraído em algum lugar acessível (referenciado abaixo como `<PAYLOAD>`).

---

## 0. Filosofia

Esta TASK não é "automação de copia-cola". É **execução verificada de um plano documental**. Cada passo tem critério de aceite explícito. Se algum passo falhar, **PARAR e reportar** — nunca improvisar (regra §0 do CLAUDE.md).

---

## 1. Backup

```bash
TS=$(date +%Y%m%d-%H%M%S)
BACKUP=~/.gca-backups/consolidation-$TS
mkdir -p $BACKUP

cd /home/luiz/GCA
for f in CLAUDE.md GCA_CANONICAL_CONTRACT.md OCG_DEFINICAO.md ARQUITETURA.md \
         ANALISE_COMPLETA_GCA.md DESIGN.md GCA_MVP_PROGRESS.md \
         TASK_PERSONAS_V2*.md; do
  [[ -f "$f" ]] && cp -p "$f" "$BACKUP/"
done
[[ -d .claude ]] && cp -rp .claude "$BACKUP/"
echo "Backup em $BACKUP"
```

**Critério de aceite**: `$BACKUP` existe e contém pelo menos `CLAUDE.md` e `GCA_CANONICAL_CONTRACT.md`.

---

## 2. Mover deprecados para `docs/_deprecated/`

```bash
cd /home/luiz/GCA
mkdir -p docs/_deprecated

# Documentos já marcados como históricos
git mv OCG_DEFINICAO.md docs/_deprecated/ 2>/dev/null || mv OCG_DEFINICAO.md docs/_deprecated/
git mv ARQUITETURA.md docs/_deprecated/ 2>/dev/null || mv ARQUITETURA.md docs/_deprecated/
git mv ANALISE_COMPLETA_GCA.md docs/_deprecated/ 2>/dev/null || mv ANALISE_COMPLETA_GCA.md docs/_deprecated/

# Versões antigas do TASK_PERSONAS_V2
git mv TASK_PERSONAS_V2_v1_1.md docs/_deprecated/ 2>/dev/null || mv TASK_PERSONAS_V2_v1_1.md docs/_deprecated/
git mv TASK_PERSONAS_V2__1_.md docs/_deprecated/ 2>/dev/null || mv TASK_PERSONAS_V2__1_.md docs/_deprecated/
git mv TASK_PERSONAS_V2__2_.md docs/_deprecated/ 2>/dev/null || mv TASK_PERSONAS_V2__2_.md docs/_deprecated/

# Vigente (v1.3 + Pré-Fase A) renomeado para nome claro e arquivado como referência histórica
git mv TASK_PERSONAS_V2__3_.md docs/_deprecated/TASK_PERSONAS_V2_v1_3.md 2>/dev/null \
  || mv TASK_PERSONAS_V2__3_.md docs/_deprecated/TASK_PERSONAS_V2_v1_3.md
```

**Critério de aceite**:
- Nenhum arquivo da lista acima permanece no root do repo.
- `docs/_deprecated/` contém os 7 arquivos.
- `docs/_deprecated/TASK_PERSONAS_V2_v1_3.md` existe (vigente renomeado).

Se algum arquivo não existir no root, é possível que já tenha sido movido em rodada anterior — não é erro.

---

## 3. Adicionar banner em cada deprecado

Para cada `.md` em `docs/_deprecated/`, prepender o banner de `<PAYLOAD>/_DEPRECATED_BANNER.md`. Verificar antes se já não está presente (idempotência):

```bash
BANNER="<PAYLOAD>/_DEPRECATED_BANNER.md"
for f in docs/_deprecated/*.md; do
  if head -3 "$f" | grep -q "DOCUMENTO HISTÓRICO / DEPRECADO"; then
    echo "Banner já presente: $f"
  else
    tmp=$(mktemp)
    cat "$BANNER" "$f" > "$tmp"
    mv "$tmp" "$f"
    echo "Banner adicionado: $f"
  fi
done
```

**Critério de aceite**: `head -3 docs/_deprecated/<qualquer>.md` mostra a marca `DOCUMENTO HISTÓRICO / DEPRECADO`.

---

## 4. Substituir `CLAUDE.md`

```bash
cp <PAYLOAD>/CLAUDE.md /home/luiz/GCA/CLAUDE.md
```

**Critério de aceite**:
- `head -1 CLAUDE.md` retorna `# CLAUDE.md`.
- `grep -c "Honestidade técnica" CLAUDE.md` retorna ≥ 1.
- `grep -c "AIKeyResolver" CLAUDE.md` retorna ≥ 1.

---

## 5. Instalar skills

```bash
cd /home/luiz/GCA
mkdir -p .claude/skills/gca-llm-resolver
mkdir -p .claude/skills/gca-ocg-engine
mkdir -p .claude/skills/gca-personas-engine

cp <PAYLOAD>/.claude/skills/gca-llm-resolver/SKILL.md   .claude/skills/gca-llm-resolver/
cp <PAYLOAD>/.claude/skills/gca-ocg-engine/SKILL.md     .claude/skills/gca-ocg-engine/
cp <PAYLOAD>/.claude/skills/gca-personas-engine/SKILL.md .claude/skills/gca-personas-engine/
```

**Critério de aceite**:
- `find .claude/skills -name SKILL.md | wc -l` retorna `3`.
- Cada SKILL.md tem frontmatter YAML válido (`---` no início, `name:` e `description:` populados).

---

## 6. Patch §5 do contrato canônico

A versão antiga do §5 dizia "ingestão ruim ou conflitante contrai confiança". A regra atual diz que **OCG só expande, nunca contrai**. Aplicar via Python (mais seguro que sed para texto multi-linha em PT-BR):

```python
# Script in-line — salvar como /tmp/patch_contract.py e rodar
import sys
path = "/home/luiz/GCA/GCA_CANONICAL_CONTRACT.md"
with open(path, "r", encoding="utf-8") as f:
    src = f.read()

old = """## 5. OCG é obrigatório

O **OCG** é a fonte única de verdade do projeto.

Regras obrigatórias:
- o OCG nasce do questionário aprovado;
- o OCG é evolutivo e auditável;
- boa ingestão expande contexto;
- ingestão ruim ou conflitante contrai confiança;
- módulos não podem assumir defaults invisíveis quando o OCG estiver incompleto;
- toda mudança relevante deve gerar versionamento e trilha de auditoria."""

new = """## 5. OCG é obrigatório

O **OCG** é a fonte única de verdade do projeto.

Regras obrigatórias (atualizadas em 2026-04-30 — substituem versão anterior):
- o OCG nasce do questionário aprovado;
- o OCG é evolutivo e auditável;
- **o OCG só expande quando recebe informação de valor; nunca contrai**;
- ingestão ruim ou conflitante: documento vai para **quarentena** e **não afeta o OCG** (não há mais "contração de confiança" como behavior do motor);
- módulos não podem assumir defaults invisíveis quando o OCG estiver incompleto;
- toda mudança relevante deve gerar versionamento e trilha de auditoria.

Detalhe da máquina de estado, schema e propagação: skill `gca-ocg-engine` em `.claude/skills/gca-ocg-engine/SKILL.md`."""

if "OCG só expande quando recebe informação de valor" in src:
    print("Patch já aplicado anteriormente. Pulando.")
    sys.exit(0)

if old not in src:
    print("ERRO: bloco §5 esperado não encontrado. Patch manual necessário.", file=sys.stderr)
    sys.exit(2)

with open(path, "w", encoding="utf-8") as f:
    f.write(src.replace(old, new))
print("Patch §5 aplicado.")
```

**Critério de aceite**:
- `grep -c "OCG só expande quando recebe informação de valor" GCA_CANONICAL_CONTRACT.md` retorna `1`.
- `grep -c "ingestão ruim ou conflitante contrai confiança" GCA_CANONICAL_CONTRACT.md` retorna `0`.

---

## 7. Verificações finais

```bash
cd /home/luiz/GCA

# Estrutura nova existe
test -f CLAUDE.md
test -f .claude/skills/gca-llm-resolver/SKILL.md
test -f .claude/skills/gca-ocg-engine/SKILL.md
test -f .claude/skills/gca-personas-engine/SKILL.md
test -d docs/_deprecated

# Estrutura antiga removida do root
test ! -f OCG_DEFINICAO.md
test ! -f ARQUITETURA.md
test ! -f ANALISE_COMPLETA_GCA.md
test ! -f TASK_PERSONAS_V2_v1_1.md
test ! -f TASK_PERSONAS_V2__1_.md
test ! -f TASK_PERSONAS_V2__2_.md
test ! -f TASK_PERSONAS_V2__3_.md

# Patch aplicado
grep -q "OCG só expande quando recebe informação de valor" GCA_CANONICAL_CONTRACT.md
```

Se algum `test` falhar, o exit code não-zero indica problema.

---

## 8. Commit

Apenas após verificações OK. Em PT-BR (regra do CLAUDE.md §6):

```bash
cd /home/luiz/GCA
git add -A
git commit -m "docs: consolidação documental (opção C: contrato + skills)

- CLAUDE.md reescrito com protocolo de honestidade técnica e invariantes inline
- skills criadas: gca-llm-resolver, gca-ocg-engine, gca-personas-engine
- regra do OCG atualizada: só expande, nunca contrai (§5 do contrato + skill)
- 7 documentos deprecados movidos para docs/_deprecated/ com banner
- backup do estado anterior em ~/.gca-backups/"
```

---

## 9. Reload do Claude Code

Para o Claude Code reconhecer as mudanças:

- Se há sessão aberta: feche e abra de novo (`claude` no diretório).
- Ou rode `/clear` na sessão atual.

---

## Falhas e rollback

Se algum passo falhar, **PARAR**. Não improvisar correção. Reportar:

- Passo onde falhou.
- Output literal do erro.
- Estado do repo (`git status`).

Para reverter ao estado pré-aplicação:

```bash
cp -rp ~/.gca-backups/consolidation-<TS>/* /home/luiz/GCA/
cd /home/luiz/GCA
git checkout .
git clean -fd .claude/skills/gca-* docs/_deprecated/
```
